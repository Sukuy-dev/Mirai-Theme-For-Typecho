<?php
/**
 * 感谢使用 Mirai 未来主题，这是一款为 Typecho 打造的简约优雅、多功能现代化内容管理主题。
 * 作者：苏酷伊 Sukuy
 * 博客：https://www.sukuy.com
 * QQ：1461139506
 * QQ 群：884250547
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

require_once __DIR__ . '/core/loader.php';
require_once __DIR__ . '/common/functions.php';
require_once __DIR__ . '/common/init.php';
require_once __DIR__ . '/common/control.php';
require_once __DIR__ . '/common/mysql/migration.php';
require_once __DIR__ . '/common/backup.php';
require_once __DIR__ . '/common/editor.php';
require_once __DIR__ . '/modules/upload.php';
require_once __DIR__ . '/modules/pagination.php';
require_once __DIR__ . '/common/config/theme-config.php';

Mirai_registerEditorHooks();

function themeActivate() {
    Mirai_ensureDatabaseSchema();
}