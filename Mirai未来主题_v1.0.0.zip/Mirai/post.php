<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php
$db = \Typecho\Db::get();
$user_id = $this->user->uid;

$isLiked = false;
$isCollected = false;
$likeCount = 0;
$paySettings = Mirai_payPostSettings($this->cid);
$payCanUse = Mirai_payEnabled() && Mirai_payAvailableForPost($paySettings);
$isPostAuthor = (int)$user_id > 0 && isset($this->authorId) && (int)$this->authorId === (int)$user_id;
$payHasAccess = !$payCanUse ? true : ($isPostAuthor || Mirai_payHasPaid($this->cid, (int)$user_id));
$payToken = \Widget\Security::alloc()->getToken('api');

try {
    $isLiked = Mirai_isLiked($this->cid, $user_id);
    $isCollected = Mirai_isCollected($this->cid, $user_id);
    $likeCount = isset($this->likes) ? (int)$this->likes : 0;

    if ($likeCount === 0) {
         $postRow = $db->fetchRow($db->select('likes')->from('table.contents')->where('cid = ?', $this->cid));
         if ($postRow) {
             $likeCount = (int)($postRow['likes'] ?? 0);
         }
    }

} catch (Exception $e) {

}
?>
<?php $this->need('header.php'); ?>
<?php $this->need('modules/breadcrumb.php'); ?>

<main id="main-content">
<article class="gt-article-main">
    <header>
        <h1><?php $this->title() ?></h1>
        <div class="article-meta">
            <div class="article-meta-left">
                <div class="article-author-box">
                    <?php
                    $authorUrl = Mirai_getAuthorArchiveUrl($this->authorId);
                    $avatarUrl = $this->authorId ? Mirai_getUserAvatar($this->authorId) : Mirai_getDefaultAvatar();
                    $authorName = htmlspecialchars($this->author->screenName, ENT_QUOTES, 'UTF-8');
                    ?>
                    <a class="article-author-avatar" href="<?php echo $authorUrl ? htmlspecialchars($authorUrl, ENT_QUOTES, 'UTF-8') : 'javascript:void(0);'; ?>">
                        <img src="<?php echo htmlspecialchars($avatarUrl, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo $authorName; ?>" loading="lazy">
                    </a>
                    <div class="article-author-info">
                        <a class="article-author-name" href="<?php echo $authorUrl ? htmlspecialchars($authorUrl, ENT_QUOTES, 'UTF-8') : 'javascript:void(0);'; ?>"><?php echo $authorName; ?></a>
                        <div class="article-publish-time">
                            <time datetime="<?php echo Mirai_formatISODate($this->created); ?>" itemprop="datePublished"><?php $this->date('Y-m-d'); ?></time>
                            <?php if ($this->modified > $this->created): ?>
                            <span class="time-separator"> </span>
                            <time itemprop="dateModified" datetime="<?php echo Mirai_formatISODate($this->modified); ?>">更新于<?php echo (new \Typecho\Date($this->modified))->format('Y-m-d'); ?></time>
                            <?php endif; ?>
                            <span class="time-separator"> </span>
                            <?php echo Mirai_formatNumber($this->views ?? 0, 'views'); ?>阅读
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    
    <div class="article-content-container">
        <?php if ($this->options->displaySummary): ?>
            <?php 
            $excerpt = Mirai_getPostExcerpt($this);
            if (!empty($excerpt)) {
                echo '<div class="article-excerpt">' . nl2br(htmlspecialchars($excerpt)) . '</div>';
            } elseif ($this->excerpt) {
                echo '<div class="article-excerpt">';
                $this->excerpt(100, '...');
                echo '</div>';
            }
            ?>
        <?php endif; ?>
        
        <div class="article-content">
            <?php
            $content = $this->content;
            $payBoxInlineRendered = false;
            $payBoxHtml = '';
            $payLocked = false;
            try {
                $content = Mirai_convertImagesToPicture($content, $this->title);
                if (Mirai_featureEnabled('seo') && (string)$this->options->nofollowExternalLinks !== '0') {
                    $content = Mirai_addNofollowToExternalLinks($content);
                }
                if ($payCanUse) {
                    $payFiltered = Mirai_payFilterPostContent($content, $this, $payHasAccess);
                    $content = $payFiltered['content'];
                    $payLocked = !empty($payFiltered['locked']);
                    if (!$payHasAccess && $payLocked) {
                        $payBoxHtml = Mirai_payRenderPurchaseBox($this, $paySettings, (int)$user_id, $payToken, 'inline');
                        if (strpos($content, '<!--MIRAI_PAYBOX_INLINE-->') !== false) {
                            $content = str_replace('<!--MIRAI_PAYBOX_INLINE-->', $payBoxHtml, $content);
                            $payBoxInlineRendered = true;
                        }
                    }
                }
            } catch (Exception $e) {
            }
            echo $content;
            ?>
        </div>
        <?php
        if ($payCanUse && !$payHasAccess && $payLocked && !$payBoxInlineRendered) {
            if ($payBoxHtml === '') {
                $payBoxHtml = Mirai_payRenderPurchaseBox($this, $paySettings, (int)$user_id, $payToken);
            }
            echo $payBoxHtml;
        }
        ?>
        <?php echo Mirai_getTags($this); ?>

        <p class="actions-title">觉得内容不错？我要</p>
        <div class="article-actions-bar">
            <button class="action-btn like-btn <?php echo $isLiked ? 'liked' : ''; ?>" onclick="likeArticle(<?php echo $this->cid; ?>)" id="likeBtn">
                <div class="btn-icon-wrap">
                    <?php if ($isLiked): ?>
                    <svg class="like-icon filled" viewBox="0 0 1024 1024"><path fill="currentColor" d="M190.193 471.412c14.446 0 26.14-11.72 26.14-26.14 0-14.445-11.694-26.164-26.14-26.164l-62.496.146c-1.426-.195-2.9-.296-4.374-.296-19.677 0-35.62 16.142-35.62 36.115v452.597c0 19.95 15.968 35.598 35.67 35.598l61.023.023c13.413-.54 24.175-11.422 24.175-24.96 0-13.56-10.76-24.442-24.175-24.982l-50.949-.001 1.45-402.276h50.266zM926.522 433.948c-19.283-31.445-47.34-44.172-81.29-45.546l-205.447-.689c13.463-39.06 22.7-85.589 22.7-129.317 0-28.35-3.194-55.963-9.042-82.543-10.638-46.579-51.736-81.315-100.966-81.315-57.264 0-95.466 48.151-95.466 106.126 0 3.242-.295 6.387 0 9.532-2.996 108.387-91.24 195.55-196.236 207.513v54.882l-.786 222.227v229.745h510.772c19.357 0 30.24-4.818 47.804-16.116 16.683-10.761 29.237-25.501 37.49-42.156l77.019-344.324c1.056-4.053 1.349-8.181 1.056-12.161-1.77-22.502-6.632-45.003-18.891-65zM893.826 486.838l-82.984 367.783c-2.555 6.142-6.88 11.596-12.872 15.427-4.177 2.727-8.774 4.351-13.415 4.964h-477.029l-.172-407.409c89.324-40.266 154.842-79.67 188.597-173.66 2.999-9.138 6.314-20.735 8.697-33.165 5.551-29.186 5.259-58.124 5.259-58.124-4.937-37.98 25.941-52.965 44.364-52.965 25.305.86 50.264 33.656 50.264 52.326 0 0 5.6 27.564 5.65 57.19.048 37.366-4.668 56.848-4.668 56.848l-.466.001c-5.873 30.879-16.215 60.138-30.465 86.964l.368.343c-2.359 4.815-3.71 10.22-3.71 15.943 0 19.923 19.089 21.742 38.766 21.742h238.762s14.666.465 14.69.465l.001.1c12.133-.638 24.222 5.207 31.1 16.41 5.505 9.016 6.438 19.604 3.487 28.988z"/></svg>
                    <?php else: ?>
                    <svg class="like-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M190.193 471.412c14.446 0 26.14-11.72 26.14-26.14 0-14.445-11.694-26.164-26.14-26.164l-62.496.146c-1.426-.195-2.9-.296-4.374-.296-19.677 0-35.62 16.142-35.62 36.115v452.597c0 19.95 15.968 35.598 35.67 35.598l61.023.023c13.413-.54 24.175-11.422 24.175-24.96 0-13.56-10.76-24.442-24.175-24.982l-50.949-.001 1.45-402.276h50.266zM926.522 433.948c-19.283-31.445-47.34-44.172-81.29-45.546l-205.447-.689c13.463-39.06 22.7-85.589 22.7-129.317 0-28.35-3.194-55.963-9.042-82.543-10.638-46.579-51.736-81.315-100.966-81.315-57.264 0-95.466 48.151-95.466 106.126 0 3.242-.295 6.387 0 9.532-2.996 108.387-91.24 195.55-196.236 207.513v54.882l-.786 222.227v229.745h510.772c19.357 0 30.24-4.818 47.804-16.116 16.683-10.761 29.237-25.501 37.49-42.156l77.019-344.324c1.056-4.053 1.349-8.181 1.056-12.161-1.77-22.502-6.632-45.003-18.891-65zM893.826 486.838l-82.984 367.783c-2.555 6.142-6.88 11.596-12.872 15.427-4.177 2.727-8.774 4.351-13.415 4.964h-477.029l-.172-407.409c89.324-40.266 154.842-79.67 188.597-173.66 2.999-9.138 6.314-20.735 8.697-33.165 5.551-29.186 5.259-58.124 5.259-58.124-4.937-37.98 25.941-52.965 44.364-52.965 25.305.86 50.264 33.656 50.264 52.326 0 0 5.6 27.564 5.65 57.19.048 37.366-4.668 56.848-4.668 56.848l-.466.001c-5.873 30.879-16.215 60.138-30.465 86.964l.368.343c-2.359 4.815-3.71 10.22-3.71 15.943 0 19.923 19.089 21.742 38.766 21.742h238.762s14.666.465 14.69.465l.001.1c12.133-.638 24.222 5.207 31.1 16.41 5.505 9.016 6.438 19.604 3.487 28.988z"/></svg>
                    <?php endif; ?>
                </div>
                <span class="btn-text">点赞 <em class="count"><?php echo $likeCount; ?></em></span>
            </button>

            <?php if (isset($this->options->displayReward) && $this->options->displayReward): ?>
            <button class="action-btn reward-btn" onclick="openRewardModal()">
                <div class="btn-icon-wrap">
                    <svg class="reward-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M670.6 282.3H352.8C245.7 336 127.3 516.1 127.3 690.5c0 216 316.4 232.9 380.5 234.5 68.3 1.7 388.4-15.6 388.4-237.4 0-162.3-119.4-351-225.6-405.3zm-33 313.6v34.7h-90.9V661h90.9v34.7h-90.9v72.1h-68.4v-72.1H387V661h91.3v-30.4H387v-34.7h75.4L352.3 422.1h81l42.6 84.3c17.3 35.6 23.4 47.8 36.1 73.1h2.3c13.6-25.3 19.7-38.9 36.1-73.1l42.2-84.3h79.6L561.7 595.9h75.9zM667.4 249.1H347.6l-38.1-124.9h396z"/></svg>
                </div>
                <span class="btn-text">打赏</span>
            </button>
            <?php endif; ?>

            <button class="action-btn share-btn" onclick="shareArticle()">
                <div class="btn-icon-wrap">
                    <svg class="share-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M835 871H152V189h369v-72H117c-20 0-36 16-36 36v755c0 20 16 36 36 36h755c20 0 36-16 36-36V539h-72v332z"/><path fill="currentColor" d="M932 228L787 81l-50 50 70 70c-72-4-167 5-237 59-70 52-106 133-106 241h72c0-84 25-147 74-183 64-49 157-50 220-44l-56 44 50 50 147-146c13-11 13-34-1-47z"/></svg>
                </div>
                <span class="btn-text">分享</span>
            </button>

            <button class="action-btn collect-btn <?php echo $isCollected ? 'collected' : ''; ?>" onclick="collectArticle(<?php echo $this->cid; ?>)" id="collectBtn">
                <div class="btn-icon-wrap">
                    <svg class="collect-icon <?php echo $isCollected ? 'filled' : ''; ?>" viewBox="0 0 1024 1024"><path fill="currentColor" d="M512 131L604 317c20 41 59 70 105 77l206 30-149 146c-33 32-48 78-40 123l35 206-183-97c-20-11-42-16-65-16s-45 5-65 16l-183 97 35-206c8-45-7-91-40-123L110 424l205-30c46-7 85-35 105-77L512 131m0-113c-20 0-41 11-52 32L347 282c-8 17-25 29-44 32L49 350C2 357-17 415 18 449l184 180c13 13 20 32 16 51l-44 254c-6 37 24 68 57 68 9 0 18-2 27-7l227-120c8-4 18-6 27-6s18 2 27 6l227 120c8 5 18 7 27 7 34 0 63-30 57-68l-44-254c-3-19 3-38 16-51l184-180c34-33 15-92-32-98l-254-37c-19-3-35-15-44-32L564 51c-11-21-31-32-52-32z"/></svg>
                </div>
                <span class="btn-text">收藏</span>
            </button>
        </div>
        
        <?php $this->need('modules/reward.php'); ?>
        
    </div>
</article>
</main>

<?php echo Mirai_copyright($this); ?>

<nav class="gt-post-navigation">
    <?php
    $nextPost = $db->fetchRow($db->select('cid', 'title', 'slug', 'created')->from('table.contents')
        ->where('created > ?', $this->created)
        ->where('created <= ?', $this->options->time)
        ->where('status = ?', 'publish')
        ->where('type = ?', 'post')
        ->where("password IS NULL OR password = ''")
        ->order('created', \Typecho\Db::SORT_ASC)
        ->limit(1));
    $prevPost = $db->fetchRow($db->select('cid', 'title', 'slug', 'created')->from('table.contents')
        ->where('created < ?', $this->created)
        ->where('status = ?', 'publish')
        ->where('type = ?', 'post')
        ->where("password IS NULL OR password = ''")
        ->order('created', \Typecho\Db::SORT_DESC)
        ->limit(1));
    ?>
    <?php if ($nextPost): ?>
    <a href="<?php echo \Typecho\Router::url('post', $nextPost, $this->options->index); ?>" class="gt-nav-prev" title="<?php echo htmlspecialchars($nextPost['title'], ENT_QUOTES, 'UTF-8'); ?>">
        <span class="gt-nav-label"><svg class="nav-prev-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M858 485H225l231-231c12-12 12-30 0-42-12-12-30-12-42 0L137 490c-6 6-9 14-9 22 0 8 3 16 9 22l277 277c12 12 30 12 42 0 12-12 12-30 0-42L232 546h626c17 0 30-13 30-30s-13-30-30-30z"/></svg> 上一篇</span>
        <span class="gt-nav-title"><?php echo htmlspecialchars($nextPost['title'], ENT_QUOTES, 'UTF-8'); ?></span>
    </a>
    <?php else: ?>
    <span class="gt-nav-prev gt-nav-empty"></span>
    <?php endif; ?>
    <?php if ($prevPost): ?>
    <a href="<?php echo \Typecho\Router::url('post', $prevPost, $this->options->index); ?>" class="gt-nav-next" title="<?php echo htmlspecialchars($prevPost['title'], ENT_QUOTES, 'UTF-8'); ?>">
        <span class="gt-nav-label">下一篇 <svg class="nav-next-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M166 485h633l-231-231c-12-12-12-30 0-42 12-12 30-12 42 0l277 277c6 6 9 14 9 22 0 8-3 16 9 22L610 820c-12 12-30 12-42 0-12-12-12-30 0-42l231-231H166c-17 0-30-13-30-30s13-30 30-30z"/></svg></span>
        <span class="gt-nav-title"><?php echo htmlspecialchars($prevPost['title'], ENT_QUOTES, 'UTF-8'); ?></span>
    </a>
    <?php else: ?>
    <span class="gt-nav-next gt-nav-empty"></span>
    <?php endif; ?>
</nav>

<?php echo Mirai_renderRelatedPosts($this); ?>

<section class="gt-comment" id="comment" data-cid="<?php echo $this->cid; ?>">
    <?php $this->need('modules/comments.php'); ?>
</section>

<?php $this->need('footer.php'); ?>
