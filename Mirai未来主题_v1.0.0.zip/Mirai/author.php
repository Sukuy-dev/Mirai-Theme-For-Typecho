<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php
$db = \Typecho\Db::get();
$authorId = isset($this->authorId) ? (int)$this->authorId : 0;
$authorSlug = '';

if (isset($this->author) && is_object($this->author)) {
    $authorId = isset($this->author->uid) ? (int)$this->author->uid : $authorId;
    $authorSlug = isset($this->author->name) ? (string)$this->author->name : '';
}

if (isset($this->parameter->uid) && (int)$this->parameter->uid > 0) {
    $authorId = (int)$this->parameter->uid;
}

if (method_exists($this->request, 'getParam')) {
    $authorSlug = $authorSlug ?: (string)$this->request->getParam('name');
    $authorSlug = $authorSlug ?: (string)$this->request->getParam('author');
}

$pathInfo = method_exists($this->request, 'getPathInfo') ? (string)$this->request->getPathInfo() : '';
if (!$authorSlug && preg_match('#/author/([^/]+)/?#', $pathInfo, $matches)) {
    $authorSlug = urldecode($matches[1]);
}

$authorRow = null;
if ($authorId > 0) {
    $authorRow = $db->fetchRow(
        $db->select('uid', 'name', 'screenName', 'mail', 'url', 'created', 'motto', 'cover')
            ->from('table.users')
            ->where('uid = ?', $authorId)
            ->limit(1)
    );
}
if (!$authorRow && $authorSlug !== '') {
    $authorRow = $db->fetchRow(
        $db->select('uid', 'name', 'screenName', 'mail', 'url', 'created', 'motto', 'cover')
            ->from('table.users')
            ->where('name = ?', $authorSlug)
            ->orWhere('screenName = ?', $authorSlug)
            ->limit(1)
    );
}

$authorName = '作者';
$authorMail = '';
$authorUrl = '';
$authorCreated = 0;
$authorMotto = '';
$authorCover = '/usr/themes/Mirai/assets/images/banner.webp';

if ($authorRow) {
    $authorId = (int)$authorRow['uid'];
    $authorSlug = (string)$authorRow['name'];
    $authorName = (string)$authorRow['screenName'] ?: $authorSlug ?: '作者';
    $authorMail = (string)$authorRow['mail'];
    $authorUrl = (string)$authorRow['url'];
    $authorCreated = (int)$authorRow['created'];
    $authorMotto = isset($authorRow['motto']) ? trim((string)$authorRow['motto']) : '';
    if (!empty($authorRow['cover'])) {
        $authorCover = Mirai_normalizeUrl((string)$authorRow['cover']);
    }
}

$authorAvatar = $authorId > 0 ? Mirai_getUserAvatar($authorId) : Mirai_getDefaultAvatar();
$authorPostCount = 0;
$authorCommentCount = 0;

if ($authorId > 0) {
    $postStatRow = $db->fetchObject(
        $db->select('COUNT(*) AS postCount')
            ->from('table.contents')
            ->where('authorId = ?', $authorId)
            ->where('type = ?', 'post')
            ->where('status = ?', 'publish')
    );
    if ($postStatRow) {
        $authorPostCount = (int)$postStatRow->postCount;
    }

    $commentRow = $db->fetchObject(
        $db->select('COUNT(table.comments.coid) AS num')
            ->from('table.comments')
            ->join('table.contents', 'table.comments.cid = table.contents.cid', \Typecho\Db::INNER_JOIN)
            ->where('table.contents.authorId = ?', $authorId)
            ->where('table.contents.type = ?', 'post')
            ->where('table.contents.status = ?', 'publish')
            ->where('table.comments.status = ?', 'approved')
    );
    $authorCommentCount = $commentRow ? (int)$commentRow->num : 0;

}

$totalPostsInArchive = (int)$this->getTotal();
$currentPage = max(1, (int)$this->getCurrentPage());
$pageSize = max(1, (int)$this->parameter->pageSize);
$totalPages = (int)ceil($totalPostsInArchive / $pageSize);
$hasPosts = $this->have();
$gridLayoutValue = Mirai_getFeatureValue($this->options->gridLayout ? $this->options->gridLayout : '3', '3', 'grid_layout');
$singleColumnEnabled = ($gridLayoutValue === '1');
?>
<?php $this->need('header.php'); ?>

<div class="gt-author-page">
    <section class="gt-author-header">
        <div class="gt-author-cover">
            <img src="<?php echo htmlspecialchars($authorCover, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($authorName, ENT_QUOTES, 'UTF-8'); ?>" loading="lazy">
            <div class="gt-author-cover-mask"></div>
        </div>
        <div class="gt-author-header-content">
            <div class="gt-author-header-info">
                <div class="gt-author-avatar-wrap">
                    <img src="<?php echo htmlspecialchars($authorAvatar, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($authorName, ENT_QUOTES, 'UTF-8'); ?>" loading="lazy">
                </div>
                <div class="gt-author-main">
                    <h1 class="gt-author-name"><?php echo htmlspecialchars($authorName, ENT_QUOTES, 'UTF-8'); ?></h1>
                    <?php if ($authorMotto !== ''): ?>
                    <p class="gt-author-desc"><?php echo htmlspecialchars($authorMotto, ENT_QUOTES, 'UTF-8'); ?></p>
                    <?php else: ?>
                    <p class="gt-author-desc">暂无个人简介</p>
                    <?php endif; ?>
                    <div class="gt-author-meta-line">
                        <span class="gt-author-meta-item">
                            <svg class="gt-author-icon" viewBox="0 0 1024 1024"><path fill="#FF6E00" d="M791.32 64H232.68c-53.74 0-97.45 42.97-97.45 95.76v704.48c0 52.79 43.72 95.76 97.45 95.76h558.65c53.74 0 97.45-42.97 97.45-95.76V159.76c0-52.79-43.72-95.76-97.45-95.76zM268.6 241.55h319.23c12.41 0 22.48 9.86 22.48 22.11 0 12.17-10.06 22.06-22.48 22.06H268.6c-12.41 0-22.48-9.9-22.48-22.06 0-12.25 10.06-22.11 22.48-22.11zm469.13 553.96H268.6c-12.41 0-22.48-9.9-22.48-22.11s10.06-22.11 22.48-22.11h469.13c12.41 0 22.52 9.9 22.52 22.11s-10.1 22.11-22.52 22.11zm0-169.93H268.6c-12.41 0-22.48-9.9-22.48-22.11s10.06-22.11 22.48-22.11h469.13c12.41 0 22.52 9.9 22.52 22.11s-10.1 22.11-22.52 22.11zm0-169.92H268.6c-12.41 0-22.48-9.88-22.48-22.08 0-12.23 10.06-22.13 22.48-22.13h469.13c12.41 0 22.52 9.9 22.52 22.13 0 12.21-10.1 22.08-22.52 22.08z"/></svg>
                            <?php echo Mirai_formatNumber($authorPostCount); ?>
                        </span>
                        <span class="gt-author-meta-item">
                            <svg class="gt-author-icon" viewBox="0 0 1024 1024"><path fill="#5EEFB7" d="M359.53 793.86h222.87c3.89 0 7.68 1.13 10.91 3.28l127.85 84.68c29.64 19.66 69.27-1.64 69.22-37.22l-0.05-30.92c0-10.91 8.81-19.76 19.76-19.76h31.13c63.49 0 115-51.51 115-115V361.06c0-63.49-51.51-115-115-115H359.53c-63.49 0-115 51.51-115 115v317.8c-0.05 63.54 51.46 115 115 115z"/><path fill="#4BE2AC" d="M734.21 757.86H485.27c-4.35 0-8.55 1.28-12.19 3.69l-167.63 111.05c-22.48 14.9-52.48-1.28-52.48-28.21l0.1-64.41c0-12.19-9.83-22.07-22.07-22.07h-34.76c-70.91 0-128.46-57.5-128.46-128.46V274.53c0-70.91 57.5-128.46 128.46-128.46H734.21c70.91 0 128.46 57.5 128.46 128.46v354.92c-0.05 70.91-57.55 128.41-128.46 128.41z"/><path fill="#06CC76" d="M359.53 246.07c-63.49 0-115 51.51-115 115v317.8c0 63.49 51.51 115 115 115h64.77l48.84-32.36c3.58-2.41 7.83-3.69 12.19-3.69h248.93c70.91 0 128.46-57.5 128.46-128.46v-354.82c0-9.22-0.97-18.23-2.87-26.93-6.09-0.97-12.29-1.54-18.64-1.54H359.53z"/><path fill="#FFFFFF" d="M670.05 361.63H279.6c-22.63 0-40.96-18.33-40.96-40.96s18.33-40.96 40.96-40.96h390.4c22.63 0 40.96 18.33 40.96 40.96s-18.28 40.96-40.91 40.96zm0 139.37H279.6c-22.63 0-40.96-18.33-40.96-40.96s18.33-40.96 40.96-40.96h390.4c22.63 0 40.96 18.33 40.96 40.96s-18.28 40.96-40.91 40.96zm-203.47 139.37H279.6c-22.63 0-40.96-18.33-40.96-40.96s18.33-40.96 40.96-40.96h186.98c22.63 0 40.96 18.33 40.96 40.96s-18.33 40.96-40.96 40.96z"/></svg>
                            <?php echo Mirai_formatNumber($authorCommentCount); ?>
                        </span>
                        <?php if ($authorCreated > 0): ?>
                        <span class="gt-author-meta-item">加入于 <?php echo (new \Typecho\Date($authorCreated))->format('Y-m-d'); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="gt-author-header-btns">
                    <?php if ($authorUrl !== ''): ?>
                    <a href="<?php echo htmlspecialchars($authorUrl, ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener noreferrer">网站</a>
                    <?php endif; ?>
                    <?php if ($authorMail !== ''): ?>
                    <a href="mailto:<?php echo htmlspecialchars($authorMail, ENT_QUOTES, 'UTF-8'); ?>">邮箱</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <section class="gt-author-posts">
        <div class="article-list-main">
            <section id="article-list-container" class="article-list <?php echo $singleColumnEnabled ? 'single-column' : ''; ?>" data-grid="<?php echo $gridLayoutValue; ?>">
            <?php if ($hasPosts): ?>
                <?php while ($this->next()): ?>
                    <?php Mirai_renderPostItem($this, ['isWidget' => true, 'isFirst' => false, 'isIndex' => false]); ?>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="gt-empty">
                    <img src="<?php $this->options->themeUrl('assets/images/empty.svg'); ?>" alt="暂无文章" width="120" height="120">
                    <p>该作者暂未发布文章</p>
                </div>
            <?php endif; ?>
            </section>
        </div>
        <?php if ($totalPages > 1): ?>
        <?php echo Mirai_customPagination($currentPage, $totalPages, function ($page) { return Mirai_getPageUrl($this, $page); }); ?>
        <?php endif; ?>
    </section>
</div>

<?php $this->need('footer.php'); ?>