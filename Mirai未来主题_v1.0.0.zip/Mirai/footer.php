<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
        </div>
        <?php 
        $shouldHideSidebar = (isset($this->hideThemeSidebar) && $this->hideThemeSidebar) || 
                             (isset($GLOBALS['_temp_hide_sidebar']) && $GLOBALS['_temp_hide_sidebar']);
        if (!$shouldHideSidebar): 
        ?>
        <?php $this->need('modules/sidebar.php'); ?>
        <?php endif; ?>
        <?php $this->need('modules/mobile/sidebar.php'); ?>
    </section>
</main>
<footer class="gt-footer" role="contentinfo">
    <main>
        <section class="gt-footer-grid">
            <section class="gt-footer-brand">
                <?php
                $footerLogoAlt = $this->options->siteTitle ? $this->options->siteTitle : $this->options->title;
                ?>
                <a class="gt-footer-logo" href="<?php $this->options->siteUrl(); ?>" rel="home" aria-label="<?php echo htmlspecialchars($footerLogoAlt); ?>" title="<?php echo htmlspecialchars($footerLogoAlt); ?>">
                    <?php
                    $footerLogoImage = $this->options->logoImage ? $this->options->logoImage : 'usr/themes/Mirai/assets/images/logo.png';
                    $footerLogoUrl = preg_replace('/^(?!http)/', $this->options->siteUrl, $footerLogoImage);
                    $footerDarkLogoUrl = $this->options->darkLogoImage ? preg_replace('/^(?!http)/', $this->options->siteUrl, $this->options->darkLogoImage) : '';
                    $footerLogoHeight = !empty($this->options->logoHeight) ? intval($this->options->logoHeight) : 40;
                    ?>
                    <?php if ($footerDarkLogoUrl): ?>
                        <img src="<?php echo htmlspecialchars($footerLogoUrl); ?>" alt="<?php echo htmlspecialchars($footerLogoAlt); ?>" class="gt-footer-logo-img mirai-logo-light" height="<?php echo $footerLogoHeight; ?>">
                        <img src="<?php echo htmlspecialchars($footerDarkLogoUrl); ?>" alt="<?php echo htmlspecialchars($footerLogoAlt); ?>" class="gt-footer-logo-img mirai-logo-dark" height="<?php echo $footerLogoHeight; ?>">
                    <?php else: ?>
                        <img src="<?php echo htmlspecialchars($footerLogoUrl); ?>" alt="<?php echo htmlspecialchars($footerLogoAlt); ?>" class="gt-footer-logo-img" height="<?php echo $footerLogoHeight; ?>">
                    <?php endif; ?>
                </a>
                <?php 
                    $footerDesc = $this->options->footerDesc;
                    if (!$footerDesc) {
                        $footerDesc = $this->options->siteDescription;
                    }
                ?>
                <?php if ($footerDesc): ?>
                <div class="gt-footer-desc"><?php echo nl2br(htmlspecialchars($footerDesc)); ?></div>
                <?php endif; ?>
            </section>
            <section class="gt-footer-custom" aria-label="底部自定义内容">
                <?php Mirai_customFooter(); ?>
                <section class="gt-footer-bottom" aria-label="底部信息">
                    <?php if ($this->options->icpNum): ?>
                    <p class="footer-beian">
                        <span><a href="https://beian.miit.gov.cn/" target="_blank"><?php echo htmlspecialchars($this->options->icpNum); ?></a></span>
                    </p>
                    <?php endif; ?>
                    <p class="footer-copyright">
                        <span>本站由Typecho& <a href="https://www.sukuy.com/" target="_blank">Mirai未来主题</a> 驱动</span>
                    </p>
                </section>
            </section>
            <?php
                $leftQr = $this->options->footerLeftQr;
                $rightQr = $this->options->footerRightQr;
                $qrSize = $this->options->footerQrSize ? $this->options->footerQrSize : '99';
            ?>
            <?php if ($leftQr || $rightQr): ?>
            <section class="gt-footer-qrcodes">
                <?php if ($leftQr): ?>
                <div class="gt-footer-qrcode">
                    <img class="gt-footer-qrcode-img" src="<?php echo $leftQr; ?>" alt="<?php $this->options->footerLeftQrText(); ?>" width="<?php echo $qrSize; ?>" height="<?php echo $qrSize; ?>">
                    <span class="gt-footer-qrcode-text"><?php $this->options->footerLeftQrText(); ?></span>
                </div>
                <?php endif; ?>
                <?php if ($rightQr): ?>
                <div class="gt-footer-qrcode">
                    <img class="gt-footer-qrcode-img" src="<?php echo $rightQr; ?>" alt="<?php $this->options->footerRightQrText(); ?>" width="<?php echo $qrSize; ?>" height="<?php echo $qrSize; ?>">
                    <span class="gt-footer-qrcode-text"><?php $this->options->footerRightQrText(); ?></span>
                </div>
                <?php endif; ?>
            </section>
            <?php endif; ?>
        </section>
    </main>
</footer>

<div class="gt-back-top" id="backTop" style="display: none;">
    <button onclick="scrollToTop()" title="返回顶部" aria-label="返回顶部">
        <svg class="back-top-icon" viewBox="0 0 1024 1024"><path fill="#3259CE" d="M513 103.7c-226.1 0-409.4 183.3-409.4 409.4S286.9 922.6 513 922.6s409.4-183.3 409.4-409.4S739.1 103.7 513 103.7zm153.5 364.7c-5.2 5.3-12.1 7.9-19 7.9s-13.8-2.6-19-7.9L545.1 385c0 0.4 0.1 0.7 0.1 1.1V705c0 11.1-5.7 20.9-14.4 26.6-4.7 4.2-10.9 6.7-17.7 6.7-6.8 0-13-2.5-17.7-6.7-8.7-5.7-14.4-15.5-14.4-26.6V386.1c0-0.4 0-0.7 0.1-1.1l-83.4 83.4c-10.5 10.5-27.5 10.5-38 0s-10.5-27.5 0-38L494 295.9c10.5-10.5 27.5-10.5 38 0l134.5 134.5c10.5 10.4 10.5 27.5 0 38z"/></svg>
    </button>
</div>

<?php echo Mirai_renderMobileBottomTab(); ?>
<?php if (Mirai_featureEnabled('seo') && $this->options->codeHighlight == '1' && $this->is('single')): ?>
     <?php if (strpos($this->content, '<pre') !== false): ?>
         <script src="<?php $this->options->themeUrl('assets/js/highlight.min.js'); ?>" defer></script>
     <?php endif; ?>
<?php endif; ?>
<?php if ($this->is('single') || $this->is('page') || $this->is('archive')): ?>
<script src="<?php $this->options->themeUrl('assets/js/lightbox.js'); ?>" defer></script>
<?php endif; ?>
<script src="<?php $this->options->themeUrl('assets/js/mirai.js'); ?>" defer></script>
<?php 
$frontendLoginEnabled = Mirai_featureEnabled('user_center') && (!isset($this->options->enableFrontendLogin) || $this->options->enableFrontendLogin === '1');
?>
<?php if (Mirai_featureEnabled('speed') && $this->options->instantPageEnable != '0'): ?>
<script src="<?php $this->options->themeUrl('assets/js/instantpage-5.2.0.js'); ?>" type="module"></script>
<?php endif; ?>
<?php if ($frontendLoginEnabled): ?>
<?php $this->need('modules/modal.php'); ?>
<?php endif; ?>
<?php $this->need('modules/share.php'); ?>
<?php $this->footer(); ?>
</body>
</html>