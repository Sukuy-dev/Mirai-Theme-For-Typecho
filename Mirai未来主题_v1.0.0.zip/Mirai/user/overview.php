<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit;
// 获取统计数据
$db = \Typecho\Db::get();
$prefix = $db->getPrefix();
$actionTable = Mirai_getActionsTableName($db, $prefix);

// 统计文章数（已发布的文章）
$postsCount = $db->fetchObject($db->select('COUNT(*) AS num')
    ->from('table.contents')
    ->where('authorId = ?', $this->user->uid)
    ->where('type = ?', 'post'))->num;

// 统计评论数
$commentsCount = $db->fetchObject($db->select('COUNT(*) AS num')
    ->from('table.comments')
    ->where('authorId = ?', $this->user->uid))->num;

// 统计点赞数
$likesCount = $db->fetchObject($db->select('COUNT(*) AS num')
    ->from($actionTable)
    ->where('uid = ?', $this->user->uid)
    ->where('type = ?', 'like'))->num;

// 统计收藏数
$favoritesCount = $db->fetchObject($db->select('COUNT(*) AS num')
    ->from($actionTable)
    ->where('uid = ?', $this->user->uid)
    ->where('type = ?', 'collect'))->num;
$ordersTable = Mirai_payTable('orders');
$ordersCount = 0;
if (Mirai_payTableExists($ordersTable)) {
    $ordersCount = $db->fetchObject($db->select('COUNT(*) AS num')
        ->from($ordersTable)
        ->where('uid = ?', $this->user->uid))->num;
}
$wallet = Mirai_payGetWallet((int)$this->user->uid);
$walletBalance = isset($wallet['balance']) ? (float)$wallet['balance'] : 0;
?>
<div class="user-module module-overview">
    <div class="module-header">
        <div class="module-title">仪表中心</div>
    </div>

    <div class="stats-grid">
        <div class="stat-card blue">
            <div class="stat-icon"><svg class="stat-posts-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M359 545.3V652c0 7.2 5.8 13 13 13h107.3c5.5 0 10.8-2.2 14.7-6.1l372-370.1c4-4 4-10.5 0-14.5L750.2 158.1c-2-2-4.6-3-7.3-3-2.6 0-5.2 1-7.2 3L365.1 530.7c-3.9 3.9-6.1 9.1-6.1 14.6zm51 12.6l333-334.8 58.2 58.3L466.8 614H410v-56.1z"/><path fill="currentColor" d="M858.8 512h-30.6c-5.6 0-10.2 4.6-10.2 10.2V818H206V206h295.8c5.6 0 10.2-4.6 10.2-10.2v-30.6c0-5.6-4.6-10.2-10.2-10.2h-306c-22.4 0-40.8 18.4-40.8 40.8v632.4c0 22.4 18.4 40.8 40.8 40.8h632.4c22.4 0 40.8-18.4 40.8-40.8v-306c0-5.6-4.6-10.2-10.2-10.2z"/></svg></div>
            <div class="stat-info">
                <span class="stat-value"><?php echo $postsCount; ?></span>
                <span class="stat-label">文章总数</span>
            </div>
        </div>
        <div class="stat-card green">
            <div class="stat-icon"><svg class="stat-comment-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M896 138.67H128c-38.4 0-64 25.6-64 64v544c0 38.4 25.6 64 64 64h128v128c83.2 0 166.4-44.8 256-128h384c38.4 0 64-25.6 64-64v-544c0-38.4-25.6-64-64-64zm0 608H486.4l-19.2 19.2c-51.2 51.2-102.4 83.2-147.2 96v-115.2H128v-544h768v544z"/><path fill="currentColor" d="M320 477.87m-64 0a64 64 0 1 0 128 0 64 64 0 1 0-128 0z"/><path fill="currentColor" d="M512 477.87m-64 0a64 64 0 1 0 128 0 64 64 0 1 0-128 0z"/><path fill="currentColor" d="M704 477.87m-64 0a64 64 0 1 0 128 0 64 64 0 1 0-128 0z"/></svg></div>
            <div class="stat-info">
                <span class="stat-value"><?php echo $commentsCount; ?></span>
                <span class="stat-label">评论总数</span>
            </div>
        </div>
        <div class="stat-card purple">
            <div class="stat-icon"><svg class="stat-like-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M190.193 471.412c14.446 0 26.14-11.72 26.14-26.14 0-14.445-11.694-26.164-26.14-26.164l-62.496.146c-1.426-.195-2.9-.296-4.374-.296-19.677 0-35.62 16.142-35.62 36.115v452.597c0 19.95 15.968 35.598 35.67 35.598l61.023.023c13.413-.54 24.175-11.422 24.175-24.96 0-13.56-10.76-24.442-24.175-24.982l-50.949-.001 1.45-402.276h50.266zM926.522 433.948c-19.283-31.445-47.34-44.172-81.29-45.546l-205.447-.689c13.463-39.06 22.7-85.589 22.7-129.317 0-28.35-3.194-55.963-9.042-82.543-10.638-46.579-51.736-81.315-100.966-81.315-57.264 0-95.466 48.151-95.466 106.126 0 3.242-.295 6.387 0 9.532-2.996 108.387-91.24 195.55-196.236 207.513v54.882l-.786 222.227v229.745h510.772c19.357 0 30.24-4.818 47.804-16.116 16.683-10.761 29.237-25.501 37.49-42.156l77.019-344.324c1.056-4.053 1.349-8.181 1.056-12.161-1.77-22.502-6.632-45.003-18.891-65zM893.826 486.838l-82.984 367.783c-2.555 6.142-6.88 11.596-12.872 15.427-4.177 2.727-8.774 4.351-13.415 4.964h-477.029l-.172-407.409c89.324-40.266 154.842-79.67 188.597-173.66 2.999-9.138 6.314-20.735 8.697-33.165 5.551-29.186 5.259-58.124 5.259-58.124-4.937-37.98 25.941-52.965 44.364-52.965 25.305.86 50.264 33.656 50.264 52.326 0 0 5.6 27.564 5.65 57.19.048 37.366-4.668 56.848-4.668 56.848l-.466.001c-5.873 30.879-16.215 60.138-30.465 86.964l.368.343c-2.359 4.815-3.71 10.22-3.71 15.943 0 19.923 19.089 21.742 38.766 21.742h238.762s14.666.465 14.69.465l.001.1c12.133-.638 24.222 5.207 31.1 16.41 5.505 9.016 6.438 19.604 3.487 28.988z"/></svg></div>
            <div class="stat-info">
                <span class="stat-value"><?php echo $likesCount; ?></span>
                <span class="stat-label">点赞文章</span>
            </div>
        </div>
        <div class="stat-card orange">
            <div class="stat-icon"><svg class="stat-favorites-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M512 131L604 317c20 41 59 70 105 77l206 30-149 146c-33 32-48 78-40 123l35 206-183-97c-20-11-42-16-65-16s-45 5-65 16l-183 97 35-206c8-45-7-91-40-123L110 424l205-30c46-7 85-35 105-77L512 131m0-113c-20 0-41 11-52 32L347 282c-8 17-25 29-44 32L49 350C2 357-17 415 18 449l184 180c13 13 20 32 16 51l-44 254c-6 37 24 68 57 68 9 0 18-2 27-7l227-120c8-4 18-6 27-6s18 2 27 6l227 120c8 5 18 7 27 7 34 0 63-30 57-68l-44-254c-3-19 3-38 16-51l184-180c34-33 15-92-32-98l-254-37c-19-3-35-15-44-32L564 51c-11-21-31-32-52-32z"/></svg></div>
            <div class="stat-info">
                <span class="stat-value"><?php echo $favoritesCount; ?></span>
                <span class="stat-label">收藏文章</span>
            </div>
        </div>
        <div class="stat-card blue">
            <div class="stat-icon"><svg class="stat-orders-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M953.1 518.8c-9.4 0-18.7.5-28 1.4l-1.1-420.4c0-22.1-16.7-43.9-39-43.9H231.6c5.5 12.2 13.6 26.5 13.6 40.8v830.5c0 22.1 20 37 42.3 37 1.2 0 2.5.2 3.6.4 1.2-.2 2.4-.4 3.6-.4 22.3 0 45.7-14.9 45.7-37V818.3c0-16.1 11-27.2 27.2-27.2h313.1c0 18.6 1.9 36.9 5.5 54.5H395l-.8 78.5c0 14.3-7.3 31.6-12.9 43.9h365.1c18.3 21.4 39.8 39.7 63.8 54.5H294.9c-1.2 0-2.4-.2-3.6-.4-1.2.2-2.4.4-3.6.4-54.8 0-99.3-44.2-99.3-98.5V235.3l-117.8.1h-.1c-7.8 0-15.3-3.1-20.8-8.6a28.9 28.9 0 0 1-8.6-20.6V100.5c0-53.5 42.7-97.7 96.3-99.1h746.4c54.8 0 99.3 44.2 99.3 98.5v420.5c-9.9-1.1-19.8-1.7-29.9-1.7zM190.8 96.8c0-22.1-20.7-37-43-37h-1.3s-51-7-51 37v81.7h95.3V96.8zm136.1 449.3V505.2h326.7v40.9H326.9zm0-340.4h326.7v40.9H326.9V205.7zm517.3 190.6H326.9V355.4h517.3v40.9z"/></svg></div>
            <div class="stat-info">
                <span class="stat-value"><?php echo $ordersCount; ?></span>
                <span class="stat-label">订单总数</span>
            </div>
        </div>
        <div class="stat-card green">
            <div class="stat-icon"><svg class="stat-wallet-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M866.3 85.5H157.7c-68.1 0-123.4 55.3-123.4 123.4v608.3c0 68.1 55.3 123.4 123.4 123.4h708.6c68.1 0 123.4-55.3 123.4-123.4V208.9c0-68.1-55.3-123.4-123.4-123.4zm55.3 527.4H646.1c-55.3 0-100.4-45.1-100.4-100.4s45.1-100.4 100.4-100.4H921.6v200.8zm0 204.3c0 30.2-24.6 55.3-55.3 55.3H157.7c-30.2 0-55.3-24.6-55.3-55.3V208.9c0-30.7 24.6-55.3 55.3-55.3h708.6c30.2 0 55.3 24.6 55.3 55.3v135.7H646.1c-92.7 0-168.4 75.8-168.4 168.4s75.8 168.4 168.4 168.4H921.6v135.7zm-251.4-304.1c0-24.6 20-44.5 44.5-44.5s44.5 20 44.5 44.5-20 44.5-44.5 44.5-44.5-19.5-44.5-44.5z"/></svg></div>
            <div class="stat-info">
                <span class="stat-value"><?php echo number_format($walletBalance, 2); ?></span>
                <span class="stat-label">余额</span>
            </div>
        </div>
    </div>

    <div class="recent-activity">
        <div class="section-title"><svg class="history-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M512 128c-211.7 0-384 172.3-384 384s172.3 384 384 384 384-172.3 384-384-172.3-384-384-384zm0 704c-176.7 0-320-143.3-320-320s143.3-320 320-320 320 143.3 320 320-143.3 320-320 320z"/><path fill="currentColor" d="M544 320h-64v224l192 115.2 32-51.2-160-96V320z"/></svg> 最近动态</div>
        <div class="activity-list">
            <?php
            // 获取最近发表的5篇文章
            $recentPosts = $db->fetchAll($db->select()->from('table.contents')
                ->where('authorId = ?', $this->user->uid)
                ->where('type = ?', 'post')
                ->order('created', \Typecho\Db::SORT_DESC)
                ->limit(5));
                
            if (empty($recentPosts)): ?>
                <div class="empty-state">暂无动态</div>
            <?php else: ?>
                <?php foreach ($recentPosts as $post): ?>
                    <div class="activity-item">
                        <span class="activity-icon post"><svg class="edit-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M512 128c-211.7 0-384 172.3-384 384s172.3 384 384 384 384-172.3 384-384-172.3-384-384-384zm0 704c-176.7 0-320-143.3-320-320s143.3-320 320-320 320 143.3 320 320-143.3 320-320 320z"/><path fill="currentColor" d="M672 352l-80-80-272 272v80h80l272-272zm48-48l48-48c17.7-17.7 17.7-46.3 0-64l-16-16c-17.7-17.7-46.3-17.7-64 0l-48 48 80 80z"/></svg></span>
                        <div class="activity-content">
                            <span class="activity-text">发布了文章 <a href="<?php echo \Typecho\Router::url('post', $post, $this->options->index); ?>"><?php echo $post['title']; ?></a></span>
                            <span class="activity-time"><?php echo (new \Typecho\Date($post['created']))->format('Y-m-d H:i'); ?></span>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
