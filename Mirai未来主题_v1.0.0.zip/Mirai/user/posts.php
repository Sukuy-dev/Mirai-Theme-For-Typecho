<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$db = \Typecho\Db::get();
?>
<div class="user-module module-posts">
    <div class="module-header">
        <div class="module-title">我的文章</div>
        <a href="<?php echo \Typecho\Common::url('/user/write', $this->options->index); ?>" class="btn btn-sm btn-primary btn-publish"><svg class="add-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M480 480V192h64v288h288v64H544v288h-64V544H192v-64h288z"/></svg> 发布</a>
    </div>

    <div class="post-list-table">
        <?php
        $page = isset($_GET['page']) ? intval($_GET['page']) : 1;
        $pageSize = 10;
        $offset = ($page - 1) * $pageSize;

        $posts = $db->fetchAll($db->select()->from('table.contents')
            ->where('authorId = ?', $this->user->uid)
            ->where('type = ?', 'post')
            ->order('created', \Typecho\Db::SORT_DESC)
            ->page($page, $pageSize));
            
        $total = $db->fetchObject($db->select('COUNT(cid) AS num')->from('table.contents')
            ->where('authorId = ?', $this->user->uid)
            ->where('type = ?', 'post'))->num;
        ?>

        <?php if (empty($posts)): ?>
            <div class="empty-state">你还没有发布过文章</div>
        <?php else: ?>
            <?php foreach ($posts as $post): ?>
                <div class="user-post-item">
                    <div class="post-info">
                        <div class="post-title">
                            <?php if ($post['status'] == 'publish'): ?>
                                <a href="<?php echo \Typecho\Router::url('post', $post, $this->options->index); ?>" target="_blank"><?php echo $post['title']; ?></a>
                            <?php else: ?>
                                <?php echo $post['title']; ?>
                            <?php endif; ?>
                        </div>
                        <div class="post-meta">
                            <span class="time"><?php echo (new \Typecho\Date($post['created']))->format('Y-m-d'); ?></span>
                            <span class="status status-<?php echo $post['status']; ?>">
                                <?php 
                                $statusMap = [
                                    'publish' => '已发布',
                                    'waiting' => '待审核',
                                    'hidden' => '草稿'
                                ];
                                echo isset($statusMap[$post['status']]) ? $statusMap[$post['status']] : $post['status'];
                                ?>
                            </span>
                            <span class="stats">
                                <svg class="posts-comment-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M896 138.67H128c-38.4 0-64 25.6-64 64v544c0 38.4 25.6 64 64 64h128v128c83.2 0 166.4-44.8 256-128h384c38.4 0 64-25.6 64-64v-544c0-38.4-25.6-64-64-64zm0 608H486.4l-19.2 19.2c-51.2 51.2-102.4 83.2-147.2 96v-115.2H128v-544h768v544z"/><path fill="currentColor" d="M320 477.87m-64 0a64 64 0 1 0 128 0 64 64 0 1 0-128 0z"/><path fill="currentColor" d="M512 477.87m-64 0a64 64 0 1 0 128 0 64 64 0 1 0-128 0z"/><path fill="currentColor" d="M704 477.87m-64 0a64 64 0 1 0 128 0 64 64 0 1 0-128 0z"/></svg> <?php echo $post['commentsNum']; ?>
                            </span>
                        </div>
                    </div>
                    <div class="post-actions">
                        <?php if ($post['status'] == 'publish'): ?>
                            <a href="<?php echo \Typecho\Router::url('post', $post, $this->options->index); ?>" class="btn-icon" title="查看" target="_blank"><svg class="eye-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M512 192c-211.2 0-384 160-384 320s172.8 320 384 320 384-160 384-320-172.8-320-384-320zm0 576c-176 0-320-115.2-320-256s144-256 320-256 320 115.2 320 256-144 256-320 256z"/><path fill="currentColor" d="M512 352c-70.4 0-128 57.6-128 128s57.6 128 128 128 128-57.6 128-128-57.6-128-128-128zm0 192c-35.2 0-64-28.8-64-64s28.8-64 64-64 64 28.8 64 64-28.8 64-64 64z"/></svg></a>
                        <?php endif; ?>
                        <a href="<?php echo \Typecho\Common::url('/user/write?cid=' . $post['cid'], $this->options->index); ?>" class="btn-icon" title="编辑"><svg class="edit-post-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M514 817l-193-113V1024zM1024 0L0 445l341 184L1012 18 443 683l391 212z"/></svg></a>
                    </div>
                </div>
            <?php endforeach; ?>
            
            <!-- 分页 -->
            <?php if ($total > $pageSize): ?>
                <?php 
                $totalPages = ceil($total / $pageSize);
                echo Mirai_customPagination(
                    $page,
                    $totalPages,
                    function($p) {
                        return \Typecho\Common::url('/user/posts?page=' . $p, $this->options->index);
                    }
                );
                ?>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>
