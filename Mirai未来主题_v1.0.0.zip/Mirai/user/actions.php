<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit;
/**
 * 通用用户操作模板（点赞/收藏）
 * 通过 $actionType 和 $actionData 变量传入参数
 */
if (!isset($actionType) || !isset($actionData)) return;

$db = \Typecho\Db::get();
$actionTable = Mirai_getActionsTableName($db, $db->getPrefix());

$items = $db->fetchAll($db->select('table.contents.*', 'table.users.screenName')
    ->from($actionTable)
    ->join('table.contents', $actionTable . '.gid = table.contents.cid')
    ->join('table.users', 'table.contents.authorId = table.users.uid')
    ->where($actionTable . '.uid = ?', $this->user->uid)
    ->where($actionTable . '.type = ?', $actionType)
    ->order($actionTable . '.created', \Typecho\Db::SORT_DESC));
?>
<div class="post-list-card">
    <?php if (empty($items)): ?>
        <div class="empty-state"><?php echo $actionData['emptyMsg']; ?></div>
    <?php else: ?>
        <div class="card-grid">
        <?php foreach ($items as $post): ?>
            <div class="post-card">
                <div class="post-cover">
                    <a href="<?php echo \Typecho\Router::url('post', $post, $this->options->index); ?>">
                        <img src="<?php echo Mirai_getPostCover($post); ?>" alt="<?php echo $post['title']; ?>">
                    </a>
                </div>
                <div class="post-body">
                    <div class="post-title">
                        <a href="<?php echo \Typecho\Router::url('post', $post, $this->options->index); ?>"><?php echo $post['title']; ?></a>
                    </div>
                    <div class="post-meta">
                        <span><svg class="meta-author-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M656.1 492.8a266.7 266.7 0 1 0-284.3 0C176.4 554.9 41.7 749 41.7 991.4a32 32 0 1 0 64 0c0-261.3 174.6-458.6 406.5-458.6S918.3 730.7 918.3 991.4a32 32 0 0 0 64 0c0-240.8-133-434.3-326.2-498.6zM312 266.7a202.8 202.8 0 1 1 202.8 202.8 203.1 203.1 0 0 1-202.8-202.8z"/></svg> <?php echo $post['screenName']; ?></span>
                        <span><svg class="meta-icon icon-time" viewBox="0 0 1024 1024"><path fill="currentColor" d="M512 70.4a441.6 441.6 0 1 0 0 883.2 441.6 441.6 0 0 0 0-883.2zm0 64a377.6 377.6 0 1 1 0 755.2 377.6 377.6 0 0 1 0-755.2z"/><path fill="currentColor" d="M544 480V256a32 32 0 1 0-64 0v230.4c0 31.8 25.8 57.6 57.6 57.6H768a32 32 0 1 0 0-64h-224z"/></svg> <?php echo (new \Typecho\Date($post['created']))->format('m-d'); ?></span>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>