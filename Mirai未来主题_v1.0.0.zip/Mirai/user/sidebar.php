<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$groupNames = [
    'subscriber' => '订阅者',
    'contributor' => '贡献者',
    'editor' => '编辑',
    'administrator' => '管理员'
];
$userGroup = isset($groupNames[$this->user->group]) ? $groupNames[$this->user->group] : $this->user->group;
?>
<div class="user-sidebar">
    <div class="user-info-card">
        <div class="user-info-header">
            <div class="user-avatar">
                <?php
                $avatarUrl = Mirai_getUserAvatar($this->user->uid);
                echo '<img src="' . $avatarUrl . '" alt="' . $this->user->screenName . '">';
                ?>
            </div>
            <div class="user-info-main">
                <div class="user-name"><?php $this->user->screenName(); ?></div>
                <div class="user-meta">
                    <span class="user-badge user-group">
                        <svg class="vip-crown-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M757.1 738.3H280.7L190.6 304l221.2 78.3 105.5-123.6L626 382.4 847.2 304l-90.1 434.3zm-435.7-50h395l63.8-307.5-169.3 60.1L518 335.2 427.7 441l-169.9-60.2 63.6 307.5z"/><path fill="currentColor" d="M269.6 568h490.9v50H269.6z"/></svg> <?php echo $userGroup; ?>
                    </span>
                    <span class="user-badge user-uid">
                        <svg class="uid-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M896 128H128c-35.3 0-64 28.7-64 64v640c0 35.3 28.7 64 64 64h768c35.3 0 64-28.7 64-64V192c0-35.3-28.7-64-64-64zM832 768H192V256h640v512zM320 480c-53 0-96-43-96-96s43-96 96-96 96 43 96 96-43 96-96 96zm-128 192h384v-32c0-70.7-57.3-128-128-128H320c-70.7 0-128 57.3-128 128v32z"/></svg> UID: <?php echo $this->user->uid; ?>
                    </span>
                </div>
            </div>
        </div>
    </div>

    <div class="user-menu">
        <?php
        $menuItems = [
            'overview' => ['text' => '仪表中心', 'perm' => 'subscriber'],
            'content' => ['text' => '创作中心', 'perm' => 'contributor', 'submenu' => [
                'write' => ['text' => '文章投稿'],
                'posts' => ['text' => '我的文章'],
                'wallet' => ['text' => '余额管理'],
                'income' => ['text' => '收益中心'],
            ]],
            'orders' => ['text' => '订单列表', 'perm' => 'subscriber'],
            'stats' => ['text' => '数据统计', 'perm' => 'subscriber', 'submenu' => [
                    'favorites' => ['text' => '我的收藏'],
                    'comments' => ['text' => '我的评论'],
                ]],
            'profile' => ['text' => '个人资料', 'perm' => 'subscriber'],
            'password' => ['text' => '修改密码', 'perm' => 'subscriber'],
        ];
        $userBaseUrl = \Typecho\Common::url('/user', $this->options->index);
        $currentTab = isset($tab) ? $tab : 'overview';
        ?>
        
        <?php foreach ($menuItems as $key => $item): ?>
            <?php if ($this->user->pass($item['perm'], true)): ?>
                <?php if ($key === 'profile'): ?>
                    <div class="menu-item has-submenu <?php echo ($currentTab == 'profile' || $currentTab == 'password') ? 'active' : ''; ?>" onclick="toggleSubmenu(this)">
                        <svg class="sidebar-profile-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M512 120c14.5 0 29.3 1.6 43.9 4.6 78.4 16.4 141.7 84 153.7 164.2 12.3 82-24.4 159.5-95.8 202.2-18.1 10.8-28.6 30.9-27.2 52 1.5 21.1 14.6 39.5 34.1 47.7 115.8 48.9 198.6 169 215.5 313.3H187.3c17.4-144.3 100.1-264.4 215.9-313.3 19.4-8.2 32.6-26.7 34.1-47.7 1.5-21.1-9-41.1-27.2-52-61.4-36.7-98.1-100.6-98.1-171 0-110.3 89.7-200 200-200m0-56c-141.4 0-256 114.6-256 256 0 93.5 50.6 174.4 125.5 219.1C250 594.7 151.7 731.2 131.7 897.3c-4 33.3 22.5 62.7 56 62.7h648.5c33.5 0 60-29.4 56-62.7-20-166.1-118.2-302.7-249.7-358.2 85.2-50.9 139-148.7 122.5-258.6-15.5-103.1-95.5-189.3-197.6-210.7-18.8-3.9-37.3-5.8-55.4-5.8z"/></svg>
                        <span><?php echo $item['text']; ?></span>
                        <svg class="submenu-arrow-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M512 693.33c-14.93 0-29.87-4.26-40.53-14.93L194.13 443.73c-27.73-23.47-29.87-64-8.53-89.6 23.47-27.73 64-29.87 89.6-8.53L512 546.13l236.8-200.53c27.73-23.47 68.27-19.2 89.6 8.53 23.47 27.73 19.2 68.27-8.53 89.6l-277.33 234.67c-10.67 10.66-25.6 14.93-40.53 14.93z"/></svg>
                    </div>
                    <div class="submenu <?php echo ($currentTab == 'profile' || $currentTab == 'password') ? 'show' : ''; ?>">
                        <a href="<?php echo $userBaseUrl . '/profile'; ?>" class="submenu-item <?php echo $currentTab == 'profile' ? 'active' : ''; ?>">
                            <svg class="sidebar-user-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M656.1 492.8a266.7 266.7 0 1 0-284.3 0C176.4 554.9 41.7 749 41.7 991.4a32 32 0 1 0 64 0c0-261.3 174.6-458.6 406.5-458.6S918.3 730.7 918.3 991.4a32 32 0 0 0 64 0c0-240.8-133-434.3-326.2-498.6zM312 266.7a202.8 202.8 0 1 1 202.8 202.8 203.1 203.1 0 0 1-202.8-202.8z"/></svg>
                            <span>基本资料</span>
                        </a>
                        <a href="<?php echo $userBaseUrl . '/password'; ?>" class="submenu-item <?php echo $currentTab == 'password' ? 'active' : ''; ?>">
                            <svg class="sidebar-password-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M512 570.5a58.5 58.5 0 0 0-39 102.1v53.9a39 39 0 1 0 78 0v-53.9a58.3 58.3 0 0 0 19.5-43.6 58.4 58.4 0 0 0-58.5-58.5zm272.9-175.4h-39V297.6a233.9 233.9 0 0 0-467.7 0v97.4h-39c-53.8 0-97.4 43.6-97.4 97.4V862.7c0 53.8 43.6 97.4 97.4 97.4h545.7c53.8 0 97.3-43.6 97.3-97.4V492.5c0-53.8-43.6-97.4-97.3-97.4zM512 102.7A194.9 194.9 0 0 1 706.9 297.6v97.4H317.1V297.6A195 195 0 0 1 512 102.7zm331.4 760.1c0 32.3-26.2 58.4-58.5 58.4H239.2a58.5 58.5 0 0 1-58.5-58.4V492.5c0-32.3 26.2-58.5 58.5-58.5h545.7c32.3 0 58.5 26.2 58.5 58.5v370.3z"/></svg>
                            <span>修改密码</span>
                        </a>
                    </div>
                <?php elseif ($key === 'content'): ?>
                    <div class="menu-item has-submenu <?php echo ($currentTab == 'write' || $currentTab == 'posts' || $currentTab == 'wallet' || $currentTab == 'income') ? 'active' : ''; ?>" onclick="toggleSubmenu(this)">
                        <svg class="sidebar-article-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M359 545.3V652c0 7.2 5.8 13 13 13h107.3c5.5 0 10.8-2.2 14.7-6.1l372-370.1c4-4 4-10.5 0-14.5L750.2 158.1c-2-2-4.6-3-7.3-3-2.6 0-5.2 1-7.2 3L365.1 530.7c-3.9 3.9-6.1 9.1-6.1 14.6zm51 12.6l333-334.8 58.2 58.3L466.8 614H410v-56.1z"/><path fill="currentColor" d="M858.8 512h-30.6c-5.6 0-10.2 4.6-10.2 10.2V818H206V206h295.8c5.6 0 10.2-4.6 10.2-10.2v-30.6c0-5.6-4.6-10.2-10.2-10.2h-306c-22.4 0-40.8 18.4-40.8 40.8v632.4c0 22.4 18.4 40.8 40.8 40.8h632.4c22.4 0 40.8-18.4 40.8-40.8v-306c0-5.6-4.6-10.2-10.2-10.2z"/></svg>
                        <span><?php echo $item['text']; ?></span>
                        <svg class="submenu-arrow-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M512 693.33c-14.93 0-29.87-4.26-40.53-14.93L194.13 443.73c-27.73-23.47-29.87-64-8.53-89.6 23.47-27.73 64-29.87 89.6-8.53L512 546.13l236.8-200.53c27.73-23.47 68.27-19.2 89.6 8.53 23.47 27.73 19.2 68.27-8.53 89.6l-277.33 234.67c-10.67 10.66-25.6 14.93-40.53 14.93z"/></svg>
                    </div>
                    <div class="submenu <?php echo ($currentTab == 'write' || $currentTab == 'posts' || $currentTab == 'wallet' || $currentTab == 'income') ? 'show' : ''; ?>">
                        <a href="<?php echo $userBaseUrl . '/write'; ?>" class="submenu-item <?php echo $currentTab == 'write' ? 'active' : ''; ?>">
                            <svg class="sidebar-write-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M514 817l-193-113V1024zM1024 0L0 445l341 184L1012 18 443 683l391 212z"/></svg>
                            <span>文章投稿</span>
                        </a>
                        <a href="<?php echo $userBaseUrl . '/posts'; ?>" class="submenu-item <?php echo $currentTab == 'posts' ? 'active' : ''; ?>">
                            <svg class="sidebar-posts-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M251.3 452.4h521.5v29.8H251.3v-29.8zm0 163.9h521.5v29.8H251.3v-29.8zm0 163.9h253.3v29.8H251.3V780.2zm633.2-478.8-0.2-0.2-235 236.2h-29.8l-470.5-0.1V959h744.9V340.6l0.1-0.1-0.1-39.1zM649.2 107.4l195.2 195.9-195.2 0V107.4zM854.7 929.2H169.3V94.8h450.1v208.6h0.1v14.9l235.2 0V929.2z"/></svg>
                            <span>我的文章</span>
                        </a>
                        <a href="<?php echo $userBaseUrl . '/wallet'; ?>" class="submenu-item <?php echo $currentTab == 'wallet' ? 'active' : ''; ?>">
                            <svg class="sidebar-wallet-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M866.3 85.5H157.7c-68.1 0-123.4 55.3-123.4 123.4v608.3c0 68.1 55.3 123.4 123.4 123.4h708.6c68.1 0 123.4-55.3 123.4-123.4V208.9c0-68.1-55.3-123.4-123.4-123.4zm55.3 527.4H646.1c-55.3 0-100.4-45.1-100.4-100.4s45.1-100.4 100.4-100.4H921.6v200.8zm0 204.3c0 30.2-24.6 55.3-55.3 55.3H157.7c-30.2 0-55.3-24.6-55.3-55.3V208.9c0-30.7 24.6-55.3 55.3-55.3h708.6c30.2 0 55.3 24.6 55.3 55.3v135.7H646.1c-92.7 0-168.4 75.8-168.4 168.4s75.8 168.4 168.4 168.4H921.6v135.7zm-251.4-304.1c0-24.6 20-44.5 44.5-44.5s44.5 20 44.5 44.5-20 44.5-44.5 44.5-44.5-19.5-44.5-44.5z"/></svg>
                            <span>余额管理</span>
                        </a>
                        <a href="<?php echo $userBaseUrl . '/income'; ?>" class="submenu-item <?php echo $currentTab == 'income' ? 'active' : ''; ?>">
                            <svg class="sidebar-income-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M512 1021.2c-252.8 0-458.4-156.2-458.4-348.2 0-131 101.8-318.1 257.5-413.2-24-26.4-36.9-57.3-36.9-90 0-93.6 105.2-167 239.4-167s239.4 73.4 239.4 167c0 33.3-13.3 64.5-38.1 91.2 154.7 95.4 255.7 281.9 255.7 412.1 0 192-205.7 348.1-458.6 348.1zm1.5-954.5c-95 0-175.4 47.1-175.4 102.9 0 33.7 29.4 57.7 46.9 68.9a32.1 32.1 0 0 1-3.7 56C225.9 367.4 117.6 552.5 117.6 673c0 156.7 177 284.2 394.4 284.2s394.5-127.5 394.5-284.2c0-119.8-107.8-304.4-262.3-377.7a32.1 32.1 0 0 1-3.5-56c18-11.3 48.1-35.5 48.1-69.6 0.1-55.8-80.2-103-175.4-103z"/><path fill="currentColor" d="M522.4 584.9a32.1 32.1 0 0 1-22.7-9.3l-105-105a32 32 0 0 1 45.3-45.3l105 105a32 32 0 0 1-22.6 54.6z"/><path fill="currentColor" d="M522.4 584.9a32 32 0 0 1-22.7-54.6l105-105a32 32 0 0 1 45.3 45.3l-105 105a31.9 31.9 0 0 1-22.6 9.3z"/><path fill="currentColor" d="M629.6 601.5H394.8a32 32 0 0 1 0-64h234.8a32 32 0 0 1 0 64zm0 115.3H394.8a32 32 0 0 1 0-64h234.8a32 32 0 0 1 0 64z"/><path fill="currentColor" d="M522.4 837.4a32 32 0 0 1-32-32V589.2a32 32 0 0 1 64 0v216.2a32 32 0 0 1-32 32z"/></svg>
                            <span>收益中心</span>
                        </a>
                    </div>
                <?php elseif ($key === 'stats'): ?>
                    <div class="menu-item has-submenu <?php echo ($currentTab == 'favorites' || $currentTab == 'likes' || $currentTab == 'comments') ? 'active' : ''; ?>" onclick="toggleSubmenu(this)">
                        <svg class="sidebar-stats-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M932 848H792V400c0-30.9-25.1-56-56-56H624V232c0-30.9-25.1-56-56-56H456c-30.9 0-56 25.1-56 56v336H288c-30.9 0-56 25.1-56 56v224H120V148c0-15.5-12.5-28-28-28s-28 12.5-28 28v700c0 30.9 25.1 56 56 56h812c15.5 0 28-12.5 28-28s-12.5-28-28-28zm-644 0V624h112v224H288zm168 0V232h112v616H456zm168 0V400h112v448H624z"/></svg>
                        <span><?php echo $item['text']; ?></span>
                        <svg class="submenu-arrow-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M512 693.33c-14.93 0-29.87-4.26-40.53-14.93L194.13 443.73c-27.73-23.47-29.87-64-8.53-89.6 23.47-27.73 64-29.87 89.6-8.53L512 546.13l236.8-200.53c27.73-23.47 68.27-19.2 89.6 8.53 23.47 27.73 19.2 68.27-8.53 89.6l-277.33 234.67c-10.67 10.66-25.6 14.93-40.53 14.93z"/></svg>
                    </div>
                    <div class="submenu <?php echo ($currentTab == 'favorites' || $currentTab == 'likes' || $currentTab == 'comments') ? 'show' : ''; ?>">
                        <a href="<?php echo $userBaseUrl . '/favorites'; ?>" class="submenu-item <?php echo $currentTab == 'favorites' ? 'active' : ''; ?>">
                            <svg class="sidebar-collect-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M512 131L604 317c20 41 59 70 105 77l206 30-149 146c-33 32-48 78-40 123l35 206-183-97c-20-11-42-16-65-16s-45 5-65 16l-183 97 35-206c8-45-7-91-40-123L110 424l205-30c46-7 85-35 105-77L512 131m0-113c-20 0-41 11-52 32L347 282c-8 17-25 29-44 32L49 350C2 357-17 415 18 449l184 180c13 13 20 32 16 51l-44 254c-6 37 24 68 57 68 9 0 18-2 27-7l227-120c8-4 18-6 27-6s18 2 27 6l227 120c8 5 18 7 27 7 34 0 63-30 57-68l-44-254c-3-19 3-38 16-51l184-180c34-33 15-92-32-98l-254-37c-19-3-35-15-44-32L564 51c-11-21-31-32-52-32z"/></svg>
                            <span>我的收藏</span>
                        </a>
                        <a href="<?php echo $userBaseUrl . '/likes'; ?>" class="submenu-item <?php echo $currentTab == 'likes' ? 'active' : ''; ?>">
                            <svg class="sidebar-like-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M190.193 471.412c14.446 0 26.14-11.72 26.14-26.14 0-14.445-11.694-26.164-26.14-26.164l-62.496.146c-1.426-.195-2.9-.296-4.374-.296-19.677 0-35.62 16.142-35.62 36.115v452.597c0 19.95 15.968 35.598 35.67 35.598l61.023.023c13.413-.54 24.175-11.422 24.175-24.96 0-13.56-10.76-24.442-24.175-24.982l-50.949-.001 1.45-402.276h50.266zM926.522 433.948c-19.283-31.445-47.34-44.172-81.29-45.546l-205.447-.689c13.463-39.06 22.7-85.589 22.7-129.317 0-28.35-3.194-55.963-9.042-82.543-10.638-46.579-51.736-81.315-100.966-81.315-57.264 0-95.466 48.151-95.466 106.126 0 3.242-.295 6.387 0 9.532-2.996 108.387-91.24 195.55-196.236 207.513v54.882l-.786 222.227v229.745h510.772c19.357 0 30.24-4.818 47.804-16.116 16.683-10.761 29.237-25.501 37.49-42.156l77.019-344.324c1.056-4.053 1.349-8.181 1.056-12.161-1.77-22.502-6.632-45.003-18.891-65zM893.826 486.838l-82.984 367.783c-2.555 6.142-6.88 11.596-12.872 15.427-4.177 2.727-8.774 4.351-13.415 4.964h-477.029l-.172-407.409c89.324-40.266 154.842-79.67 188.597-173.66 2.999-9.138 6.314-20.735 8.697-33.165 5.551-29.186 5.259-58.124 5.259-58.124-4.937-37.98 25.941-52.965 44.364-52.965 25.305.86 50.264 33.656 50.264 52.326 0 0 5.6 27.564 5.65 57.19.048 37.366-4.668 56.848-4.668 56.848l-.466.001c-5.873 30.879-16.215 60.138-30.465 86.964l.368.343c-2.359 4.815-3.71 10.22-3.71 15.943 0 19.923 19.089 21.742 38.766 21.742h238.762s14.666.465 14.69.465l.001.1c12.133-.638 24.222 5.207 31.1 16.41 5.505 9.016 6.438 19.604 3.487 28.988z"/></svg>
                            <span>我的点赞</span>
                        </a>
                        <a href="<?php echo $userBaseUrl . '/comments'; ?>" class="submenu-item <?php echo $currentTab == 'comments' ? 'active' : ''; ?>">
                            <svg class="sidebar-comment-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M896 138.67H128c-38.4 0-64 25.6-64 64v544c0 38.4 25.6 64 64 64h128v128c83.2 0 166.4-44.8 256-128h384c38.4 0 64-25.6 64-64v-544c0-38.4-25.6-64-64-64zm0 608H486.4l-19.2 19.2c-51.2 51.2-102.4 83.2-147.2 96v-115.2H128v-544h768v544z"/><path fill="currentColor" d="M320 477.87m-64 0a64 64 0 1 0 128 0 64 64 0 1 0-128 0z"/><path fill="currentColor" d="M512 477.87m-64 0a64 64 0 1 0 128 0 64 64 0 1 0-128 0z"/><path fill="currentColor" d="M704 477.87m-64 0a64 64 0 1 0 128 0 64 64 0 1 0-128 0z"/></svg>
                            <span>我的评论</span>
                        </a>
                    </div>
                <?php elseif ($key === 'overview'): ?>
                    <a href="<?php echo $userBaseUrl . '/' . $key; ?>" class="menu-item <?php echo $currentTab == $key ? 'active' : ''; ?>">
                        <svg class="sidebar-dashboard-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M428.8 85.3h-294.4c-27.3 0-49.1 21.8-49.1 49.1v294.4c0 27.3 21.8 49.1 49.1 49.1h294.4c27.3 0 49.1-21.8 49.1-49.1v-294.4c0-27.3-21.8-49.1-49.1-49.1zm-19.2 324.3H153.6V153.6h256v256zm480-324.3h-294.4c-27.3 0-49.1 21.8-49.1 49.1v294.4c0 27.3 21.8 49.1 49.1 49.1h294.4c27.3 0 49.1-21.8 49.1-49.1v-294.4c0-27.3-21.8-49.1-49.1-49.1zm-19.2 324.3h-256V153.6h256v256zm-441.6 134.4h-294.4c-27.3 0-49.1 21.8-49.1 49.1v294.4c0 27.3 21.8 49.1 49.1 49.1h294.4c27.3 0 49.1-21.8 49.1-49.1v-294.4c0-27.3-21.8-49.1-49.1-49.1zm-19.2 324.3H153.6v-256h256v256zm480-324.3h-294.4c-27.3 0-49.1 21.8-49.1 49.1v294.4c0 27.3 21.8 49.1 49.1 49.1h294.4c27.3 0 49.1-21.8 49.1-49.1v-294.4c0-27.3-21.8-49.1-49.1-49.1zm-19.2 324.3h-256v-256h256v256z"/></svg>
                        <span><?php echo $item['text']; ?></span>
                    </a>
                <?php elseif ($key === 'orders'): ?>
                    <a href="<?php echo $userBaseUrl . '/' . $key; ?>" class="menu-item <?php echo $currentTab == $key ? 'active' : ''; ?>">
                        <svg class="sidebar-orders-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M953.1 518.8c-9.4 0-18.7.5-28 1.4l-1.1-420.4c0-22.1-16.7-43.9-39-43.9H231.6c5.5 12.2 13.6 26.5 13.6 40.8v830.5c0 22.1 20 37 42.3 37 1.2 0 2.5.2 3.6.4 1.2-.2 2.4-.4 3.6-.4 22.3 0 45.7-14.9 45.7-37V818.3c0-16.1 11-27.2 27.2-27.2h313.1c0 18.6 1.9 36.9 5.5 54.5H395l-.8 78.5c0 14.3-7.3 31.6-12.9 43.9h365.1c18.3 21.4 39.8 39.7 63.8 54.5H294.9c-1.2 0-2.4-.2-3.6-.4-1.2.2-2.4.4-3.6.4-54.8 0-99.3-44.2-99.3-98.5V235.3l-117.8.1h-.1c-7.8 0-15.3-3.1-20.8-8.6a28.9 28.9 0 0 1-8.6-20.6V100.5c0-53.5 42.7-97.7 96.3-99.1h746.4c54.8 0 99.3 44.2 99.3 98.5v420.5c-9.9-1.1-19.8-1.7-29.9-1.7zM190.8 96.8c0-22.1-20.7-37-43-37h-1.3s-51-7-51 37v81.7h95.3V96.8zm136.1 449.3V505.2h326.7v40.9H326.9zm0-340.4h326.7v40.9H326.9V205.7zm517.3 190.6H326.9V355.4h517.3v40.9z"/></svg>
                        <span><?php echo $item['text']; ?></span>
                    </a>
                <?php elseif ($key !== 'password'): ?>
                    <a href="<?php echo $userBaseUrl . '/' . $key; ?>" class="menu-item <?php echo $currentTab == $key ? 'active' : ''; ?>">
                        <i class="<?php echo $item['icon']; ?>"></i>
                        <span><?php echo $item['text']; ?></span>
                    </a>
                <?php endif; ?>
            <?php endif; ?>
        <?php endforeach; ?>

        <a href="<?php $this->options->logoutUrl(); ?>" class="menu-item logout">
            <svg class="logout-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M896 928H384a32 32 0 0 1-32-32v-128a32 32 0 0 1 64 0v96h448v-704h-448V256a32 32 0 1 1-64 0V128a32 32 0 0 1 32-32h512a32 32 0 0 1 32 32v768a32 32 0 0 1-32 32z"/><path fill="currentColor" d="M608 544H192a32 32 0 0 1 0-64h416a32 32 0 0 1 0 64z"/><path fill="currentColor" d="M256 672a30.1 30.1 0 0 1-22.4-9.6l-128-128a30.7 30.7 0 0 1 0-44.8l128-128a31.4 31.4 0 1 1 44.8 44.8L173.4 512l105 105.6a30.7 30.7 0 0 1 0 44.8 30.1 30.1 0 0 1-22.4 9.6z"/></svg>
            <span>退出登录</span>
        </a>
    </div>
</div>
