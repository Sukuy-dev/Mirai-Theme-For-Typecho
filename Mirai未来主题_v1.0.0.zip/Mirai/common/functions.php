<?php

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

define('MIRAI_FUNCTIONS_DIR', __DIR__ . '/functions');

require_once MIRAI_FUNCTIONS_DIR . '/core.php';
require_once MIRAI_FUNCTIONS_DIR . '/helper.php';
require_once MIRAI_FUNCTIONS_DIR . '/views.php';
require_once MIRAI_FUNCTIONS_DIR . '/image.php';
require_once MIRAI_FUNCTIONS_DIR . '/content.php';
require_once MIRAI_FUNCTIONS_DIR . '/category.php';
require_once MIRAI_FUNCTIONS_DIR . '/comment.php';
require_once MIRAI_FUNCTIONS_DIR . '/post.php';
require_once MIRAI_FUNCTIONS_DIR . '/seo.php';
require_once MIRAI_FUNCTIONS_DIR . '/navigation.php';
require_once MIRAI_FUNCTIONS_DIR . '/actions.php';
require_once MIRAI_FUNCTIONS_DIR . '/email.php';
require_once MIRAI_FUNCTIONS_DIR . '/pay.php';
require_once dirname(__DIR__) . '/common/api/router.php';
require_once MIRAI_FUNCTIONS_DIR . '/recommend.php';
require_once MIRAI_FUNCTIONS_DIR . '/sidebar.php';
require_once MIRAI_FUNCTIONS_DIR . '/location.php';
require_once MIRAI_FUNCTIONS_DIR . '/links.php';