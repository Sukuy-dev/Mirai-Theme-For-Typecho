<?php
/**
 * Mirai Theme - Navigation Functions Module
 * 导航菜单函数模块
 * 
 * 包含：桌面导航、移动导航等
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

function _Mirai_getCategoryTree() {
    $db = \Typecho\Db::get();
    $categories = $db->fetchAll($db->select()->from('table.metas')
        ->where('type = ?', 'category')
        ->order('order', \Typecho\Db::SORT_ASC));
    
    $categoryMap = [];
    foreach ($categories as $category) {
        $category['children'] = [];
        $categoryMap[$category['mid']] = $category;
    }
    
    $categoryTree = [];
    foreach ($categoryMap as $category) {
        if ($category['parent'] == 0) {
            $categoryTree[] = &$categoryMap[$category['mid']];
        } else if (isset($categoryMap[$category['parent']])) {
            $categoryMap[$category['parent']]['children'][] = &$categoryMap[$category['mid']];
        }
    }
    return $categoryTree;
}

function Mirai_getNavigationMenu($type = 'desktop') {
    $options = Mirai_opt();
    $navSource = (isset($options->navSource) ? $options->navSource : 'category');
    $maxNavItems = (int)((isset($options->maxNavItems) ? $options->maxNavItems : 8));
    $navCount = 0;
    
    // Cache logic removed
    
    $html = '';
    $isMobile = ($type === 'mobile');
    
    if ($navSource == 'category' || $navSource == 'both') {
        $categoryTree = _Mirai_getCategoryTree();
        
        foreach ($categoryTree as $category):
            if ($navCount >= $maxNavItems) break;
            $navCount++;
            
            $categoryUrl = \Typecho\Router::url('category', $category, $options->index);
            $hasChildren = !empty($category['children']);
            
            if ($isMobile) {
                if ($hasChildren) {
                    $html .= '<div class="gt-mobile-nav-item has-children">';
                    $html .= '<a href="' . $categoryUrl . '" class="gt-mobile-nav-link" aria-label="' . htmlspecialchars($category['name']) . '">';
                    $html .= $category['name'];
                    $html .= '</a>';
                    
                    $html .= '<div class="gt-mobile-submenu">';
                    foreach ($category['children'] as $child) {
                        $childUrl = \Typecho\Router::url('category', $child, $options->index);
                        $html .= '<a href="' . $childUrl . '" class="gt-mobile-submenu-item" aria-label="' . htmlspecialchars($child['name']) . '">';
                        $html .= $child['name'];
                        $html .= '</a>';
                    }
                    $html .= '</div>';
                    $html .= '</div>';
                } else {
                    $html .= '<a href="' . $categoryUrl . '" class="gt-mobile-nav-link" aria-label="' . htmlspecialchars($category['name']) . '">';
                    $html .= $category['name'];
                    $html .= '</a>';
                }
            } else {
                if ($hasChildren) {
                    $html .= '<div class="nav-dropdown" aria-haspopup="true">' . "\n";
                    $html .= '<a class="nav-link gt-hover" href="' . $categoryUrl . '" aria-label="' . htmlspecialchars($category['name']) . '">';
                    $html .= $category['name'];
                    $html .= '<svg class="nav-arrow-icon" viewBox="0 0 1024 1024" aria-hidden="true"><path fill="currentColor" d="M512 693.33c-14.93 0-29.87-4.26-40.53-14.93L194.13 443.73c-27.73-23.47-29.87-64-8.53-89.6 23.47-27.73 64-29.87 89.6-8.53L512 546.13l236.8-200.53c27.73-23.47 68.27-19.2 89.6 8.53 23.47 27.73 19.2 68.27-8.53 89.6l-277.33 234.67c-10.67 10.66-25.6 14.93-40.53 14.93z"/></svg>';
                    $html .= '</a>' . "\n";
                    $html .= '<div class="nav-dropdown-menu" role="menu">' . "\n";
                    foreach ($category['children'] as $child) {
                        $childUrl = \Typecho\Router::url('category', $child, $options->index);
                        $html .= '<a class="nav-dropdown-item" href="' . $childUrl . '" role="menuitem" aria-label="' . htmlspecialchars($child['name']) . '">' . $child['name'] . '</a>' . "\n";
                    }
                    $html .= '</div>' . "\n";
                    $html .= '</div>' . "\n";
                } else {
                    $html .= '<a class="nav-link gt-hover" href="' . $categoryUrl . '" aria-label="' . htmlspecialchars($category['name']) . '">' . $category['name'] . '</a>' . "\n";
                }
            }
        endforeach;
    }
    
    if ($navSource == 'page' || $navSource == 'both') {
        $pagesWidget = \Typecho\Widget::widget('Widget_Contents_Page_List');
        while($pagesWidget->next()): 
            if ($navCount >= $maxNavItems) break;
            $navCount++;
            
            if ($isMobile) {
                // --- 移动端页面链接 ---
                $html .= '<a href="' . $pagesWidget->permalink . '" class="gt-mobile-nav-link">';
                $html .= $pagesWidget->title;
                $html .= '</a>';
            } else {

                $html .= '<a class="nav-link gt-hover" href="' . $pagesWidget->permalink . '" title="' . $pagesWidget->title . '">' . $pagesWidget->title . '</a>' . "\n";
            }
        endwhile;
    }
    
    return $html;
}

function Mirai_getMobileBottomTabItems() {
    $options = Mirai_opt();
    $items = [];

    if (empty($options->mobileBottomTabItems)) {

        $defaultItems = "首页||/\n投稿||#write\n搜索||#search\n友链||/links\n我的||#login";
        $lines = explode("\n", $defaultItems);
    } else {
        $lines = explode("\n", $options->mobileBottomTabItems);
    }

    foreach ($lines as $line) {
        $line = trim($line);
        if (empty($line)) continue;

        $parts = explode('||', $line);
        if (count($parts) >= 2) {
            $item = [
                'name' => trim($parts[0]),
                'url' => trim($parts[1]),
                'customSvg' => null
            ];
            // 如果提供了第三个字段，则使用自定义SVG
            if (count($parts) >= 3 && !empty(trim($parts[2]))) {
                $item['customSvg'] = trim($parts[2]);
            }
            $items[] = $item;
        }
    }

    return $items;
}

function Mirai_renderMobileBottomTab() {
    $options = Mirai_opt();

    if (empty($options->mobileBottomTabEnable) || $options->mobileBottomTabEnable !== '1' || !Mirai_isMobile()) {
        return '';
    }

    $items = Mirai_getMobileBottomTabItems();
    if (empty($items)) {
        return '';
    }

    $userCenterEnabled = Mirai_featureEnabled('user_center');
    $frontendLoginEnabled = $userCenterEnabled && (!isset($options->enableFrontendLogin) || $options->enableFrontendLogin === '1');

    $currentPath = Mirai_getCurrentPath();
    $html = '<nav class="gt-mobile-bottom-tab" id="mobileBottomTab">';
    $html .= '<div class="gt-mobile-bottom-tab-inner">';

    $user = \Typecho\Widget::widget('Widget_User');
    $isUserLoggedIn = $user->hasLogin();

    foreach ($items as $item) {
        $url = $item['url'];
        $isActive = false;
        $isSearch = ($url === '#search');
        $isLogin = ($url === '#login');
        $isWrite = ($url === '#write');

        if (!$isSearch && !$isLogin && !$isWrite) {
            $isActive = Mirai_isCurrentPage($url, $currentPath);
        }

        if ($isLogin && !$frontendLoginEnabled) {
            continue;
        }

        if ($isWrite && !$isUserLoggedIn && !$frontendLoginEnabled) {
            continue;
        }

        $activeClass = $isActive ? ' active' : '';
        $onclick = '';
        $finalUrl = $url;

        if ($isSearch) {
            $onclick = ' onclick="openSearch(); return false;"';
        } elseif ($isLogin) {
            $onclick = ' onclick="if(window.openLoginModal){openLoginModal();}return false;"';
        } elseif ($isWrite) {
            $writeUrl = Typecho_Common::url('user/write', $options->index);
            if ($isUserLoggedIn) {
                $finalUrl = $writeUrl;
            } else {
                $onclick = ' onclick="if(window.openLoginModal){openLoginModal();}return false;"';
            }
        }

        $html .= '<a href="' . htmlspecialchars($finalUrl) . '" class="gt-mobile-bottom-tab-item' . $activeClass . '"' . $onclick . '>';

        // 优先使用自定义SVG图标
        if (!empty($item['customSvg'])) {
            $html .= $item['customSvg'];
        } else {
            // 根据菜单名称使用内置SVG图标
            $iconName = $item['name'];
            if ($iconName === '首页') {
                $html .= '<svg class="mobile-tab-home-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M961 415L570 73a91 91 0 0 0-119 0L63 415a37 37 0 0 0-5 48 29 29 0 0 0 43 6l12-11v413c0 61 54 105 103 105h612c48 0 80-41 80-102V458l14 12a28 28 0 0 0 19 7 30 30 0 0 0 24-13 37 37 0 0 0-5-49zM603 833v71H420v-71c0-40 29-82 92-82 63 0 91 42 91 82z"/></svg>';
            } elseif ($iconName === '投稿') {
                $html .= '<svg class="mobile-tab-write-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M514 817l-193-113V1024zM1024 0L0 445l341 184L1012 18 443 683l391 212z"/></svg>';
            } elseif ($iconName === '搜索') {
                $html .= '<svg class="mobile-tab-search-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M996 860L789 653a427 427 0 1 0-136 136l207 207a96 96 0 0 0 136-136zM427 683a256 256 0 1 1 0-512 256 256 0 0 1 0 512z"/></svg>';
            } elseif ($iconName === '友链') {
                $html .= '<svg class="mobile-tab-links-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M510 0c282 0 510 228 510 510s-228 510-510 510C228 1020 0 792 0 510S228 0 510 0zm12 437a47 47 0 0 0-1 45c11 28 6 62-15 85l-110 118a67 67 0 0 1-100 0 79 79 0 0 1 0-107l41-44c12-11 17-27 14-44a43 43 0 0 0-30-33 40 40 0 0 0-41 14l-42 45a170 170 0 0 0-45 116c0 43 16 85 45 116 29 31 68 48 108 48s80-17 108-48l111-118c45-49 57-122 31-185l-1-2c0 0 0 0 0 0-7-15-20-25-35-26a41 41 0 0 0-38 21zm124-248c-41 0-80 17-108 48l-111 119c-45 49-58 122-31 184l1 2c0 0 0 0 0 0 6 15 20 25 35 26 15 1 29-7 37-21 8-13 9-31 1-45a80 80 0 0 1 15-85l111-118a67 67 0 0 1 100 0 79 79 0 0 1 0 107l-42 44 1 1c-12 10-17 27-13 43 3 16 15 29 30 33 14 4 30-1 40-13l1 0 42-45c60-64 60-168 0-232-29-31-68-48-108-48z"/></svg>';
            } elseif ($iconName === '我的') {
                $html .= '<svg class="mobile-tab-user-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M395 565C205 565 51 718 51 906v20c0 98 152 98 344 98h204c184 0 343 0 343-98v-20c0-188-154-340-343-340H395zm92-26c150 0 272-121 272-270S637 0 486 0 214 121 214 270s122 270 272 270z"/></svg>';
            } else {
                // 未匹配到内置图标时显示默认圆圈
                $html .= '<svg class="mobile-tab-default-icon" viewBox="0 0 1024 1024"><circle cx="512" cy="512" r="400" fill="none" stroke="currentColor" stroke-width="80"/></svg>';
            }
        }
        $html .= '<span>' . htmlspecialchars($item['name']) . '</span>';
        $html .= '</a>';
    }

    $html .= '</div>';
    $html .= '</nav>';

    return $html;
}

function Mirai_getCurrentPath() {
    $uri = $_SERVER['REQUEST_URI'] ?? '/';
    // 移除查询参数
    $path = explode('?', $uri)[0];
    return $path;
}

function Mirai_isCurrentPage($url, $currentPath) {
    // 提取路径部分
    if (strpos($url, '://') !== false) {
        // 完整URL
        $path = parse_url($url, PHP_URL_PATH) ?: '/';
    } else {
        // 相对路径
        $path = $url;
    }

    // 标准化路径（确保以/开头）
    if (empty($path) || $path === '') {
        $path = '/';
    }

    // 比较路径（考虑尾部斜杠的差异）
    $pathVariants = [
        $path,
        rtrim($path, '/') ?: '/',
        $path . '/',
    ];

    $currentVariants = [
        $currentPath,
        rtrim($currentPath, '/') ?: '/',
        $currentPath . '/',
    ];

    foreach ($pathVariants as $pv) {
        if (in_array($pv, $currentVariants, true)) {
            return true;
        }
    }

    return false;
}