<?php
/**
 * Mirai Theme - Views Helper Module
 * 阅读量显示工具模块
 * 
 * 提供统一的阅读量格式化、渲染和缓存功能
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

function Mirai_renderViews($views, $options = []) {
    $views = (int)$views;
    
    $defaults = [
        'showZero' => true,
        'class' => '',
        'id' => '',
        'format' => true
    ];
    $opts = array_merge($defaults, $options);
    
    // 不显示0值的情况
    if (!$opts['showZero'] && $views <= 0) {
        return '';
    }
    
    // 格式化数字
    $display = $opts['format'] ? Mirai_formatNumber($views, 'views') : $views;
    
    // 构建属性
    $attrs = [];
    if ($opts['class']) {
        $attrs['class'] = $opts['class'];
    }
    if ($opts['id']) {
        $attrs['id'] = $opts['id'];
    }
    if ($views > 0) {
        $attrs['data-views'] = $views;
    }
    
    // 构建属性字符串
    $attrStr = '';
    foreach ($attrs as $k => $v) {
        $attrStr .= ' ' . $k . '="' . htmlspecialchars($v) . '"';
    }
    
    return sprintf(
        '<span%s><svg class="views-icon" viewBox="0 0 1033 1024" fill="currentColor"><path d="M516.64 146.28c150.9 0 278.93 67.4 384 178.58a775.3 775.3 0 0 1 116.3 160.62 357.6 357.6 0 0 1 8.27 16.13l8.04 17.22-9.47 16.49a402 402 0 0 1-9.44 15.36 906.72 906.72 0 0 1-125.92 154.55c-109.6 107.38-234.2 172.48-371.78 172.48-137.58 0-262.18-65.1-371.78-172.48a906.87 906.87 0 0 1-125.92-154.48 416.76 416.76 0 0 1-9.44-15.36L0 518.88l8.08-17.19C13.57 489.95 24.06 470.34 39.64 445.51a775.22 775.22 0 0 1 93-120.65c105.07-111.18 233.1-178.58 384-178.58zm415.05 338.03a703.31 703.31 0 0 0-84.22-109.2c-92.38-97.72-202.46-155.68-330.82-155.68s-238.45 57.96-330.83 155.68a702.97 702.97 0 0 0-102.55 140.36 834.43 834.43 0 0 0 112.79 137.5c97.13 95.24 205.09 151.59 320.58 151.59 115.5 0 223.45-56.39 320.58-151.55a834.39 834.39 0 0 0 112.78-137.54 630.06 630.06 0 0 0-18.31-31.16zm-415.05-155.17c100.24 0 182.86 82.62 182.86 182.86 0 101.08-80.71 182.86-182.86 182.86-101.08 0-182.86-80.72-182.86-182.86 0-101.08 80.71-182.86 182.86-182.86zm0 73.14c-61.55 0-109.72 48.79-109.72 109.72 0 61.55 48.79 109.72 109.72 109.72 61.55 0 109.72-48.78 109.72-109.72 0-59.83-49.88-109.72-109.72-109.72z"/></svg>%s</span>',
        $attrStr,
        $display
    );
}

function Mirai_calculateTotalViews($posts) {
    if (empty($posts)) {
        return 0;
    }
    
    $total = 0;
    foreach ($posts as $post) {
        $total += (int)($post['views'] ?? 0);
    }
    
    return $total;
}