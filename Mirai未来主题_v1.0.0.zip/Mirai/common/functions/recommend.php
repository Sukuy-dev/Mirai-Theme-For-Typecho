<?php
/**
 * Mirai Theme - Recommend Functions Module
 * 推荐模块函数
 * 
 * 包含：推荐文章获取、推荐区域渲染等
 */
 
function Mirai_getRecommendPost($cid) {
    $cid = (int)$cid;
    if ($cid <= 0) return null;
    
    $db = \Typecho\Db::get();
    $post = $db->fetchRow($db->select()->from('table.contents')
        ->where('cid = ?', $cid)
        ->where('status = ?', 'publish')
        ->where('type = ?', 'post'));
        
    if ($post) {
        $post['category'] = Mirai_getPostCategory($post['cid']);
        $post['permalink'] = \Typecho\Router::url('post', $post, Mirai_opt()->index);
        return $post;
    }
    
    return null;
}

function Mirai_getRecommendPosts($widget, $limit = 7) {
    $db = \Typecho\Db::get();
    
    // 从主题选项获取推荐文章ID
    $options = $widget->options;
    $recommendIds = [];
    
    // 收集所有推荐位ID
    $fields = [
        'recommendTopLeft',
        'recommendTopRight1',
        'recommendTopRight2',
        'recommendBottom1',
        'recommendBottom2',
        'recommendBottom3',
        'recommendBottom4'
    ];
    
    foreach ($fields as $field) {
        if (!empty($options->$field)) {
            $recommendIds[] = $options->$field;
        }
    }
    
    $posts = [];
    
    if (!empty($recommendIds)) {
        // 过滤非数字ID
        $ids = array_filter($recommendIds, 'is_numeric');
        
        if (!empty($ids)) {
            $query = $db->select()->from('table.contents')
                ->where('cid IN ?', $ids)
                ->where('status = ?', 'publish')
                ->where('type = ?', 'post');
            
            $result = $db->fetchAll($query);
            
            if ($result) {
                // 将结果按ID键值对存储，方便排序
                $tempPosts = [];
                foreach ($result as $row) {
                    $tempPosts[$row['cid']] = $row;
                }
                
                // 按配置顺序重新组装
                foreach ($ids as $cid) {
                    if (isset($tempPosts[$cid])) {
                        $posts[] = $tempPosts[$cid];
                    }
                }
            }
        }
    }
    
    // 如果推荐文章不足，用最新文章补充
    if (count($posts) < $limit) {
        $need = $limit - count($posts);
        $existingIds = array_column($posts, 'cid');
        
        $query = $db->select()->from('table.contents')
            ->where('status = ?', 'publish')
            ->where('type = ?', 'post')
            ->order('created', \Typecho\Db::SORT_DESC)
            ->limit($need);
        
        if (!empty($existingIds)) {
            $query->where('cid NOT IN ?', $existingIds);
        }
        
        $result = $db->fetchAll($query);
        
        if ($result) {
            foreach ($result as $row) {
                $posts[] = $row;
            }
        }
    }

    if (!empty($posts)) {
        $cids = array_column($posts, 'cid');
        $categoryData = $db->fetchAll(
            $db->select('table.relationships.cid', 'table.metas.slug')
                ->from('table.relationships')
                ->join('table.metas', 'table.relationships.mid = table.metas.mid', \Typecho\Db::LEFT_JOIN)
                ->where('table.relationships.cid IN ?', $cids)
                ->where('table.metas.type = ?', 'category')
        );
        
        $categoryMap = [];
        foreach ($categoryData as $cat) {
            if (!isset($categoryMap[$cat['cid']])) {
                $categoryMap[$cat['cid']] = $cat['slug'];
            }
        }
        
        foreach ($posts as &$post) {
            $post['category'] = $categoryMap[$post['cid']] ?? null;
        }
        unset($post);
    }
    
    return $posts;
}