<?php
/**
 * Mirai Theme - Actions Functions Module
 * 点赞收藏功能模块
 * 
 * 包含：点赞、收藏状态检查等
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

function Mirai_getActionsTableName($db, $prefix) {
    return $prefix . 'mirai_actions';
}

function Mirai_isLiked($gid, $uid) {
    static $cache = [];
    $gid = (int)$gid;
    $uid = (int)$uid;
    $cacheKey = $gid . '_' . $uid;
    
    if (isset($cache[$cacheKey])) {
        return $cache[$cacheKey];
    }
    
    // 对于未登录用户，使用cookie记录
    if (empty($uid)) {
        $cookieName = 'mirai_liked_' . $gid;
        $cache[$cacheKey] = isset($_COOKIE[$cookieName]) && $_COOKIE[$cookieName] === '1';
        return $cache[$cacheKey];
    }
    try {
        $db = \Typecho\Db::get();
        $actionsTable = Mirai_getActionsTableName($db, $db->getPrefix());
        $tableExists = $db->fetchRow($db->query("SHOW TABLES LIKE '" . $actionsTable . "'"));
        if (!$tableExists) {
            $cache[$cacheKey] = false;
            return false;
        }
        
        $count = $db->fetchObject($db->select('COUNT(*) AS count')
            ->from($actionsTable)
            ->where('gid = ?', $gid)
            ->where('type = ?', 'like')
            ->where('uid = ?', $uid))->count;
        
        $cache[$cacheKey] = $count > 0;
        return $cache[$cacheKey];
    } catch (Exception $e) {
        $cache[$cacheKey] = false;
        return false;
    }
}

function Mirai_isCollected($gid, $uid) {
    static $cache = [];
    $gid = (int)$gid;
    $uid = (int)$uid;
    $cacheKey = $gid . '_' . $uid;
    
    if (isset($cache[$cacheKey])) {
        return $cache[$cacheKey];
    }
    
    // 未登录用户无法收藏
    if (empty($uid)) {
        $cache[$cacheKey] = false;
        return false;
    }
    
    try {
        $db = \Typecho\Db::get();
        $actionsTable = Mirai_getActionsTableName($db, $db->getPrefix());
        
        // 检查actions表是否存在
        $tableExists = $db->fetchRow($db->query("SHOW TABLES LIKE '" . $actionsTable . "'"));
        if (!$tableExists) {
            $cache[$cacheKey] = false;
            return false;
        }
        
        $count = $db->fetchObject($db->select('COUNT(*) AS count')
            ->from($actionsTable)
            ->where('gid = ?', $gid)
            ->where('type = ?', 'collect')
            ->where('uid = ?', $uid))->count;
        
        $cache[$cacheKey] = $count > 0;
        return $cache[$cacheKey];
    } catch (Exception $e) {
        $cache[$cacheKey] = false;
        return false;
    }
}
