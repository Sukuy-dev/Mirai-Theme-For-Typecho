<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

function Mirai_payFieldsByCid($cid) {
    static $cache = [];
    $cid = (int)$cid;
    if ($cid <= 0) {
        return [];
    }
    if (isset($cache[$cid])) {
        return $cache[$cid];
    }
    $db = \Typecho\Db::get();
    $rows = $db->fetchAll($db->select()->from('table.fields')->where('cid = ?', $cid));
    $data = [];
    foreach ($rows as $row) {
        $name = isset($row['name']) ? (string)$row['name'] : '';
        if ($name === '') {
            continue;
        }
        $value = '';
        if (isset($row['str_value']) && $row['str_value'] !== null && $row['str_value'] !== '') {
            $value = (string)$row['str_value'];
        } elseif (isset($row['int_value']) && $row['int_value'] !== null) {
            $value = (string)$row['int_value'];
        } elseif (isset($row['float_value']) && $row['float_value'] !== null) {
            $value = (string)$row['float_value'];
        }
        $data[$name] = $value;
    }
    $cache[$cid] = $data;
    return $cache[$cid];
}

function Mirai_payPostSettings($cid) {
    $fields = Mirai_payFieldsByCid($cid);
    $pick = function(array $keys, $default = '') use ($fields) {
        foreach ($keys as $key) {
            if (isset($fields[$key]) && trim((string)$fields[$key]) !== '') {
                return $fields[$key];
            }
        }
        return $default;
    };
    $mode = trim((string)$pick(['pay_mode', 'payMode'], 'none'));
    if (!in_array($mode, ['none', 'read', 'partial'], true)) {
        $mode = 'none';
    }
    $price = Mirai_payNormalizeAmount($pick(['pay_price', 'payPrice'], 0));
    $commission = (float)$pick(['pay_commission_rate', 'payCommissionRate'], -1);
    $loginRequired = trim((string)$pick(['pay_login_required', 'payLoginRequired'], '1'));
    $purchaseMethod = trim((string)$pick(['pay_purchase_method', 'payPurchaseMethod'], 'both'));
    if (!in_array($purchaseMethod, ['both', 'online', 'balance'], true)) {
        $purchaseMethod = 'both';
    }
    return [
        'mode' => $mode,
        'price' => round(max(0, $price), 2),
        'commission_rate' => $commission,
        'login_required' => $loginRequired === '1',
        'purchase_method' => $purchaseMethod,
    ];
}

function Mirai_payAvailableForPost($settings) {
    if (!is_array($settings)) {
        return false;
    }
    $mode = isset($settings['mode']) ? (string)$settings['mode'] : 'none';
    if ($mode === 'none') {
        return false;
    }
    $price = isset($settings['price']) ? (float)$settings['price'] : 0;
    return $price > 0;
}

function Mirai_payAvailableMethodsForPost($settings, $uid = 0) {
    $uid = (int)$uid;
    $allMethods = Mirai_payMethods();
    $purchaseMethod = isset($settings['purchase_method']) ? (string)$settings['purchase_method'] : 'both';
    $methods = [];
    foreach ($allMethods as $method) {
        if ($purchaseMethod === 'online' && $method === 'balance') {
            continue;
        }
        if ($purchaseMethod === 'balance' && $method !== 'balance') {
            continue;
        }
        if ($uid <= 0 && $method === 'balance') {
            continue;
        }
        $methods[] = $method;
    }
    return array_values(array_unique($methods));
}

function Mirai_payHasPaid($cid, $uid = 0) {
    static $cache = [];
    $cid = (int)$cid;
    $uid = (int)$uid;
    if ($cid <= 0) {
        return false;
    }
    $cacheKey = $cid . '_' . $uid;
    if (isset($cache[$cacheKey])) {
        return $cache[$cacheKey];
    }

    $db = \Typecho\Db::get();
    $ordersTable = Mirai_payTable('orders');
    if (!Mirai_payDbCheck()) {
        $cache[$cacheKey] = false;
        return false;
    }
    if ($uid > 0) {
        $row = $db->fetchRow($db->select('id')->from($ordersTable)->where('cid = ?', $cid)->where('uid = ?', $uid)->where('status = ?', 'paid')->limit(1));
        $cache[$cacheKey] = !empty($row);
        return $cache[$cacheKey];
    }
    $guestToken = Mirai_payGuestToken();
    $currentIp = Mirai_getClientIp();
    if ($currentIp === '') {
        $cache[$cacheKey] = false;
        return false;
    }
    $orders = $db->fetchAll($db->select('meta')->from($ordersTable)->where('cid = ?', $cid)->where('guest_token = ?', $guestToken)->where('status = ?', 'paid'));
    foreach ($orders as $order) {
        $meta = Mirai_payOrderMeta($order);
        $orderIp = isset($meta['ip']) ? (string)$meta['ip'] : '';
        if ($orderIp !== '' && $orderIp === $currentIp) {
            $cache[$cacheKey] = true;
            return true;
        }
    }
    $cache[$cacheKey] = false;
    return false;
}

function Mirai_payUnwrapShortcode($content) {
    return preg_replace('/\[pay\]([\s\S]*?)\[\/pay\]/i', '$1', (string)$content);
}

function Mirai_payFilterPostContent($content, $widget, $canAccess) {
    $content = (string)$content;
    $rawContent = $content;
    $settings = Mirai_payPostSettings($widget->cid);
    if (!$canAccess && isset($widget->user, $widget->authorId) && (int)$widget->user->uid > 0 && (int)$widget->user->uid === (int)$widget->authorId) {
        $canAccess = true;
    }
    $plainContent = Mirai_payUnwrapShortcode($content);
    $inlineToken = '<!--MIRAI_PAYBOX_INLINE-->';
    if (!Mirai_payAvailableForPost($settings)) {
        return ['content' => $plainContent, 'locked' => false, 'settings' => $settings, 'inline' => false];
    }
    if ($canAccess) {
        return ['content' => $plainContent, 'locked' => false, 'settings' => $settings, 'inline' => false];
    }
    if ($settings['mode'] === 'partial') {
        if (preg_match('/\[pay\][\s\S]*?\[\/pay\]/i', $rawContent)) {
            $replaceFirst = '<div class="mirai-pay-lock-placeholder"></div>' . $inlineToken;
            $content = preg_replace('/\[pay\][\s\S]*?\[\/pay\]/i', $replaceFirst, $rawContent, 1);
            $content = preg_replace('/\[pay\][\s\S]*?\[\/pay\]/i', '<div class="mirai-pay-lock-placeholder"></div>', $content);
        } else {
            return ['content' => $plainContent, 'locked' => false, 'settings' => $settings, 'inline' => false];
        }
        return ['content' => $content, 'locked' => true, 'settings' => $settings, 'inline' => true];
    }
    if ($settings['mode'] === 'read') {
        $content = $inlineToken;
        return ['content' => $content, 'locked' => true, 'settings' => $settings, 'inline' => true];
    }
    return ['content' => $plainContent, 'locked' => false, 'settings' => $settings, 'inline' => false];
}

function Mirai_payRenderBoxHead($settings, $layout, $title = '') {
    $html = '<fieldset class="mirai-paybox mirai-paybox-' . htmlspecialchars($layout, ENT_QUOTES, 'UTF-8') . '">';
    if ($title !== '') {
        $html .= '<legend class="mirai-paybox-title">' . $title . '</legend>';
    }
    return $html;
}

function Mirai_payRenderPurchaseBox($widget, $settings, $uid, $token, $layout = 'default') {
    if (!Mirai_payAvailableForPost($settings)) {
        return '';
    }
    if ($uid > 0 && isset($widget->authorId) && (int)$widget->authorId === (int)$uid) {
        return '';
    }
    $hasPaid = Mirai_payHasPaid($widget->cid, $uid);
    $balance = $uid > 0 ? (float)Mirai_payGetWallet($uid)['balance'] : 0;
    $methods = Mirai_payAvailableMethodsForPost($settings, $uid);
    $displayPrice = max(0, Mirai_payNormalizeAmount(isset($settings['price']) ? $settings['price'] : 0));
    $payNotice = trim((string)Mirai_payGetOption('payNotice', ''));
    
    $options = Mirai_opt();
    $userCenterEnabled = Mirai_featureEnabled('user_center');
    $frontendLoginEnabled = $userCenterEnabled && (!isset($options->enableFrontendLogin) || $options->enableFrontendLogin === '1');
    
    if ($hasPaid) {
        $html = Mirai_payRenderBoxHead($settings, $layout, '你已购买当前内容');
    } else {
        if ($frontendLoginEnabled) {
            $loginBtn = '<button type="button" class="btn btn-primary" onclick="if(window.openLoginModal){openLoginModal();}return false;">立即登录</button>';
        } else {
            $loginBtn = '<p style="color:#666;font-size:14px;">当前站点未启用登录功能，请联系站长</p>';
        }

        $needLoginCases = [
            ['condition' => $settings['login_required'] && $uid <= 0, 'title' => '该内容需要登录后购买'],
            ['condition' => $settings['purchase_method'] === 'balance' && $uid <= 0, 'title' => '该文章仅支持余额购买，请先登录'],
            ['condition' => $uid <= 0 && !Mirai_payGuestAllowed(), 'title' => '当前仅支持登录用户购买'],
        ];

        foreach ($needLoginCases as $case) {
            if ($case['condition']) {
                $html = Mirai_payRenderBoxHead($settings, $layout, $case['title']);
                if ($payNotice !== '') {
                    $html .= '<div class="mirai-paybox-desc">' . nl2br(htmlspecialchars($payNotice, ENT_QUOTES, 'UTF-8')) . '</div>';
                }
                $html .= '<div class="mirai-paybox-actions" style="margin-top:16px;text-align:center;">';
                $html .= $loginBtn;
                $html .= '</div>';
                $html .= '</fieldset>';
                return $html;
            }
        }

        if ($settings['mode'] === 'read') {
            $boxTitle = '本文为付费阅读内容';
        } else {
            $boxTitle = '此部分内容需要付费后阅读';
        }
        $html = Mirai_payRenderBoxHead($settings, $layout, $boxTitle);
        if ($payNotice !== '') {
            $html .= '<div class="mirai-paybox-desc">' . nl2br(htmlspecialchars($payNotice, ENT_QUOTES, 'UTF-8')) . '</div>';
        }

        $iconBaseUrl = Mirai_getThemeUrl() . '/assets/images/';
        $methodData = [];
        foreach ($methods as $method) {
            $iconMap = [
                'wechat' => 'wechat-pay.svg',
                'alipay' => 'alipay.svg',
                'qq' => 'QQ-Pay.svg',
                'balance' => 'balance.svg'
            ];
            $iconFile = isset($iconMap[$method]) ? $iconMap[$method] : '';
            $methodData[] = [
                'value' => $method,
                'label' => Mirai_payMethodLabel($method),
                'icon' => $iconFile ? ($iconBaseUrl . $iconFile) : ''
            ];
        }
        $orderTypeLabel = $settings['mode'] === 'read' ? '付费阅读' : '付费内容';
        $orderTitle = isset($widget->title) ? $widget->title : '付费内容';
        $html .= '<form class="mirai-pay-form mirai-pay-form-post" method="post" action="' . htmlspecialchars(Mirai_payBuildApiUrl('pay_create_order'), ENT_QUOTES, 'UTF-8') . '" target="_self" data-pay-methods="' . htmlspecialchars(json_encode($methodData), ENT_QUOTES, 'UTF-8') . '" data-order-type-label="' . htmlspecialchars($orderTypeLabel, ENT_QUOTES, 'UTF-8') . '" data-order-title="' . htmlspecialchars($orderTitle, ENT_QUOTES, 'UTF-8') . '">';
        $html .= '<input type="hidden" name="token" value="' . htmlspecialchars($token, ENT_QUOTES, 'UTF-8') . '">';
        $html .= '<input type="hidden" name="cid" value="' . (int)$widget->cid . '">';
        $html .= '<input type="hidden" name="order_type" value="' . htmlspecialchars($settings['mode'], ENT_QUOTES, 'UTF-8') . '">';
        $html .= '<input type="hidden" name="payment_method" value="' . htmlspecialchars(isset($methods[0]) ? (string)$methods[0] : '', ENT_QUOTES, 'UTF-8') . '">';
        $html .= '<input type="hidden" name="amount" value="' . htmlspecialchars(number_format($displayPrice, 2, '.', ''), ENT_QUOTES, 'UTF-8') . '">';
        if (empty($methods)) {
            $html .= '<div class="mirai-paybox-empty" style="color:#f59e0b;font-size:14px;text-align:center;font-weight:500;">当前文章暂无可用支付方式</div>';
            $html .= '</form>';
            $html .= '</fieldset>';
            return $html;
        }
        $html .= '<div class="mirai-paybox-row">';
        $html .= '<button type="submit" class="btn btn-primary mirai-paybox-submit"><span class="mirai-paybox-submit-price"><strong>' . number_format($displayPrice, 2) . '</strong><span>元</span></span><span class="mirai-paybox-submit-text">立即解锁</span></button>';
        $html .= '</div>';
        $html .= '</form>';
    }
    $html .= '</fieldset>';
    return $html;
}
