<?php
/**
 * Mirai Theme - Sidebar Functions Module
 * 侧边栏渲染函数模块
 *
 * 包含：侧边栏数据获取、文章列表、评论、管理员信息、标签云等渲染函数
 * 以及移动端侧边栏小工具渲染函数
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

function Mirai_getSidebarHotPosts($limit = 5) {
    $db = \Typecho\Db::get();
    $limit = (int)$limit;
    $select = $db->select('cid', 'title', 'slug', 'text', 'created', 'cover', 'authorId', 'views')
        ->from('table.contents')
        ->where('status = ?', 'publish')
        ->where('type = ?', 'post')
        ->where('created <= ?', time())
        ->order('views', \Typecho\Db::SORT_DESC)
        ->limit($limit);
    
    $posts = $db->fetchAll($select);
    
    if (empty($posts)) {
        return [];
    }
    
    $cids = array_column($posts, 'cid');

    $categoryData = $db->fetchAll(
        $db->select('table.relationships.cid', 'table.metas.slug')
            ->from('table.relationships')
            ->join('table.metas', 'table.relationships.mid = table.metas.mid', \Typecho\Db::LEFT_JOIN)
            ->where('table.relationships.cid IN ?', $cids)
            ->where('table.metas.type = ?', 'category')
    );
    
    $categoryMap = [];
    foreach ($categoryData as $cat) {
        if (!isset($categoryMap[$cat['cid']])) {
            $categoryMap[$cat['cid']] = $cat['slug'];
        }
    }
    
    $options = Mirai_opt()->index;
    $hotPosts = [];
    foreach ($posts as $row) {
        $row['category'] = $categoryMap[$row['cid']] ?? null;
        $row['permalink'] = \Typecho\Router::url('post', $row, $options);
        $hotPosts[] = $row;
    }
    
    return $hotPosts;
}

function Mirai_getSidebarRecentPosts($limit = 5) {
    $db = \Typecho\Db::get();
    $limit = (int)$limit;
    
    $select = $db->select('cid', 'title', 'slug', 'created', 'text', 'cover', 'authorId', 'views')
        ->from('table.contents')
        ->where('type = ?', 'post')
        ->where('status = ?', 'publish')
        ->where('created <= ?', time())
        ->order('created', \Typecho\Db::SORT_DESC)
        ->limit($limit);
    
    $posts = $db->fetchAll($select);
    
    if (empty($posts)) {
        return [];
    }
    
    $cids = array_column($posts, 'cid');
    
    // 批量获取分类信息
    $categoryData = $db->fetchAll(
        $db->select('table.relationships.cid', 'table.metas.slug')
            ->from('table.relationships')
            ->join('table.metas', 'table.relationships.mid = table.metas.mid', \Typecho\Db::LEFT_JOIN)
            ->where('table.relationships.cid IN ?', $cids)
            ->where('table.metas.type = ?', 'category')
    );
    
    $categoryMap = [];
    foreach ($categoryData as $cat) {
        if (!isset($categoryMap[$cat['cid']])) {
            $categoryMap[$cat['cid']] = $cat['slug'];
        }
    }
    
    $options = Mirai_opt()->index;
    $recentPosts = [];
    foreach ($posts as $row) {
        $row['category'] = $categoryMap[$row['cid']] ?? null;
        $row['permalink'] = \Typecho\Router::url('post', $row, $options);
        $recentPosts[] = $row;
    }
    
    return $recentPosts;
}

function Mirai_getSidebarTags($limit = 30, $sort = 'mid') {
    $db = \Typecho\Db::get();
    
    $select = $db->select('mid', 'name', 'slug', 'count')->from('table.metas')
        ->where('type = ?', 'tag')
        ->where('count > ?', 0);
        
    if ($sort == 'count') {
        $select->order('count', \Typecho\Db::SORT_DESC);
    } else if ($sort == 'rand') {
        $select->order('RAND()');
    } else if ($sort == 'name') {
        $select->order('name', \Typecho\Db::SORT_ASC);
    } else {
        $select->order('mid', \Typecho\Db::SORT_DESC);
    }
    
    $select->limit($limit);
    
    $tags = $db->fetchAll($select);
    
    $data = [];
    $options = Mirai_opt();
    foreach ($tags as $tag) {
        $tag['permalink'] = \Typecho\Router::url('tag', $tag, $options->index);
        $data[] = $tag;
    }
    
    return $data;
}

function Mirai_getSidebarRecentComments() {
    $options = Mirai_opt();
    $limit = intval($options->commentsListSize ?? 10);
    
    $commentsWidget = \Widget\Comments\Recent::alloc(['pageSize' => $limit]);
    
    $data = [];
    while ($commentsWidget->next()) {
        $avatar = Mirai_getUserAvatar($commentsWidget->authorId);

        $data[] = [
            'coid' => $commentsWidget->coid,
            'cid' => $commentsWidget->cid,
            'author' => $commentsWidget->author,
            'authorId' => $commentsWidget->authorId,
            'mail' => $commentsWidget->mail,
            'url' => $commentsWidget->url,
            'text' => $commentsWidget->text,
            'created' => $commentsWidget->created,
            'permalink' => $commentsWidget->permalink,
            'title' => $commentsWidget->title,
            'avatar' => $avatar,
        ];
    }
    
    return $data;
}

function Mirai_getSidebarAdminInfo() {
    $options = Mirai_opt();
    $adminBio = $options->adminBio;

    $db = \Typecho\Db::get();
    $admin = $db->fetchRow($db->select()->from('table.users')->where('group = ?', 'administrator')->limit(1));

    $adminName = $admin['screenName'] ?? '管理员';
    $adminUid = $admin['uid'] ?? 0;
    if (empty($adminBio)) $adminBio = $admin['bio'] ?? '这里什么也没写。';

    $avatarUrl = Mirai_getUserAvatar($adminUid);
    
    return [
        'name' => $adminName,
        'bio' => $adminBio,
        'avatar' => $avatarUrl
    ];
}

if (!function_exists('Mirai_getSidebarIcon')) {
    function Mirai_getSidebarIcon($icon) {
        if ($icon === 'hot') {
            return '<svg class="aside-icon-hot" viewBox="0 0 1024 1024"><path fill="#F2474A" d="M394.24 776.19c-41.47-86.02-19.46-135.68 12.29-182.27 34.82-51.2 44.03-101.38 44.03-101.38s27.65 35.84 16.38 91.14c48.64-53.76 57.34-139.78 50.18-172.54 109.57 76.29 156.16 242.18 93.18 365.06 335.36-189.95 83.46-473.6 39.42-505.86 14.85 31.74 17.41 86.02-12.29 112.64-50.18-189.44-173.57-228.35-173.57-228.35 14.85 97.79-53.25 204.8-118.27 284.67-2.05-38.91-4.61-66.05-25.09-103.42-4.61 70.66-58.88 128.51-73.22 199.68-19.97 96.26 14.85 166.4 146.94 240.64z"/></svg>';
        } elseif ($icon === 'recent') {
            return '<svg class="aside-icon-recent" viewBox="0 0 1024 1024"><path fill="#FF6E00" d="M791.32 64H232.68c-53.74 0-97.45 42.97-97.45 95.76v704.48c0 52.79 43.72 95.76 97.45 95.76h558.65c53.74 0 97.45-42.97 97.45-95.76V159.76c0-52.79-43.72-95.76-97.45-95.76zM268.6 241.55h319.23c12.41 0 22.48 9.86 22.48 22.11 0 12.17-10.06 22.06-22.48 22.06H268.6c-12.41 0-22.48-9.9-22.48-22.06 0-12.25 10.06-22.11 22.48-22.11zm469.13 553.96H268.6c-12.41 0-22.48-9.9-22.48-22.11s10.06-22.11 22.48-22.11h469.13c12.41 0 22.52 9.9 22.52 22.11s-10.1 22.11-22.52 22.11zm0-169.93H268.6c-12.41 0-22.48-9.9-22.48-22.11s10.06-22.11 22.48-22.11h469.13c12.41 0 22.52 9.9 22.52 22.11s-10.1 22.11-22.52 22.11zm0-169.92H268.6c-12.41 0-22.48-9.88-22.48-22.08 0-12.23 10.06-22.13 22.48-22.13h469.13c12.41 0 22.52 9.9 22.52 22.13 0 12.21-10.1 22.08-22.52 22.08z"/></svg>';
        }
        return '<i class="' . $icon . '"></i>';
    }
}

if (!function_exists('renderSidebarArticleList')) {
    function renderSidebarArticleList($posts, $title, $icon, $index = 0, $style = 'cover') {
        if (empty($posts)) {
            return;
        }
        
        $style = in_array($style, ['cover', 'text']) ? $style : 'cover';
        $delay = ($index + 1) * 0.08;
        
        if ($style === 'text') {
            renderSidebarTextArticleList($posts, $title, $icon, $delay);
            return;
        }
        
        ?>
        <section class="gt-aside-item articles gt-animation gt-animation-init" style="animation-delay: <?php echo $delay; ?>s;">
            <div class="sky-h3"><?php echo Mirai_getSidebarIcon($icon); ?> <?php echo $title; ?></div>
            <div class="gt-aside-articles gt-aside-articles-cover">
                <?php 
                $lazyLoading = Mirai_getDefaultLazyLoading();
                foreach ($posts as $post):
                    $cover = Mirai_getPostCover($post, true);
                ?>
                    <a href="<?php echo $post['permalink']; ?>" class="gt-aside-article-item">
                        <div class="gt-aside-article-cover">
                            <?php echo Mirai_generatePictureTag($cover, $lazyLoading, $post['title'], 'gt-aside-article-img', '', '', ['context' => 'aside-article']); ?>
                            <div class="gt-aside-article-info">
                                <div class="gt-aside-article-title"><?php echo $post['title']; ?></div>
                                <div class="gt-aside-article-meta">
                                    <?php echo Mirai_renderViews($post['views'], ['class' => 'gt-aside-article-views']); ?>
                                    <span class="gt-aside-article-time"><?php echo (new \Typecho\Date($post['created']))->format('Y-m-d'); ?></span>
                                </div>
                            </div>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        </section>
        <?php
    }
}

if (!function_exists('renderSidebarTextArticleList')) {
    function renderSidebarTextArticleList($posts, $title, $icon, $delay = 0.08) {
        ?>
        <section class="gt-aside-item articles gt-animation gt-animation-init" style="animation-delay: <?php echo $delay; ?>s;">
            <div class="sky-h3"><?php echo Mirai_getSidebarIcon($icon); ?> <?php echo $title; ?></div>
            <div class="gt-aside-articles gt-aside-articles-text">
                <?php foreach ($posts as $index => $post): ?>
                    <a href="<?php echo $post['permalink']; ?>" class="gt-aside-article-text-item">
                        <span class="gt-aside-article-rank"><?php echo $index + 1; ?></span>
                        <span class="gt-aside-article-text-title"><?php echo $post['title']; ?></span>
                    </a>
                <?php endforeach; ?>
            </div>
        </section>
        <?php
    }
}

if (!function_exists('renderSidebarRecentComments')) {
    function renderSidebarRecentComments($comments, $index = 0) {
        if (empty($comments)) {
            return;
        }
        $delay = ($index + 1) * 0.08;
        ?>
        <section class="gt-aside-item recent-comments gt-animation gt-animation-init" style="animation-delay: <?php echo $delay; ?>s;">
            <div class="sky-h3"><svg class="aside-icon-comments" viewBox="0 0 1024 1024"><path fill="#5EEFB7" d="M359.53 793.86h222.87c3.89 0 7.68 1.13 10.91 3.28l127.85 84.68c29.64 19.66 69.27-1.64 69.22-37.22l-0.05-30.92c0-10.91 8.81-19.76 19.76-19.76h31.13c63.49 0 115-51.51 115-115V361.06c0-63.49-51.51-115-115-115H359.53c-63.49 0-115 51.51-115 115v317.8c-0.05 63.54 51.46 115 115 115z"/><path fill="#4BE2AC" d="M734.21 757.86H485.27c-4.35 0-8.55 1.28-12.19 3.69l-167.63 111.05c-22.48 14.9-52.48-1.28-52.48-28.21l0.1-64.41c0-12.19-9.83-22.07-22.07-22.07h-34.76c-70.91 0-128.46-57.5-128.46-128.46V274.53c0-70.91 57.5-128.46 128.46-128.46H734.21c70.91 0 128.46 57.5 128.46 128.46v354.92c-0.05 70.91-57.55 128.41-128.46 128.41z"/><path fill="#06CC76" d="M359.53 246.07c-63.49 0-115 51.51-115 115v317.8c0 63.49 51.51 115 115 115h64.77l48.84-32.36c3.58-2.41 7.83-3.69 12.19-3.69h248.93c70.91 0 128.46-57.5 128.46-128.46v-354.82c0-9.22-0.97-18.23-2.87-26.93-6.09-0.97-12.29-1.54-18.64-1.54H359.53z"/><path fill="#FFFFFF" d="M670.05 361.63H279.6c-22.63 0-40.96-18.33-40.96-40.96s18.33-40.96 40.96-40.96h390.4c22.63 0 40.96 18.33 40.96 40.96s-18.28 40.96-40.91 40.96zm0 139.37H279.6c-22.63 0-40.96-18.33-40.96-40.96s18.33-40.96 40.96-40.96h390.4c22.63 0 40.96 18.33 40.96 40.96s-18.28 40.96-40.91 40.96zm-203.47 139.37H279.6c-22.63 0-40.96-18.33-40.96-40.96s18.33-40.96 40.96-40.96h186.98c22.63 0 40.96 18.33 40.96 40.96s-18.33 40.96-40.96 40.96z"/></svg> 最新评论</div>
            <div class="gt-aside-comments">
                <?php foreach ($comments as $comment): ?>
                    <a href="<?php echo $comment['permalink']; ?>" class="gt-aside-comment-item" title="<?php echo htmlspecialchars($comment['title'] ?? ''); ?>" rel="nofollow">
                        <img class="gt-aside-comment-avatar" src="<?php echo $comment['avatar']; ?>" alt="<?php echo htmlspecialchars($comment['author']); ?>的头像" width="40" height="40" loading="lazy">
                        <div class="gt-aside-comment-content">
                            <div class="gt-aside-comment-meta">
                                <span class="gt-aside-comment-author"><?php echo htmlspecialchars($comment['author']); ?></span>
                                <span class="gt-aside-comment-time"><?php echo Mirai_formatTime($comment['created']); ?></span>
                            </div>
                            <div class="gt-aside-comment-text"><?php echo htmlspecialchars(strip_tags($comment['text'])); ?></div>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        </section>
        <?php
    }
}

if (!function_exists('renderSidebarAdminInfo')) {
    function renderSidebarAdminInfo($adminInfo, $avatarSize = 120, $index = 0) {
        $delay = ($index + 1) * 0.08;
        ?>
        <section class="gt-aside-item user gt-animation gt-animation-init" style="animation-delay: <?php echo $delay; ?>s;">
            <img class="gt-aside-avatar" src="<?php echo $adminInfo['avatar']; ?>" alt="<?php echo $adminInfo['name']; ?>的头像" width="<?php echo $avatarSize; ?>" height="<?php echo $avatarSize; ?>">
            <span class="gt-aside-author"><?php echo $adminInfo['name']; ?></span>
            <?php if (!empty($adminInfo['bio'])): ?>
            <span class="gt-aside-bio"><?php echo nl2br(htmlspecialchars($adminInfo['bio'])); ?></span>
            <?php endif; ?>
        </section>
        <?php
    }
}

if (!function_exists('renderSidebarTags')) {
    function renderSidebarTags($tags, $index = 0) {
        $delay = ($index + 1) * 0.08;
        ?>
        <section class="gt-aside-item tags gt-animation gt-animation-init" style="animation-delay: <?php echo $delay; ?>s;">
            <div class="sky-h3"><svg class="aside-icon-tags" viewBox="0 0 1024 1024"><path fill="#FF934A" d="M128.37 199.12c3.28-38.77 28.06-70.67 66.32-78.24C249.26 110.09 347.04 98 511.24 98s261.98 12.09 316.55 22.88c38.26 7.57 63.04 39.47 66.32 78.24 5.45 64.15 12.37 179.6 12.37 352.2 0 159.56-3.08 257.78-6.76 318.15-3.42 56.2-46.42 74.15-94.18 44.13l-231.1-145.19c-38.61-24.27-87.78-24.27-126.4 0l-231.1 145.19c-47.76 30.02-90.76 12.08-94.18-44.13C119.08 809.1 116 710.88 116 551.32c0-172.6 6.92-288.05 12.37-352.2z"/><path fill="#FFFFFF" d="M327.65 411.85c-24.92 0.89-42.9 20.49-42.9 45.43v9.51c0 23.32 15.95 41.44 39.24 42.46 31.73 1.4 88.43 2.74 189.01 2.74s157.27-1.35 189.01-2.74c23.29-1.02 39.24-19.15 39.24-42.47v-16.23c0-21.79-14.3-38.66-36.06-39.83-31.07-1.67-88.16-3.12-192.2-2.2-96.82 0.85-152.98 2.16-185.35 3.32z"/></svg> 标签云</div>
            <div class="gt-aside-tags">
                <?php if (!empty($tags)): ?>
                    <?php foreach ($tags as $tag): ?>
                        <a href="<?php echo $tag['permalink']; ?>"><span><?php echo $tag['name']; ?></span></a>
                    <?php endforeach; ?>
                <?php else: ?>
                    <span>暂无标签</span>
                <?php endif; ?>
            </div>
        </section>
        <?php
    }
}

if (!function_exists('renderMobileSidebarWidgets')) {
    function renderMobileSidebarWidgets($options) {
        ?>
        <div class="gt-mobile-sidebar-widgets">
            <?php if ($options->asideShowAdmin !== '0'): ?>
            <?php
                $adminInfo = Mirai_getSidebarAdminInfo();
                renderSidebarAdminInfo($adminInfo, 80, 0);
            ?>
            <?php endif; ?>

            <?php if ($options->asideShowHotPosts !== '0'): ?>
                <?php $hotPosts = Mirai_getSidebarHotPosts(intval($options->asideHotPostsNumber ?? 5)); ?>
                <?php renderSidebarArticleList($hotPosts, '热门文章', 'hot', 1, $options->asideHotPostsStyle ?? 'cover'); ?>
            <?php endif; ?>

            <?php if ($options->asideShowRecent !== '0'): ?>
                <?php $recentPosts = Mirai_getSidebarRecentPosts(intval($options->asideRecentPostsNumber ?? 5)); ?>
                <?php renderSidebarArticleList($recentPosts, '最新文章', 'recent', 2, $options->asideRecentPostsStyle ?? 'cover'); ?>
            <?php endif; ?>

            <?php if ($options->asideShowTags !== '0'): ?>
            <?php 
                $tags = Mirai_getSidebarTags(intval($options->asideTagsNumber ?? 30), $options->asideTagsSort ?? 'mid');
                renderSidebarTags($tags, 3);
            ?>
            <?php endif; ?>

            <?php if ($options->asideShowRecentComments !== '0'): ?>
                <?php $recentComments = Mirai_getSidebarRecentComments(); ?>
                <?php renderSidebarRecentComments($recentComments, 4); ?>
            <?php endif; ?>
        </div>
        <?php
    }
}
