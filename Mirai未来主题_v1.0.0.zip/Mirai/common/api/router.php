<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

require_once __DIR__ . '/../functions/location.php';
// 引入 auth 通用工具函数
require_once __DIR__ . '/auth/utils.php';

function Mirai_handleApi($api) {
    $bufferLevel = ob_get_level();
    ob_start();
    // 处理 RSS Feed 请求 (无需 Session 和 Token)
    if ($api === 'feed' || $api === 'feed_atom') {
        Mirai_handleRssFeed($api);
    }

    // 开启 Session 用于存储验证码
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }

    $db = \Typecho\Db::get();
    $options = Mirai_opt();

    $response = ['code' => -1, 'msg' => '未知错误', 'success' => false];

    try {
        // 对非GET请求，强制要求为Ajax访问，排除支付回调等特殊接口
        $requestMethod = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
        $isGetRequest = $requestMethod === 'GET';
        $noAjaxApis = ['pay_notify', 'pay_return'];
        if (!$isGetRequest && !in_array($api, $noAjaxApis)) {
            // 检查POST参数中的_ajax标识
            if (!isset($_POST['_ajax']) || $_POST['_ajax'] !== '1') {
                throw new Exception('非法访问方式');
            }
        }

        // 验证 Token (防止 CSRF)
        $token = isset($_POST['token']) ? $_POST['token'] : (isset($_GET['token']) ? $_GET['token'] : '');
        $security = \Widget\Security::alloc();
        // 验证 mirai_api 的 token
        if ($token !== $security->getToken('api')) {
            if (!in_array($api, ['get_views', 'pay_notify', 'pay_return'])) {
                throw new Exception('非法请求');
            }
        }
        switch ($api) {

            case 'auth_login':
                require_once __DIR__ . '/auth/login.php';
                $response = Mirai_api_auth_login();
                break;
            case 'auth_register':
                require_once __DIR__ . '/auth/register.php';
                $response = Mirai_api_auth_register();
                break;
            case 'auth_reset_step2':
                require_once __DIR__ . '/auth/reset.php';
                $response = Mirai_api_auth_reset_step2();
                break;
            case 'auth_validate_code':
                require_once __DIR__ . '/auth/reset.php';
                $response = Mirai_api_auth_validate_code();
                break;
            case 'auth_send_code':
                $result = Mirai_api_send_code_with_check();
                if (!$result['success']) throw new Exception($result['msg']);
                $response = $result;
                break;
            case 'ajaxAddViews':
                require_once __DIR__ . '/interact/views.php';
                $response = Mirai_ajaxAddViews();
                break;
            case 'get_views':
                require_once __DIR__ . '/interact/views.php';
                $response = Mirai_ajaxViews();
                break;
            case 'addlike':
                require_once __DIR__ . '/interact/like.php';
                $response = Mirai_ajaxLike();
                break;
            case 'unlike':
                require_once __DIR__ . '/interact/like.php';
                $response = Mirai_ajaxUnlike();
                break;
            case 'collect_article':
                require_once __DIR__ . '/interact/collect.php';
                $response = Mirai_ajaxToggleCollect();
                break;
            case 'send_test_mail':
                $result = Mirai_api_send_test_mail_with_check();
                if (!$result['success']) throw new Exception($result['msg']);
                $response = $result;
                break;
            case 'pay_create_order':
            case 'pay_query_order':
            case 'pay_mark_pending':
            case 'pay_delete_order':
            case 'pay_notify':
            case 'pay_return':
            case 'income_stats':
            case 'income_orders':
            case 'income_transfer':
            case 'balance_withdraw_create':
            case 'balance_withdraw_cancel':
                $response = Mirai_payInterfaceDispatch($api);
                break;
            case 'license_check_update':
            case 'license_verify':
            case 'license_activate':
                if (!function_exists('Mirai_handleLicenseApi')) {
                    throw new Exception('许可模块未加载');
                }
                $response = Mirai_handleLicenseApi($api);
                break;
            case 'core_repair_db':
                $user = \Typecho\Widget::widget('Widget_User');
                if (!$user->pass('administrator', true)) {
                    throw new Exception('权限不足');
                }
                $plugins = \Typecho\Plugin::export();
                if (!isset($plugins['activated']['MiraiCore'])) {
                    throw new Exception('MiraiCore插件未激活');
                }
                if (!class_exists('MiraiCore_Plugin')) {
                    throw new Exception('MiraiCore插件类未找到');
                }
                $changes = MiraiCore_Plugin::repairDatabaseStructures();
                if (empty($changes)) {
                    $message = '数据库结构已是最新，无需修复';
                } else {
                    $message = '数据库结构补齐完成';
                }
                $response = [
                    'code' => 0,
                    'success' => true,
                    'message' => $message,
                    'details' => $changes
                ];
                break;

            default:
                throw new Exception('未知API');
        }
    } catch (Throwable $e) {
        $response = ['code' => -1, 'msg' => $e->getMessage(), 'success' => false];
    }

    while (ob_get_level() > $bufferLevel) {
        ob_end_clean();
    }
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($response);
    exit;
}