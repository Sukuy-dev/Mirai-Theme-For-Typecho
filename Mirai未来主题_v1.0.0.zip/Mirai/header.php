<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<!DOCTYPE html>
<?php
$themeMode = isset($this->options->themeMode) ? $this->options->themeMode : 'auto';
$initialTheme = 'light';
if ($themeMode !== 'auto') {
    $initialTheme = $themeMode;
}
?>
<html lang="zh-CN" data-theme="<?php echo htmlspecialchars($initialTheme); ?>" data-bs-theme="<?php echo htmlspecialchars($initialTheme); ?>">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="x-dns-prefetch-control" content="on">
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="chrome=1,IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=3.0, user-scalable=yes, viewport-fit=cover">
    <meta name="applicable-device" content="pc,mobile">
    <meta name="color-scheme" content="light dark">
    <meta name="HandheldFriendly" content="true">
    <meta name="MobileOptimized" content="320">
<?php if (isset($this->is404) && $this->is404): ?>
    <meta name="robots" content="noindex, nofollow">
<?php else: ?>
    <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">
<?php endif; ?>
<?php
    $seoData = Mirai_getSeoData($this);
    Mirai_renderSeoMeta($seoData, $this);
?>
<?php
    $rssEnabled = Mirai_featureEnabled('seo') && (!isset($this->options->rssEnable) || $this->options->rssEnable === '1');
    if ($rssEnabled):
?>
    <?php $rssSiteTitle = $this->options->siteTitle ?: $this->options->title; ?>
    <link rel="alternate" type="application/rss+xml" title="<?php echo htmlspecialchars($rssSiteTitle); ?> - RSS Feed" href="<?php echo rtrim($this->options->index, '/') . '/rss'; ?>">
    <link rel="alternate" type="application/atom+xml" title="<?php echo htmlspecialchars($rssSiteTitle); ?> - Atom Feed" href="<?php echo rtrim($this->options->index, '/') . '/atom'; ?>">
<?php endif; ?>
    <link rel="preload" as="style" href="<?php $this->options->themeUrl('assets/css/mirai.css'); ?>">
    <link rel="stylesheet" href="<?php $this->options->themeUrl('assets/css/mirai.css'); ?>">
<?php if ($this->is('author')): ?>
    <link rel="stylesheet" href="<?php $this->options->themeUrl('assets/css/mirai.author.css'); ?>">
<?php endif; ?>
    <?php 
    $userCenterEnabled = Mirai_featureEnabled('user_center');
    $frontendLoginEnabled = $userCenterEnabled && (!isset($this->options->enableFrontendLogin) || $this->options->enableFrontendLogin === '1');
    ?>
<?php if ($this->is('single') || $this->is('page') || $this->is('archive')): ?>
    <link rel="stylesheet" href="<?php $this->options->themeUrl('assets/css/lightbox.css'); ?>">
<?php endif; ?>
<?php 

if ($this->is('page') && $this->template === 'links.php'): 
?>
    <link rel="stylesheet" href="<?php $this->options->themeUrl('assets/css/links.css'); ?>">
<?php endif; ?>
<?php 
if ($this->is('index')) {
    $preloadCover = null;
    
    if (Mirai_featureEnabled('home_category_recommend') && $this->options->recommendEnable) {
        $topLeftCid = $this->options->recommendTopLeft;
        if (!empty($topLeftCid)) {
            $topLeftPost = Mirai_getRecommendPost($topLeftCid);
            if ($topLeftPost) {
                $preloadCover = Mirai_getPostCover($topLeftPost);
            }
        }
    }
    
    if (!$preloadCover) {
        $firstPosts = Mirai_getHomePosts(1, 1);
        if (!empty($firstPosts) && isset($firstPosts[0])) {
            $preloadCover = Mirai_getPostCover($firstPosts[0]);
        }
    }
    
    if ($preloadCover) {
        echo '    <link rel="preload" as="image" href="' . htmlspecialchars(Mirai_normalizeUrl($preloadCover)) . '" fetchpriority="high">' . "\n";
    }
}
?>
<?php 
    Mirai_renderSchema($seoData, $this);
?>
    <script>const MIRAI_CONFIG={HOME_URL:"<?php $this->options->siteUrl(); ?>",INDEX_URL:"<?php echo htmlspecialchars($this->options->index); ?>",TEMPLATE_URL:"<?php echo rtrim($this->options->themeUrl, '/') . '/'; ?>",themeMode:"<?php echo htmlspecialchars($this->options->themeMode ?? 'auto'); ?>",baiduPushEnable:"<?php echo htmlspecialchars($this->options->baiduPushEnable ?? '0'); ?>",indexNowEnable:"<?php echo htmlspecialchars($this->options->indexNowEnable ?? '0'); ?>",allowRegister:"<?php echo $this->options->allowRegister ? '1' : '0'; ?>",API_TOKEN:"<?php echo \Widget\Security::alloc()->getToken('api'); ?>",cid:<?php echo ($this->is('post') || $this->is('page')) ? $this->cid : 'null'; ?>};</script>
    <?php if ($themeMode === 'auto'): ?><script>(function(){const a=window.matchMedia('(prefers-color-scheme: dark)').matches,b=localStorage.getItem('theme'),c=localStorage.getItem('theme_manual_toggle'),d=c?b:a?'dark':'light';d&&(document.documentElement.setAttribute('data-theme',d),document.documentElement.setAttribute('data-bs-theme',d));})();</script><?php endif; ?>
<?php Mirai_customCssVars($this); ?>
    <script type="text/javascript" src="<?php $this->options->themeUrl('assets/lazysizes/5.3.2/lazysizes.min.js'); ?>" async></script>
    <?php Mirai_customHead(); ?>
    <?php $this->header('description=&keywords=&generator=&template=&pingback=&xmlrpc=&wlw=&rss2=&rss1=&atom=&social=&canonical='); ?>
</head>
<body>
<header class="gt-header" role="banner">
    <section>
        <button class="nav-link gt-hover menu-btn d-md-none" onclick="toggleMobileSidebar()" aria-label="切换菜单">
            <svg class="menu-icon" viewBox="0 0 1024 1024"><path fill="#217ade" d="M832 938.667H661.333c-59.733 0-106.666-46.933-106.666-106.667V661.333c0-59.733 46.933-106.667 106.666-106.666H832c59.733 0 106.667 46.933 106.667 106.666v170.667c0 59.733-46.934 106.667-106.667 106.667zM661.333 640a21.333 21.333 0 0 0-21.333 21.333v170.667c0 11.782 9.551 21.333 21.333 21.333H832c11.782 0 21.333-9.551 21.333-21.333V661.333c0-11.782-9.551-21.333-21.333-21.333H661.333zM362.667 85.333H192C134.4 85.333 85.333 132.267 85.333 192v170.667c0 59.733 46.934 106.667 106.667 106.666h170.667c59.733 0 106.666-46.933 106.666-106.666V192c0-59.733-46.933-106.667-106.666-106.667zM832 85.333H661.333c-59.733 0-106.666 46.934-106.666 106.667v170.667c0 59.733 46.933 106.667 106.666 106.666H832c59.733 0 106.667-46.933 106.667-106.666V192c0-59.733-46.934-106.667-106.667-106.667zM362.667 554.667H192c-59.733 0-106.667 46.933-106.667 106.666v170.667c0 59.733 46.934 106.667 106.667 106.667h170.667c59.733 0 106.666-46.934 106.666-106.667V661.333c0-59.733-46.933-106.666-106.666-106.666z"/></svg>
            <svg class="close-icon" style="display:none" viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
        </button>
        <?php $logoAriaLabel = $this->options->siteTitle ? $this->options->siteTitle : $this->options->title; ?>
        <?php if ($this->is('index')): ?>
        <h1 class="home" aria-label="<?php echo htmlspecialchars($logoAriaLabel); ?>">
            <a href="<?php $this->options->siteUrl(); ?>" rel="home" class="gt-hover">
                <?php Mirai_renderLogo($this->options); ?>
                <span class="visually-hidden"><?php echo htmlspecialchars($logoAriaLabel); ?></span>
            </a>
        </h1>
        <?php else: ?>
        <div class="site-logo" aria-label="<?php echo htmlspecialchars($logoAriaLabel); ?>">
            <a href="<?php $this->options->siteUrl(); ?>" rel="home" class="gt-hover">
                <?php Mirai_renderLogo($this->options); ?>
            </a>
        </div>
        <?php endif; ?>
        <nav class="nav-center" role="navigation" aria-label="主导航">
            <a class="nav-link gt-hover" href="<?php $this->options->siteUrl(); ?>" aria-label="首页">首页</a>
            <?php echo Mirai_getNavigationMenu(); ?>
        </nav>
        
        <div class="nav-right" role="toolbar" aria-label="工具栏">
            <button class="nav-link gt-hover search-btn" onclick="openSearch()" title="搜索" aria-label="打开搜索">
                <svg class="search-icon" viewBox="0 0 1024 1024"><path fill="#217ade" d="M995.88 859.78l-207.17-207.17a426.69 426.69 0 1 0-136 136.06l207.23 207.17a96.26 96.26 0 0 0 135.94-136.06zm-569.15-177.09a256 256 0 1 1 0-512 256 256 0 0 1 0 512z"/></svg>
            </button>
            <?php 
            if($this->user->hasLogin()): 
            ?>
            <?php if($userCenterEnabled): ?>
            <?php $userCenterUrl = Mirai_getPageUrlBySlug('user'); ?>
            <a class="nav-link gt-hover user-btn d-md-flex" href="<?php echo htmlspecialchars($userCenterUrl ?: $this->options->siteUrl); ?>" title="<?php echo $userCenterUrl ? '用户中心' : '返回首页'; ?>" aria-label="<?php echo $userCenterUrl ? '用户中心' : '返回首页'; ?>">
                <svg class="usercenter-icon" viewBox="0 0 1024 1024"><path fill="#FF7E47" d="M497.66 87.93h149.62c41.77 0 75.64 33.86 75.64 75.64v149.62c0 122.51-100.18 226.29-222.67 228.52-128.68 2.35-233.46-102.43-231.11-231.11 2.23-122.49 106.01-222.67 228.52-222.67zM580.97 915.19c-22.21-22.21-39.65-48.08-51.84-76.91-12.63-29.87-19.04-61.56-19.04-94.21s6.41-64.35 19.04-94.21c10.4-24.58 24.62-47 42.35-66.85-23.49-2.24-48.6-3.44-75.45-3.44-419.72 0-415.53 292.32-415.53 292.32-4.12 26.22 13.86 48.04 38.06 48.04h467.3a242.55 242.55 0 0 1-4.89-4.74z"/><path fill="#FFB12E" d="M927.69 767.32l30.79-19.27c4.89-3.06 7.3-8.88 6.02-14.5l-15.07-66.14a13.53 13.53 0 0 0-11.71-10.45l-36.16-4.02a13.59 13.59 0 0 1-9.11-5.03l-6.05-7.6a13.57 13.57 0 0 1-2.86-9.99l4.15-36.08c0.66-5.73-2.38-11.25-7.58-13.76L819 551.05c-5.19-2.5-11.4-1.44-15.47 2.64l-25.68 25.76a13.53 13.53 0 0 1-9.59 3.98h-9.69c-3.6 0-7.05-1.43-9.59-3.98l-25.68-25.76a13.55 13.55 0 0 0-15.47-2.64l-61.11 29.43c-5.2 2.5-8.24 8.02-7.58 13.75l4.14 36.12c0.41 3.58-0.62 7.17-2.87 9.99l-6.03 7.57a13.5 13.5 0 0 1-9.1 5.02l-36.18 4.03c-5.73 0.64-10.43 4.83-11.71 10.45l-15.09 66.14a13.55 13.55 0 0 0 6.02 14.5l30.8 19.28c3.05 1.91 5.22 4.96 6.02 8.47l2.16 9.46c0.8 3.51 0.17 7.2-1.75 10.25l-19.4 30.74a13.54 13.54 0 0 0 0.87 15.68l42.32 53.05c3.6 4.51 9.65 6.25 15.09 4.34l34.31-12.07c3.39-1.19 7.12-0.99 10.37 0.57l8.73 4.19a13.5 13.5 0 0 1 6.92 7.76l11.94 34.33c1.89 5.45 7.03 9.1 12.8 9.1h67.84c5.77 0 10.9-3.65 12.8-9.1l11.94-34.33c1.18-3.4 3.68-6.2 6.92-7.76l8.73-4.19c3.24-1.56 6.97-1.77 10.37-0.57l34.31 12.07c5.44 1.91 11.49 0.17 15.09-4.34l42.32-53.05c3.6-4.51 3.94-10.8 0.87-15.68l-19.4-30.74a13.55 13.55 0 0 1-1.75-10.24l2.15-9.46c0.78-3.52 2.95-6.57 6-8.49zm-153.34 42.16c-35.62 6.02-69.37-17.96-75.4-53.58a65.47 65.47 0 0 1 0.01-21.86c4.4-27.08 26.22-48.93 53.28-53.41 35.59-6.13 69.42 17.75 75.55 53.35 1.27 7.37 1.27 14.9-0.01 22.27-4.49 27.06-26.36 48.84-53.43 53.23z"/></svg>
            </a>
            <?php else: ?>
            <a class="nav-link gt-hover user-btn d-md-flex" href="<?php $this->options->siteUrl(); ?>" title="返回首页" aria-label="返回首页">
                <svg class="usercenter-icon" viewBox="0 0 1024 1024"><path fill="#FF7E47" d="M497.66 87.93h149.62c41.77 0 75.64 33.86 75.64 75.64v149.62c0 122.51-100.18 226.29-222.67 228.52-128.68 2.35-233.46-102.43-231.11-231.11 2.23-122.49 106.01-222.67 228.52-222.67zM580.97 915.19c-22.21-22.21-39.65-48.08-51.84-76.91-12.63-29.87-19.04-61.56-19.04-94.21s6.41-64.35 19.04-94.21c10.4-24.58 24.62-47 42.35-66.85-23.49-2.24-48.6-3.44-75.45-3.44-419.72 0-415.53 292.32-415.53 292.32-4.12 26.22 13.86 48.04 38.06 48.04h467.3a242.55 242.55 0 0 1-4.89-4.74z"/><path fill="#FFB12E" d="M927.69 767.32l30.79-19.27c4.89-3.06 7.3-8.88 6.02-14.5l-15.07-66.14a13.53 13.53 0 0 0-11.71-10.45l-36.16-4.02a13.59 13.59 0 0 1-9.11-5.03l-6.05-7.6a13.57 13.57 0 0 1-2.86-9.99l4.15-36.08c0.66-5.73-2.38-11.25-7.58-13.76L819 551.05c-5.19-2.5-11.4-1.44-15.47 2.64l-25.68 25.76a13.53 13.53 0 0 1-9.59 3.98h-9.69c-3.6 0-7.05-1.43-9.59-3.98l-25.68-25.76a13.55 13.55 0 0 0-15.47-2.64l-61.11 29.43c-5.2 2.5-8.24 8.02-7.58 13.75l4.14 36.12c0.41 3.58-0.62 7.17-2.87 9.99l-6.03 7.57a13.5 13.5 0 0 1-9.1 5.02l-36.18 4.03c-5.73 0.64-10.43 4.83-11.71 10.45l-15.09 66.14a13.55 13.55 0 0 0 6.02 14.5l30.8 19.28c3.05 1.91 5.22 4.96 6.02 8.47l2.16 9.46c0.8 3.51 0.17 7.2-1.75 10.25l-19.4 30.74a13.54 13.54 0 0 0 0.87 15.68l42.32 53.05c3.6 4.51 9.65 6.25 15.09 4.34l34.31-12.07c3.39-1.19 7.12-0.99 10.37 0.57l8.73 4.19a13.5 13.5 0 0 1 6.92 7.76l11.94 34.33c1.89 5.45 7.03 9.1 12.8 9.1h67.84c5.77 0 10.9-3.65 12.8-9.1l11.94-34.33c1.18-3.4 3.68-6.2 6.92-7.76l8.73-4.19c3.24-1.56 6.97-1.77 10.37-0.57l34.31 12.07c5.44 1.91 11.49 0.17 15.09-4.34l42.32-53.05c3.6-4.51 3.94-10.8 0.87-15.68l-19.4-30.74a13.55 13.55 0 0 1-1.75-10.24l2.15-9.46c0.78-3.52 2.95-6.57 6-8.49zm-153.34 42.16c-35.62 6.02-69.37-17.96-75.4-53.58a65.47 65.47 0 0 1 0.01-21.86c4.4-27.08 26.22-48.93 53.28-53.41 35.59-6.13 69.42 17.75 75.55 53.35 1.27 7.37 1.27 14.9-0.01 22.27-4.49 27.06-26.36 48.84-53.43 53.23z"/></svg>
            </a>
            <?php endif; ?>
            <?php elseif ($frontendLoginEnabled): ?>
            <button class="nav-link gt-hover user-btn d-md-flex" onclick="window.openLoginModal()" title="登录" aria-label="登录">
                <svg class="user-icon" viewBox="0 0 1024 1024"><path fill="#FD9F55" d="M510.32 498.64A196.58 196.58 0 0 0 644.8 311.68c0-108.24-88.56-196.8-196.8-196.8s-196.8 88.56-196.8 196.8a196.59 196.59 0 0 0 134.48 186.96C246.27 526.51 120 644.59 120 787.28a114.08 114.08 0 0 0 114.8 114.8h426.4A114.08 114.08 0 0 0 776 787.28c0-142.69-126.29-260.77-265.68-288.64z"/><path fill="#FECC87" d="M719.92 541.12c-101.6.05-183.92 82.45-183.92 184.05s82.35 183.95 183.95 183.95 184-82.3 184.05-183.92c0-48.82-19.36-95.68-53.89-130.2a183.86 183.86 0 0 0-130.19-53.88zm105.6 136.29L706.43 796.42a16.64 16.64 0 0 1-23.94 0L614 727.94a16.93 16.93 0 0 1 23.92-23.94l56.8 56.8L801.92 654a16.93 16.93 0 0 1 23.94 23.94l-.36-.53z"/></svg>
            </button>
            <?php endif; ?>
            <button class="nav-link gt-hover theme-btn d-md-flex" onclick="toggleTheme()" title="切换主题" aria-label="切换主题模式">
                <svg class="theme-icon-sun" viewBox="0 0 1024 1024" style="display: <?php echo $initialTheme === 'light' ? 'block' : 'none'; ?>"><path fill="#FF934A" d="M512 512m-224 0a224 224 0 1 0 448 0 224 224 0 1 0-448 0Z"/><path fill="#FCBF28" d="M445.29 120.69c.9-31.1 21.04-55.58 52.13-56.49 4.48-.13 9.34-.2 14.58-.2s10.1.07 14.58.2c31.09.91 51.23 25.39 52.13 56.49.29 9.91.49 20.98.49 32.91s-.2 23-.49 32.91c-.9 31.1-21.04 55.58-52.13 56.49-4.48.13-9.34.2-14.58.2s-10.1-.07-14.58-.2c-31.09-.91-51.23-25.39-52.13-56.49-.29-9.91-.49-20.98-.49-32.91s.2-23 .49-32.91zm0 782.62c.9 31.1 21.04 55.58 52.13 56.49 4.48.13 9.34.2 14.58.2s10.1-.07 14.58-.2c31.09-.91 51.23-25.39 52.13-56.49.29-9.91.49-20.98.49-32.91s-.2-23-.49-32.91c-.9-31.1-21.04-55.58-52.13-56.49-4.48-.13-9.34-.2-14.58-.2s-10.1.07-14.58.2c-31.09.91-51.23 25.39-52.13 56.49-.29 9.91-.49 20.98-.49 32.91s.2 23 .49 32.91zM120.69 578.72c-31.09-.92-55.57-21.04-56.49-52.14-.13-4.48-.2-9.33-.2-14.58s.07-10.1.2-14.58c.92-31.1 25.4-51.22 56.49-52.14 21.94-.64 43.87-.64 65.81 0 31.09.92 55.57 21.04 56.49 52.14.13 4.48.2 9.33.2 14.58s-.07 10.1-.2 14.58c-.92 31.1-25.4 51.22-56.49 52.14-21.94.64-43.87.64-65.81 0zm782.62 0c31.09-.92 55.57-21.04 56.49-52.14.13-4.48.2-9.33.2-14.58s-.07-10.1-.2-14.58c-.92-31.1-25.4-51.22-56.49-52.14-21.94-.64-43.87-.64-65.81 0-31.09.92-55.57 21.04-56.49 52.14-.13 4.48-.2 9.33-.2 14.58s.07 10.1.2 14.58c.92 31.1 25.4 51.22 56.49 52.14 21.94.64 43.87.64 65.81 0zM188.12 282.48c-21.33-22.64-24.42-54.18-3.07-76.81a471.58 471.58 0 0 1 10.17-10.46 486.64 486.64 0 0 1 10.46-10.17c22.62-21.34 54.16-18.26 76.79 3.08a1104.74 1104.74 0 0 1 23.63 22.93 1160.74 1160.74 0 0 1 22.91 23.61c21.35 22.64 24.44 54.18 3.09 76.81a599.97 599.97 0 0 1-10.17 10.45 486.64 486.64 0 0 1-10.46 10.17c-22.62 21.34-54.16 18.26-76.81-3.08a1106.88 1106.88 0 0 1-23.61-22.93 1171.42 1171.42 0 0 1-22.94-23.61zm553.41 553.39c22.62 21.34 54.16 24.42 76.79 3.08a486.64 486.64 0 0 0 10.46-10.17 471.58 471.58 0 0 0 10.17-10.46c21.35-22.63 18.26-54.17-3.07-76.81a1171.42 1171.42 0 0 0-22.94-23.61 1106.88 1106.88 0 0 0-23.61-22.93c-22.65-21.34-54.19-24.42-76.81-3.08a486.64 486.64 0 0 0-10.46 10.17 599.97 599.97 0 0 0-10.17 10.45c-21.35 22.63-18.26 54.17 3.09 76.81a1160.74 1160.74 0 0 0 22.91 23.61 1104.74 1104.74 0 0 0 23.63 22.93zm-459.06 0c-22.62 21.34-54.16 24.42-76.79 3.08a486.64 486.64 0 0 1-10.46-10.17 471.58 471.58 0 0 1-10.17-10.46c-21.35-22.63-18.26-54.17 3.07-76.81a1171.42 1171.42 0 0 1 22.94-23.61 1106.88 1106.88 0 0 1 23.61-22.93c22.65-21.34 54.19-24.42 76.81-3.08a486.64 486.64 0 0 1 10.46 10.17 599.97 599.97 0 0 1 10.17 10.45c21.35 22.63 18.26 54.17-3.09 76.81a1160.74 1160.74 0 0 1-22.91 23.61 1104.74 1104.74 0 0 1-23.63 22.93zm553.41-553.39c21.33-22.64 24.42-54.18 3.07-76.81a471.58 471.58 0 0 0-10.17-10.46 486.64 486.64 0 0 0-10.46-10.17c-22.62-21.34-54.16-18.26-76.79 3.08a1104.74 1104.74 0 0 0-23.63 22.93 1160.74 1160.74 0 0 0-22.91 23.61c-21.35 22.64-24.44 54.18-3.09 76.81a599.97 599.97 0 0 0 10.17 10.45 486.64 486.64 0 0 0 10.46 10.17c22.62 21.34 54.16 18.26 76.81-3.08a1106.88 1106.88 0 0 0 23.61-22.93 1171.42 1171.42 0 0 0 22.94-23.61z"/></svg>
                <svg class="theme-icon-moon" viewBox="0 0 1024 1024" style="display: <?php echo $initialTheme === 'dark' ? 'block' : 'none'; ?>"><path fill="#74BFF5" d="M1007.75 644.41a519.57 519.57 0 0 0 14.5-76.77c3.84-34.97-51.39-44.95-76-19.75a311.78 311.78 0 0 1-8.49 8.36 303.03 303.03 0 1 1-380.4-380.4 303.93 303.93 0 0 1 88.2-42.31c14.07-4.14 16.08-25.16 1.92-29L645.9 17.57A511.81 511.81 0 0 0 19.03 379.46C-54.12 652.55 107.91 933.2 380.92 1006.3 654.01 1079.49 934.65 917.41 1007.75 644.45z"/><path fill="#FFF5E0" d="M619.46 196.92a19.02 19.02 0 0 0-11.17 34.42l.17.13c6.65 4.86 9.38 13.14 6.82 20.98l-.08.22a19.02 19.02 0 0 0 29.26 21.24l.17-.13a18.55 18.55 0 0 1 22.05 0l.21.13c14.93 10.83 34.97-3.71 29.26-21.24l-.09-.21a18.55 18.55 0 0 1 6.82-20.98l.17-.13a19.02 19.02 0 0 0-11.17-34.42h-.21a18.55 18.55 0 0 1-17.83-12.97l-.09-.21a19.02 19.02 0 0 0-36.17 0l-.08.21a18.55 18.55 0 0 1-17.83 12.97h-.21zm255.9 0a19.02 19.02 0 0 0-11.17 34.42l.17.13c6.65 4.86 9.38 13.14 6.82 20.98l-.08.22a19.02 19.02 0 0 0 29.26 21.24l.17-.13a18.55 18.55 0 0 1 22.05 0l.21.13c14.93 10.83 34.97-3.71 29.26-21.24l-.09-.21a18.55 18.55 0 0 1 6.82-20.98l.17-.13a19.02 19.02 0 0 0-11.17-34.42h-.21a18.55 18.55 0 0 1-17.83-12.97l-.09-.21a19.02 19.02 0 0 0-36.17 0l-.08.21a18.55 18.55 0 0 1-17.83 12.97h-.21zm-127.95 170.6a19.02 19.02 0 0 0-11.17 34.42l.17.13a18.55 18.55 0 0 1 6.74 21.2 19.02 19.02 0 0 0 29.26 21.24l.17-.13a18.55 18.55 0 0 1 22.05 0l.21.13c14.93 10.83 34.97-3.71 29.26-21.24l-.09-.21a18.55 18.55 0 0 1 6.82-20.98l.17-.13a19.02 19.02 0 0 0-11.17-34.42h-.21a18.55 18.55 0 0 1-17.83-12.97l-.09-.21a19.02 19.02 0 0 0-36.17 0l-.08.21a18.55 18.55 0 0 1-17.83 12.97h-.21z"/></svg>
            </button>
        </div>
    </section>
</header>
<?php $this->need('modules/search.php'); ?>
<main role="main" class="main">
    <section class="main-inner <?php echo (isset($this->hideThemeSidebar) && $this->hideThemeSidebar) ? 'no-aside' : ($this->options->asidePosition == 'left' ? 'aside-left' : 'aside-right'); ?> <?php if($this->is('index')) echo 'home-page'; ?>">
        <div class="main-inner-content">