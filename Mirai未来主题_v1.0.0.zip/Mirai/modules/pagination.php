<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/**
 * 自定义分页渲染
 */
function Mirai_customPagination($current, $total, $linkGenerator, $options = []) {
    if ($total <= 1) return '';

    $linkCallback = function($page) use ($linkGenerator) {
        return is_callable($linkGenerator) ? $linkGenerator($page) : $linkGenerator . ($page > 1 ? '?page=' . $page : '');
    };

    $prevIcon = '<svg aria-label="上一页" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"></polyline></svg>';
    $nextIcon = '<svg aria-label="下一页" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"></polyline></svg>';

    $defaults = [
        'itemClass' => '',
        'activeClass' => 'active',
        'disabledClass' => 'disabled',
        'innerClass' => 'pagination',
        'outerTag' => 'section',
        'outerClass' => 'gt-art-page',
    ];

    $opts = array_merge($defaults, $options);

    $inner = '';

    // 上一页按钮
    if ($current > 1) {
        $inner .= '<a href="' . $linkCallback($current - 1) . '" class="' . $opts['itemClass'] . ' prev">' . $prevIcon . '</a>';
    } else {
        $inner .= '<span class="' . $opts['itemClass'] . ' prev ' . $opts['disabledClass'] . '">' . $prevIcon . '</span>';
    }

    if ($current <= 2) {
        // 当前在第1页或第2页，显示1, 2
        for ($i = 1; $i <= min(2, $total); $i++) {
            if ($i == $current) {
                $inner .= '<span class="' . $opts['itemClass'] . ' ' . $opts['activeClass'] . '">' . $i . '</span>';
            } else {
                $inner .= '<a href="' . $linkCallback($i) . '" class="' . $opts['itemClass'] . '">' . $i . '</a>';
            }
        }

        // 如果总页数大于2，显示省略号和最后一页
        if ($total > 2) {
            $inner .= '<a class="' . $opts['itemClass'] . ' ellipsis">...</a>';
            $inner .= '<a href="' . $linkCallback($total) . '" class="' . $opts['itemClass'] . '">' . $total . '</a>';
        }
    } else {
        // 当前在第3页或更后，显示1, 2, ..., 当前页, ..., 最后一页
        $inner .= '<a href="' . $linkCallback(1) . '" class="' . $opts['itemClass'] . '">1</a>';
        $inner .= '<a href="' . $linkCallback(2) . '" class="' . $opts['itemClass'] . '">2</a>';
        $inner .= '<a class="' . $opts['itemClass'] . ' ellipsis">...</a>';

        // 显示当前页（高亮）
        $inner .= '<span class="' . $opts['itemClass'] . ' ' . $opts['activeClass'] . '">' . $current . '</span>';

        // 如果当前页后面还有页，显示省略号和最后一页
        if ($current < $total - 1) {
            $inner .= '<a class="' . $opts['itemClass'] . ' ellipsis">...</a>';
            $inner .= '<a href="' . $linkCallback($total) . '" class="' . $opts['itemClass'] . '">' . $total . '</a>';
        } else if ($current == $total - 1) {
            // 当前是倒数第二页，直接显示最后一页
            $inner .= '<a href="' . $linkCallback($total) . '" class="' . $opts['itemClass'] . '">' . $total . '</a>';
        }
    }

    // 下一页按钮
    if ($current < $total) {
        $inner .= '<a href="' . $linkCallback($current + 1) . '" class="' . $opts['itemClass'] . ' next">' . $nextIcon . '</a>';
    } else {
        $inner .= '<span class="' . $opts['itemClass'] . ' next ' . $opts['disabledClass'] . '">' . $nextIcon . '</span>';
    }

    return '<' . $opts['outerTag'] . ' class="' . $opts['outerClass'] . '"><div class="' . $opts['innerClass'] . '">' . $inner . '</div></' . $opts['outerTag'] . '>';
}
