<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$config = Mirai_getCommentConfig();
$canComment = $config['globalEnable'] && $this->allow('comment') && !Mirai_isCommentClosed($this->created) && ($this->user->hasLogin() || $config['guestAllowed']);
$respondId = $this->respondId;
?>
    <div class="gt-comment-header">
        <div class="gt-comment-title">
            <svg class="comment-title-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M896 138.67H128c-38.4 0-64 25.6-64 64v544c0 38.4 25.6 64 64 64h128v128c83.2 0 166.4-44.8 256-128h384c38.4 0 64-25.6 64-64v-544c0-38.4-25.6-64-64-64zm0 608H486.4l-19.2 19.2c-51.2 51.2-102.4 83.2-147.2 96v-115.2H128v-544h768v544z"/><path fill="currentColor" d="M320 477.87m-64 0a64 64 0 1 0 128 0 64 64 0 1 0-128 0z"/><path fill="currentColor" d="M512 477.87m-64 0a64 64 0 1 0 128 0 64 64 0 1 0-128 0z"/><path fill="currentColor" d="M704 477.87m-64 0a64 64 0 1 0 128 0 64 64 0 1 0-128 0z"/></svg>
            <span>评论</span>
            <em class="gt-comment-count-text"><?php echo intval($this->commentsNum) > 0 ? '共' . $this->commentsNum . '条' : '暂无评论'; ?></em>
        </div>
    </div>

    <div class="gt-comment-form-wrap">
        <?php if($canComment): ?>
        <div id="<?php echo $respondId; ?>" class="respond">
            <form class="gt-comment-form" method="post" action="<?php $this->commentUrl() ?>" id="comment-form" role="form">
                <div class="gt-comment-textarea-wrap">
                    <textarea name="text" id="comment-textarea" rows="4" placeholder="文明交流，友善发言" required><?php $this->remember('text'); ?></textarea>
                    <div class="gt-comment-textarea-footer">
                        <div class="gt-comment-submit-wrap">
                            <div class="cancel-comment-reply">
                                <?php $replyTo = $this->request->filter('int')->get('replyTo'); ?>
                                <a id="cancel-comment-reply-link" href="<?php echo $this->permalink; ?>#<?php echo $respondId; ?>" rel="nofollow"<?php echo $replyTo ? '' : ' style="display:none"'; ?> onclick="return TypechoComment.cancelReply();">取消回复</a>
                            </div>
                            <button type="submit" class="submit">
                                <span>发表评论</span>
                            </button>
                        </div>
                    </div>
                </div>

                <?php if(!$this->user->hasLogin()): ?>
                <div class="gt-comment-fields">
                    <div class="gt-comment-field">
                        <svg class="comment-user-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M933.7 931.5a417.4 417.4 0 0 0-159.5-300.1l-5.6-3.9a33.6 33.6 0 0 0-17.6-5 28.8 28.8 0 0 0-34.2 27.6 33.7 33.7 0 0 0 12.5 26l5 3.5a324.4 324.4 0 0 1 131.2 252.5v4a34.2 34.2 0 0 0 68.3 1.9h.7zM823.7 359.7a311.9 311.9 0 0 0-623.4 0 304.6 304.6 0 0 0 111.4 235.6 419.8 419.8 0 0 0-221.4 340.4l-.4 6a1.1 1.1 0 0 0 0 .4v1.4a29 29 0 0 0 58 0v-.9h.4l.5-6a356.5 356.5 0 0 1 219.9-304 369 369 0 0 0 143.3 34.9 312.2 312.2 0 0 0 135-30.8l31.6-18.3 25.8-17a305 305 0 0 0 119.2-241.8zm-311.9 245.9a247.8 247.8 0 0 1-249.1-246 249.1 249.1 0 0 1 498 0 247.8 247.8 0 0 1-249.1 246z"/></svg>
                        <input type="text" name="author" placeholder="昵称 *" value="<?php $this->remember('author'); ?>" required>
                    </div>
                    <div class="gt-comment-field">
                        <svg class="comment-mail-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M104.9 233.1v557.8H919V233.1H104.9zm715.2 46L512 484.4 203.9 279.1h616.2zM150.9 744.9V299L512 539.6 873.1 299v445.9H150.9z"/></svg>
                        <input type="email" name="mail" placeholder="邮箱<?php echo $config['requireMail'] ? ' *' : ''; ?>" value="<?php $this->remember('mail'); ?>"<?php echo $config['requireMail'] ? ' required' : ''; ?>>
                    </div>
                    <?php if ($config['showUrl']): ?>
                    <div class="gt-comment-field">
                        <svg class="comment-url-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M569.1 626.1a166.2 166.2 0 0 1-117.4-49 22.8 22.8 0 1 1 32.3-32.3 121.5 121.5 0 0 0 170.3 0l163.8-163.8a120.4 120.4 0 0 0-170.3-170.3l-138.2 138.2a22.8 22.8 0 1 1-32.3-32.3l138.2-138.2a165.1 165.1 0 0 1 233.5 233.5l-163.8 163.8a159.5 159.5 0 0 1-116.1 50.4zM299.5 896a165.8 165.8 0 0 1-117.4-282.6l163.8-163.8a165.1 165.1 0 0 1 233.5 0 22.8 22.8 0 1 1-32.3 32.3 121.5 121.5 0 0 0-170.3 0l-163.8 163.8a120.4 120.4 0 0 0 170.3 170.3l138.2-138.2a22.8 22.8 0 0 1 32.3 32.3l-138.2 138.2A169.8 169.8 0 0 1 299.5 896z"/></svg>
                        <input type="url" name="url" placeholder="网址<?php echo $config['requireUrl'] ? ' *' : ' (选填)'; ?>" value="<?php $this->remember('url'); ?>"<?php echo $config['requireUrl'] ? ' required' : ''; ?>>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </form>
        </div>
        <?php else: ?>
            <?php $statusTip = Mirai_getCommentStatusTip($this->created, $this->allow('comment'), $config['globalEnable'], $config['guestAllowed'], $this->user->hasLogin()); ?>
            <?php if ($statusTip): ?>
            <div class="gt-comment-closed"><svg class="comment-closed-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M896 138.67H128c-38.4 0-64 25.6-64 64v544c0 38.4 25.6 64 64 64h128v128c83.2 0 166.4-44.8 256-128h384c38.4 0 64-25.6 64-64v-544c0-38.4-25.6-64-64-64zm0 608H486.4l-19.2 19.2c-51.2 51.2-102.4 83.2-147.2 96v-115.2H128v-544h768v544z"/><path fill="currentColor" d="M320 477.87m-64 0a64 64 0 1 0 128 0 64 64 0 1 0-128 0z"/><path fill="currentColor" d="M512 477.87m-64 0a64 64 0 1 0 128 0 64 64 0 1 0-128 0z"/><path fill="currentColor" d="M704 477.87m-64 0a64 64 0 1 0 128 0 64 64 0 1 0-128 0z"/></svg><span><?php echo $statusTip; ?></span></div>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <?php

    $this->comments('commentPage', $config['pageSize'])->to($comments);
    
    if ($comments->have()): 
    ?>
        <div class="gt-comment-list-wrapper">
            <?php $comments->listComments(['before' => '<div class="gt-comment-list">', 'after' => '</div>']); ?>
            <?php if ($config['pageBreak']): ?>
                <?php
                $db = Typecho_Db::get();
                $select = $db->select(['COUNT(coid)' => 'num'])->from('table.comments')
                    ->where('cid = ?', $this->cid)
                    ->where('status = ?', 'approved')
                    ->where('parent = ?', 0);
                if ($this->options->commentsShowCommentOnly) $select->where('type = ?', 'comment');
                $totalComments = $db->fetchObject($select)->num;
                $totalPages = ceil($totalComments / $config['pageSize']);
                if ($totalPages > 1):
                    $currentPage = 1;
                    if (preg_match('/comment-page-(\d+)/i', $this->request->getPathInfo(), $matches)) $currentPage = intval($matches[1]);
                    echo Mirai_customPagination($currentPage, $totalPages, function($page) {
                        return $this->permalink . ($page > 1 ? '/comment-page-' . $page : '') . '#comments';
                    }, ['outerClass' => 'gt-art-page', 'innerClass' => 'pagination']);
                endif;
                ?>
            <?php endif; ?>
        </div>

    <?php elseif ($canComment): ?>
        <div class="gt-comment-list-wrapper">
            <div class="gt-comment-list">
                <div class="gt-comment-empty">
                    <svg class="comment-empty-icon" viewBox="0 0 1024 1024"><path fill="currentColor" d="M896 138.67H128c-38.4 0-64 25.6-64 64v544c0 38.4 25.6 64 64 64h128v128c83.2 0 166.4-44.8 256-128h384c38.4 0 64-25.6 64-64v-544c0-38.4-25.6-64-64-64zm0 608H486.4l-19.2 19.2c-51.2 51.2-102.4 83.2-147.2 96v-115.2H128v-544h768v544z"/><path fill="currentColor" d="M320 477.87m-64 0a64 64 0 1 0 128 0 64 64 0 1 0-128 0z"/><path fill="currentColor" d="M512 477.87m-64 0a64 64 0 1 0 128 0 64 64 0 1 0-128 0z"/><path fill="currentColor" d="M704 477.87m-64 0a64 64 0 1 0 128 0 64 64 0 1 0-128 0z"/></svg>
                    <span>暂无评论，快来抢沙发吧~</span>
                </div>
            </div>
        </div>
    <?php endif; ?>
