<?php
/**
 * 桌面端侧边栏
 * 移动端不渲染此文件
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

// 移动端不渲染桌面侧边栏
if (Mirai_isMobile()) {
    return;
}

// 初始化侧边栏变量
$options = $this->options;
?>
<aside class="gt-aside pc-aside" aria-label="侧边栏">
    <div class="sticky-aside">
        <?php if ($options->asideShowAdmin !== '0'): ?>
        <?php
            $adminInfo = Mirai_getSidebarAdminInfo();
            renderSidebarAdminInfo($adminInfo, 120, 0);
        ?>
        <?php endif; ?>

        <?php if ($options->asideShowHotPosts !== '0'): ?>
            <?php $hotPosts = Mirai_getSidebarHotPosts(intval($options->asideHotPostsNumber ?? 5)); ?>
            <?php renderSidebarArticleList($hotPosts, '热门文章', 'hot', 1, $options->asideHotPostsStyle ?? 'cover'); ?>
        <?php endif; ?>

        <?php if ($options->asideShowRecent !== '0'): ?>
            <?php $recentPosts = Mirai_getSidebarRecentPosts(intval($options->asideRecentPostsNumber ?? 5)); ?>
            <?php renderSidebarArticleList($recentPosts, '最新文章', 'recent', 2, $options->asideRecentPostsStyle ?? 'cover'); ?>
        <?php endif; ?>

        <?php if ($options->asideShowTags !== '0'): ?>
        <?php 
            $tags = Mirai_getSidebarTags(intval($options->asideTagsNumber ?? 30), $options->asideTagsSort ?? 'mid');
            renderSidebarTags($tags, 3);
        ?>
        <?php endif; ?>

        <?php if ($options->asideShowRecentComments !== '0'): ?>
            <?php $recentComments = Mirai_getSidebarRecentComments(); ?>
            <?php renderSidebarRecentComments($recentComments, 4); ?>
        <?php endif; ?>
    </div>
</aside>
