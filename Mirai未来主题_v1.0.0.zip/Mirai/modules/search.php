<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<div class="gt-search-modal" id="searchModal" onclick="closeSearch(event)" role="dialog" aria-modal="true">
    <div class="gt-search-box" onclick="event.stopPropagation()">
        <form class="gt-search-form" method="post" action="<?php $this->options->siteUrl(); ?>">
            <label for="search-input" class="visually-hidden">搜索输入</label>
            <input type="text" id="search-input" name="s" placeholder="请输入关键字..." autocomplete="off" aria-label="请输入关键字">
            <button type="submit" aria-label="提交搜索"><svg class="search-submit-icon" viewBox="0 0 1024 1024" aria-hidden="true"><path fill="#217ade" d="M995.88 859.78l-207.17-207.17a426.69 426.69 0 1 0-136 136.06l207.23 207.17a96.26 96.26 0 0 0 135.94-136.06zm-569.15-177.09a256 256 0 1 1 0-512 256 256 0 0 1 0 512z"/></svg></button>
        </form>
    </div>
</div>
