<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

if (!Mirai_featureEnabled('home_category_recommend')) return;
if (!isset($this->options) || $this->options->recommendEnable != '1') return;

$recommendTopEnable = $this->options->recommendTopEnable === '1';
$recommendTopIds = [];
if ($recommendTopEnable && !empty($this->options->recommendTopIds)) {
    $lines = explode("\n", $this->options->recommendTopIds);
    foreach ($lines as $line) {
        $cid = intval(trim($line));
        if ($cid > 0) {
            $recommendTopIds[] = $cid;
        }
    }
}

$topLeft = null;
$topRight1 = null;
$topRight2 = null;
$bottomItems = [];

$availableTopPosts = [];
if ($recommendTopEnable && !empty($recommendTopIds)) {
    foreach ($recommendTopIds as $cid) {
        $post = Mirai_getRecommendPost($cid);
        if ($post) {
            // 标记为置顶
            $post['isTop'] = true;
            $availableTopPosts[] = $post;
        }
    }
}

$getPostFunc = function($configId) use (&$availableTopPosts) {
    // 优先使用置顶文章
    if (!empty($availableTopPosts)) {
        return array_shift($availableTopPosts);
    }
    
    // 置顶文章用尽后，使用配置的文章ID
    if (!empty($configId)) {
        $post = Mirai_getRecommendPost($configId);
        if ($post) {
            return $post;
        }
    }
    
    return null;
};

if (isset($this->options->recommendTopLeft)) {
    $topLeft = $getPostFunc($this->options->recommendTopLeft);
} else {
    $topLeft = $getPostFunc(null);
}

if (isset($this->options->recommendTopRight1)) {
    $topRight1 = $getPostFunc($this->options->recommendTopRight1);
} else {
    $topRight1 = $getPostFunc(null);
}

if (isset($this->options->recommendTopRight2)) {
    $topRight2 = $getPostFunc($this->options->recommendTopRight2);
} else {
    $topRight2 = $getPostFunc(null);
}

$bottomConfigs = ['recommendBottom1', 'recommendBottom2', 'recommendBottom3', 'recommendBottom4'];
foreach ($bottomConfigs as $opt) {
    $post = null;
    if (isset($this->options->$opt)) {
        $post = $getPostFunc($this->options->$opt);
    } else {
        $post = $getPostFunc(null);
    }
    
    if ($post) {
        $bottomItems[] = $post;
    }
}

// 记录已使用的文章ID，供列表页排除
global $mirai_recommend_excluded_ids;
$mirai_recommend_excluded_ids = [];
if ($topLeft && isset($topLeft['cid'])) $mirai_recommend_excluded_ids[] = $topLeft['cid'];
if ($topRight1 && isset($topRight1['cid'])) $mirai_recommend_excluded_ids[] = $topRight1['cid'];
if ($topRight2 && isset($topRight2['cid'])) $mirai_recommend_excluded_ids[] = $topRight2['cid'];
if (!empty($bottomItems)) {
    foreach ($bottomItems as $item) {
        if (isset($item['cid'])) {
            $mirai_recommend_excluded_ids[] = $item['cid'];
        }
    }
}

// 检查是否有顶部推荐内容
$hasTopContent = $topLeft || $topRight1 || $topRight2;

// 设置默认值
$lazyLoading = Mirai_getDefaultLazyLoading();
$defaultCover = Mirai_getDefaultThumb();
?>

<section class="gt-recommend-section">
    <?php if ($hasTopContent): ?>
    <div class="gt-recommend-top">
        <?php if ($topLeft): 
            $cover = $topLeft['cover'] ?: $defaultCover;
            $isTop = !empty($topLeft['isTop']);
        ?>
        <a href="<?php echo $topLeft['permalink']; ?>" class="gt-recommend-main active">
            <?php echo Mirai_generatePictureTag($cover, $lazyLoading, $topLeft['title'], '', '800', '450', ['context' => 'recommend-main', 'priority' => true]); ?>
            <?php if ($isTop): ?>
            <span class="gt-recommend-top-badge">置顶</span>
            <?php endif; ?>
            <div class="gt-recommend-overlay">
                <span class="gt-recommend-tag">推荐</span>
                <h2 class="text-truncate"><?php echo $topLeft['title']; ?></h2>
            </div>
        </a>
        <?php endif; ?>
        
        <?php if ($topRight1 || $topRight2): ?>
        <div class="gt-recommend-right">
            <?php if ($topRight1): 
                $cover = $topRight1['cover'] ?: $defaultCover; 
                $isTop = !empty($topRight1['isTop']);
            ?>
            <a href="<?php echo $topRight1['permalink']; ?>" class="gt-recommend-item active">
                <?php echo Mirai_generatePictureTag($cover, $lazyLoading, $topRight1['title'], '', '400', '225', ['context' => 'recommend-item', 'priority' => true]); ?>
                <?php if ($isTop): ?>
                <span class="gt-recommend-top-badge">置顶</span>
                <?php endif; ?>
                <div class="gt-recommend-overlay">
                    <span class="gt-recommend-tag">推荐</span>
                    <h2 class="text-truncate"><?php echo $topRight1['title']; ?></h2>
                </div>
            </a>
            <?php endif; ?>
            
            <?php if ($topRight2): 
                $cover = $topRight2['cover'] ?: $defaultCover; 
                $isTop = !empty($topRight2['isTop']);
            ?>
            <a href="<?php echo $topRight2['permalink']; ?>" class="gt-recommend-item active">
                <?php echo Mirai_generatePictureTag($cover, $lazyLoading, $topRight2['title'], '', '400', '225', ['context' => 'recommend-item', 'priority' => true]); ?>
                <?php if ($isTop): ?>
                <span class="gt-recommend-top-badge">置顶</span>
                <?php endif; ?>
                <div class="gt-recommend-overlay">
                    <span class="gt-recommend-tag">推荐</span>
                    <h2 class="text-truncate"><?php echo $topRight2['title']; ?></h2>
                </div>
            </a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    
    <?php if (!empty($bottomItems)): ?>
    <div class="gt-recommend-bottom">
        <?php foreach ($bottomItems as $index => $item): 
            $delay = ($index + 1) * 0.05;
            $cover = $item['cover'] ?: $defaultCover; 
            $isTop = !empty($item['isTop']);
        ?>
        <a href="<?php echo $item['permalink']; ?>" class="gt-recommend-card gt-animation gt-animation-init active" style="animation-delay: <?php echo $delay; ?>s;">
            <?php if ($isTop): ?>
            <span class="gt-recommend-top-badge">置顶</span>
            <?php endif; ?>
            <div class="gt-recommend-thumb">
                <?php echo Mirai_generatePictureTag($cover, $lazyLoading, $item['title'], '', '200', '113', ['context' => 'recommend-card']); ?>
            </div>
            <h2 class="text-truncate"><?php echo $item['title']; ?></h2>
        </a>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</section>
