<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<div id="mirai-share-modal">
    <div class="share-mask" onclick="MiraiShare.close()"></div>
    <div class="share-container">
        <div class="share-title">分享到</div>
        <div class="share-options">
            <div class="share-item" onclick="MiraiShare.to('qq')">
                <div class="share-icon icon-qq"><svg class="share-qq-icon" viewBox="0 0 1024 1024"><path fill="#1296DB" d="M824.8 613.2c-16-51.4-34.4-94.6-62.7-165.3C766.5 262.2 689.3 112 511.5 112 331.7 112 256.2 265.2 261 447.9c-28.4 70.8-46.7 113.7-62.7 165.3-34 109.5-23 154.8-14.6 155.8 18 2.2 70.1-82.4 70.1-82.4 0 49 25.2 112.9 79.8 159-26.4 8.1-85.7 29.9-71.6 53.8 11.4 19.3 196.2 12.3 249.5 6.3 53.3 6 238.1 13 249.5-6.3 14.1-23.8-45.3-45.7-71.6-53.8 54.6-46.2 79.8-110.1 79.8-159 0 0 52.1 84.6 70.1 82.4 8.5-1.1 19.5-46.4-14.5-155.8z"/></svg></div>
                QQ
            </div>
            <div class="share-item" onclick="MiraiShare.to('wechat')">
                <div class="share-icon icon-wechat"><svg class="share-wechat-icon" viewBox="0 0 1024 1024"><path fill="#24DB5A" d="M669.3 369.4c9.8 0 19.6 0 29.4 1.6C671 245.2 536.9 152 383.2 152 211.6 152 71 269.7 71 416.8c0 85 45.8 156.9 124.2 210.9l-31.1 93.2L273.6 667c39.2 8.2 70.3 16.3 109.5 16.3 9.8 0 19.6 0 31.1-1.6-6.5-21.3-9.8-42.5-9.8-65.4 0.1-135.7 116.2-246.9 264.9-246.9zm-168.4-85c24.5 0 39.2 16.3 39.2 39.2 0 22.9-16.3 39.2-39.2 39.2-24.5 0-47.4-16.4-47.4-39.2 0-24.5 24.6-39.2 47.4-39.2zm-216.3 73.1c-24.7 0-47.8-16.2-47.8-38.8 0-24.3 24.7-38.8 47.8-38.8s39.5 16.2 39.5 38.8c0.1 22.7-16.4 38.8-39.5 38.8zM953.8 613c0-125.9-124.2-227.2-264.8-227.2-148.8 0-266.5 103-266.5 227.2 0 125.9 117.7 227.2 266.5 227.2 31.1 0 62.1-8.2 93.2-16.3l85 47.4-22.9-78.5c62.1-47.4 109.5-109.5 109.5-179.8zm-351.5-39.2c-14.7 0-31.1-14.7-31.1-31.1 0-14.7 16.3-31.1 31.1-31.1 22.9 0 39.2 16.3 39.2 31.1 0 16.4-14.7 31.1-39.2 31.1zm178-7.6c-14.8 0-31.3-14.6-31.3-30.7 0-14.6 16.5-30.7 31.3-30.7 23.1 0 39.5 16.2 39.5 30.7 0 16.2-16.4 30.7-39.5 30.7z"/></svg></div>
                微信
            </div>
            <div class="share-item" onclick="MiraiShare.to('weibo')">
                <div class="share-icon icon-weibo"><svg class="share-weibo-icon" viewBox="0 0 1024 1024"><path fill="#F56467" d="M676.2 232.5s113.3-12 161.4 58.2c44.8 44.8 27.4 158.6 27.4 158.6a22 22 0 0 0 22.6 26h11.2a30.4 30.4 0 0 0 29.1-26.2c4.8-26.1 26.1-138.6-54.4-215.7-62.7-60.3-148.6-66.9-183-66.9h-15.2a27 27 0 0 0-26.4 26.9v13.1a25.6 25.6 0 0 0 27.2 25.9zM453.1 758.1c79-16 132.5-81.9 119.5-148.6-11.2-57.4-67.8-96-133.8-96a163.5 163.5 0 0 0-32 3.2c-79 16-132.5 81.9-119.5 148.6s86.9 108.2 165.8 92.8zm2.2-171.7a24.6 24.6 0 1 1-23.4-24.6 24.5 24.5 0 0 1 23.4 24.6zM368 625c24.3-11.4 51-5.6 59.5 13s-3.5 42.7-27.5 54a61 61 0 0 1-25.1 5.8 36 36 0 0 1-34.4-18.9c-9-18.4 3.7-42.6 27.5-53.9z"/><path fill="#F56467" d="M467.5 857.4c208 0 374.4-110.2 374.4-246.4 0-114.9-141.8-114.9-141.8-122.4s70.7-74.1 0-115.7c-42.2-25-105.6-12.2-148.8 0a330.2 330.2 0 0 1-47 14.4c55.7-97.1-23.7-128-64-128-96 0-348.6 214.9-348.6 350.9s168.2 247.2 375.8 247.2zm-34.4-392.6c132.6-18.7 250.2 37.3 262.6 124.8s-85.3 173.8-218.1 192a365.3 365.3 0 0 1-50.7 3.5c-110.7 0-201-52.2-211.7-128-12.3-87.5 85.3-173.8 217.9-192.3z"/><path fill="#F56467" d="M780.6 444.2h16a21.4 21.4 0 0 0 20.6-17.4s19-73.1-25-113.1a111 111 0 0 0-75.8-28.2 108.3 108.3 0 0 0-25.3 2.6 21.1 21.1 0 0 0-17.4 20.2v6.9a16 16 0 0 0 17.9 16.8s48-6.6 71.4 21.6 5.1 73.8 5.1 73.8a12.3 12.3 0 0 0 12.5 17z"/></svg></div>
                微博
            </div>
            <div class="share-item" onclick="MiraiShare.to('qzone')">
                <div class="share-icon icon-qzone"><svg class="share-qzone-icon" viewBox="0 0 1024 1024"><path fill="#F5BE3F" d="M512.2 736.1S266.2 886.9 251 874.6c-15.2-12.3 49.9-293.3 49.9-293.3S80.5 396.3 89.5 373.6c9-22.7 292-42.8 292-42.8S486.7 63.9 512.2 63.9c25.5 0 130.6 266.8 130.6 266.8S927 351 934.9 373.6c7.8 22.6-211.3 207.7-211.3 207.7s2.7 18 5.9 31.3c0.2 0.9-102.3 3.2-186.3 0-44.1-1.7-97.2-10-97.2-10l243.2-174.9s-88-16-176.9-19.2c-97.4-3.5-197.1 5.9-211.3 9.6-8.9 2.3 63 2.1 145 9.6 57.4 5.2 133 19.2 133 19.2L335.7 629.5s48.6 8.7 221.1 4.9 231.4-17.2 231.4-17c0.1 0.5-11.7 6.5-24.6 9-14.1 2.7-28.1 7.4-27.9 8 18.5 81 50.1 227.4 37.7 240.1-17.1 17.6-261.2-138.4-261.2-138.4z"/></svg></div>
                QQ空间
            </div>
            <div class="share-item" onclick="MiraiShare.poster()">
                <div class="share-icon icon-poster"><svg class="share-poster-icon" viewBox="0 0 1024 1024"><path fill="#4078FD" opacity=".2" d="M800 480a191.1 191.1 0 0 1 96 25.6V736a96 96 0 0 1-96 96H256.5a240 240 0 0 1 361.9-222.5A192 192 0 0 1 800 480z"/><path fill="#4078FD" d="M791.6 464a208 208 0 0 0-179.2 117.4l-2.4 5.3-2.1-1.1a256 256 0 0 0-367.5 247.3 16 16 0 0 0 16 14.9H800a112 112 0 0 0 112-112v-230.4a16 16 0 0 0-8-13.9 207.1 207.1 0 0 0-112.4-27zm17.7 32a174.8 174.8 0 0 1 70.6 19.2V736l-.2 5.3A80 80 0 0 1 800 816H272a224 224 0 0 1 338.2-192.7 16 16 0 0 0 23.3-8.5 176 176 0 0 1 166.4-118.7z"/><path fill="#4078FD" d="M800 160H224a128 128 0 0 0-128 128v448a128 128 0 0 0 128 128h576a128 128 0 0 0 128-128V288a128 128 0 0 0-128-128zM224 224h576a64 64 0 0 1 64 64v448a64 64 0 0 1-64 64H224a64 64 0 0 1-64-64V288a64 64 0 0 1 64-64z"/><path fill="#FE9C23" d="M224 368A80 80 0 1 0 304 288a80 80 0 0 0-80 80z"/></svg></div>
                海报
            </div>
            <div class="share-item" onclick="MiraiShare.copy()">
                <div class="share-icon icon-link"><svg class="share-link-icon" viewBox="0 0 1024 1024"><path fill="#3259CE" d="M514.2 659.1c-44.8 42.1-84.6 85-127.6 126.7-46.3 45.6-120.6 45.6-167 0-22.7-23-34.9-54.3-33.7-86.6 1.2-32.3 15.6-62.6 39.9-83.9 41.6-42.5 84.2-83.7 125.8-125.8 10.5-7.1 17.1-18.6 18.1-31.3 1-12.6-3.9-25-13.2-33.6-9-8.2-21-12.4-33.2-11.5-12.2.8-23.5 6.6-31.3 16-44.8 44.8-89.5 86.8-131.2 131.2-46.9 47.1-67.7 114.2-55.9 179.6 11.9 65.4 55 120.9 115.4 148.5 69.8 34.8 153.8 22.6 210.8-30.4 50.6-44.8 97.1-94 143.7-142.8 8.9-11.1 12.8-25.3 10.7-39.4-3.4-15.3-15.3-27.3-30.6-30.9-15-3.7-30.9 1.9-40.7 14.2zM873.2 240.1c-28.2-71.4-96.5-119-173.2-120.9-47.3-4.1-94.3 10-131.6 39.4-53.7 48.3-104.3 99.8-154.4 151.7a40 40 0 0 0-7.5 42c5.8 14.3 19.4 23.9 34.8 24.7 14.2-.5 27.8-6.2 38-16.1 44.8-44.8 89.5-89.5 134.3-130.7 27.2-25.4 66-34.3 101.6-23.3 41.2 10 73.6 41.6 84.8 82.4 11.2 40.9-.7 84.6-31.1 114.1L637.8 534.6c-18.6 15.9-21 43.8-5.4 62.7 18.6 18.3 48.5 18.3 67.1 0 44.8-44.8 89.5-86.8 134.3-134.3 59.2-58.4 75-147.8 39.4-222.9z"/><path fill="#3259CE" d="M338.3 668c8 8.6 19.2 13.5 30.9 13.5s22.9-4.9 30.9-13.5c86.2-85.9 172-172.2 257.4-258.7 5.5-7 9.9-14.9 13-23.3 1.6-19-9-37-26.4-44.8-16.9-7.7-36.9-3.1-48.8 11.2L340.5 607.2c-9 7.4-14.4 18.3-14.8 29.9-.4 11.6 4.2 22.9 12.6 30.9z"/></svg></div>
                复制链接
            </div>
        </div>
        <div class="share-close-btn" onclick="MiraiShare.close()">关闭</div>
    </div>
</div>

<div id="mirai-poster-modal" style="display:none">
    <div class="poster-mask" onclick="window.MiraiShare&&MiraiShare.closePoster()"></div>
    <div class="poster-content">
        <div class="poster-card">
            <div class="poster-close" onclick="window.MiraiShare&&MiraiShare.closePoster()" title="关闭"><svg class="close-icon" viewBox="0 0 1024 1024"><path fill="#fff" d="M573 512l243-243c16-16 16-44 0-61-16-16-44-16-61 0L512 451 269 208c-16-16-44-16-61 0-16 16-16 44 0 61l243 243-243 243c-16 16-16 44 0 61 16 16 44 16 61 0l243-243 243 243c16 16 44 16 61 0 16-16 16-44 0-61L573 512z"/></svg></div>
            <img id="mirai-generated-poster" src="">
            <div class="poster-tip">长按保存图片</div>
        </div>
    </div>
</div>

<div id="mirai-wechat-modal">
    <div class="wechat-mask" onclick="MiraiShare.closeWechat()"></div>
    <div class="wechat-content">
        <div class="wechat-title">微信扫一扫分享</div>
        <div id="mirai-wechat-qrcode" class="wechat-qr"></div>
        <div class="wechat-desc">打开微信，点击底部的"发现"，<br>使用"扫一扫"即可分享给好友。</div>
        <div class="wechat-close" onclick="MiraiShare.closeWechat()"><svg class="close-icon" viewBox="0 0 1024 1024"><path fill="#3A414B" d="M573 512l243-243c16-16 16-44 0-61-16-16-44-16-61 0L512 451 269 208c-16-16-44-16-61 0-16 16-16 44 0 61l243 243-243 243c-16 16-16 44 0 61 16 16 44 16 61 0l243-243 243 243c16 16 44 16 61 0 16-16 16-44 0-61L573 512z"/></svg></div>
    </div>
</div>

<?php if (!isset($this->is404) || !$this->is404): ?>
<?php
    $share_title = '';
    $share_author = '';
    $share_cover = '';
    $share_date = '';
    $share_desc = '';
    $share_cat = '';
    $share_url = '';

    if ($this->is('post') || $this->is('page')) {
        $share_title = $this->title;
        $share_author = $this->options->authorName ? $this->options->authorName : $this->author->screenName;
        $share_cover = Mirai_normalizeUrl($this->fields->cover ? $this->fields->cover : Mirai_getPostCover($this));
        ob_start();
        $this->date('Y-m-d');
        $share_date = ob_get_clean();
        $share_desc = $this->fields->description ? $this->fields->description : ($this->fields->excerpt ? $this->fields->excerpt : Mirai_getPostExcerpt($this, 140));
        $share_cat = count($this->categories) > 0 ? $this->categories[0]['name'] : '';
        $share_url = $this->permalink;
    } elseif ($this->is('archive')) {
        ob_start();
        $this->archiveTitle(':', '', '');
        $share_title = ob_get_clean();
        $share_author = $this->options->authorName; // Site author
        $share_cover = Mirai_normalizeUrl($this->options->logoImage); // Site logo
        $share_date = ''; // No date for archives
        $share_desc = $this->getDescription() ? $this->getDescription() : ($this->options->siteDescription ?: $this->options->description);
        if ($this->is('category')) {
            $share_cat = $this->getArchiveTitle();
        }

        $share_url = $this->archiveUrl;
    }
    ?>
<div id="mirai-share-data" style="display:none"
    data-title="<?php echo htmlspecialchars($share_title ?? ''); ?>"
    data-url="<?php echo htmlspecialchars($share_url ?? ''); ?>"
    data-author="<?php echo htmlspecialchars($share_author ?? ''); ?>"
    data-cover="<?php echo htmlspecialchars($share_cover ?? ''); ?>"
    data-logo="<?php echo htmlspecialchars($this->options->logoImage ? Mirai_normalizeUrl($this->options->logoImage) : $this->options->themeUrl . '/assets/images/logo.png'); ?>"
    data-date="<?php echo htmlspecialchars($share_date ?? ''); ?>"
    data-desc="<?php echo htmlspecialchars($share_desc ?? ''); ?>"
    data-cat="<?php echo htmlspecialchars($share_cat ?? ''); ?>"
></div>
<?php endif; ?>
<canvas id="mirai-poster-canvas" style="display:none"></canvas>

<script>
    window.shareArticle = function() {
        if (typeof MiraiShare !== 'undefined') return MiraiShare.open();
        
        var script = document.createElement('script');
        script.src = '<?php $this->options->themeUrl("assets/js/share.js"); ?>';
        script.onload = function() {
            if (typeof MiraiShare !== 'undefined') {
                MiraiShare.init();
                MiraiShare.open();
            }
        };
        document.body.appendChild(script);
    };
</script>