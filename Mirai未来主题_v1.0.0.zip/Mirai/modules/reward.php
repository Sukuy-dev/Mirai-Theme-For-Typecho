<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php if (isset($this->options->displayReward) && $this->options->displayReward): ?>
<div class="reward-modal" id="rewardModal" onclick="closeRewardModal(event)">
    <div class="reward-modal-content">
        <div class="reward-modal-header">
            <div class="sky-h3">打赏杯咖啡或蜜雪冰城吧</div>
            <button class="reward-close-btn" onclick="closeRewardModal(event, true)">
                <svg class="close-icon" viewBox="0 0 1024 1024"><path fill="#3A414B" d="M573 512l243-243c16-16 16-44 0-61-16-16-44-16-61 0L512 451 269 208c-16-16-44-16-61 0-16 16-16 44 0 61l243 243-243 243c-16 16-16 44 0 61 16 16 44 16 61 0l243-243 243 243c16 16 44 16 61 0 16-16 16-44 0-61L573 512z"/></svg>
            </button>
        </div>
        <div class="reward-modal-body">
            <div class="reward-qrcodes">
                <?php if (isset($this->options->rewardWechat) && $this->options->rewardWechat): ?>
                <div class="reward-qrcode-item">
                    <div class="reward-qrcode-label">微信扫一扫</div>
                    <div class="reward-qrcode-box wechat">
                        <img src="<?php echo $this->options->rewardWechat; ?>" alt="微信赞赏码">
                    </div>
                </div>
                <?php endif; ?>
                <?php if (isset($this->options->rewardAlipay) && $this->options->rewardAlipay): ?>
                <div class="reward-qrcode-item">
                    <div class="reward-qrcode-label">支付宝扫一扫</div>
                    <div class="reward-qrcode-box alipay">
                        <img src="<?php echo $this->options->rewardAlipay; ?>" alt="支付宝赞赏码">
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
