<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$adminDir = '/' . trim((string)__TYPECHO_ADMIN_DIR__, '/');
include_once __TYPECHO_ROOT_DIR__ . $adminDir . '/common.php';
include_once __TYPECHO_ROOT_DIR__ . $adminDir . '/header.php';
include_once __TYPECHO_ROOT_DIR__ . $adminDir . '/menu.php';

if (!$user->pass('administrator')) {
    throw new Typecho_Widget_Exception(_t('禁止访问'), 403);
}

$options = \Typecho\Widget::widget('Widget_Options');
$themeDir = __TYPECHO_ROOT_DIR__ . '/usr/themes/' . $options->theme;
$coreFile = $themeDir . '/common/functions/core.php';
if (file_exists($coreFile)) {
    require_once $coreFile;
}
$functionsFile = $themeDir . '/common/functions/pay.php';
if (file_exists($functionsFile)) {
    require_once $functionsFile;
}

$db = \Typecho\Db::get();
$security = \Typecho\Widget::widget('Widget_Security');

$payEnabled = Mirai_payEnabled();
if (!$payEnabled) {
    echo '<div class="message error"><p>支付功能未启用，请在主题设置中开启支付功能</p></div>';
    return;
}

$panelName = 'MiraiCore/Balance/manage-balance.php';
$panelUrl = $options->adminUrl('extending.php?panel=' . urlencode($panelName), true);
$success = '';
$error = '';
$total = 0;
$totalPages = 1;
$page = 1;
$pageSize = 20;
$keywords = '';
$users = [];
$userBalances = [];

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$action = isset($_POST['action']) ? trim((string)$_POST['action']) : '';
if ($action === 'update_balance' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $processedKey = 'mirai_balance_processed_' . md5(serialize($_POST));
        if (isset($_SESSION[$processedKey])) {
            $redirectUrl = $options->adminUrl('extending.php?panel=' . urlencode($panelName) . '&success=1&ts=' . time(), true);
            header('Location: ' . $redirectUrl);
            exit;
        }

        $token = isset($_POST['_']) ? trim((string)$_POST['_']) : '';
        $expectedToken = $security->getToken('/action/users-edit');
        if ($token !== $expectedToken) {
            throw new \Exception('安全验证失败，请刷新页面重试');
        }

        $formToken = isset($_POST['form_token']) ? trim((string)$_POST['form_token']) : '';
        if (empty($formToken)) {
            throw new \Exception('表单验证失败');
        }

        $tokenKey = 'mirai_balance_used_token_' . $formToken;
        if (isset($_SESSION[$tokenKey])) {
            $redirectUrl = $options->adminUrl('extending.php?panel=' . urlencode($panelName) . '&success=1&ts=' . time(), true);
            header('Location: ' . $redirectUrl);
            exit;
        }
        
        $targetUid = isset($_POST['uid']) ? (int)$_POST['uid'] : 0;
        $amount = isset($_POST['amount']) ? (float)$_POST['amount'] : 0;
        $type = isset($_POST['type']) ? trim((string)$_POST['type']) : 'add';
        $remark = isset($_POST['remark']) ? trim((string)$_POST['remark']) : '';
        
        if ($targetUid <= 0) {
            throw new \Exception('请选择用户');
        }
        if ($amount <= 0) {
            throw new \Exception('金额必须大于0');
        }
        if (!is_finite($amount)) {
            throw new \Exception('金额格式错误');
        }
        if ($amount > 999999.99) {
            throw new \Exception('单次调整金额不能超过 999,999.99');
        }
        
        $actualAmount = $type === 'add' ? $amount : -$amount;
        $result = Mirai_payAdminAdjustBalance($targetUid, $actualAmount, 'admin_adjust', $remark ?: '管理员调整');
        
        if (!empty($result['success'])) {
            $tokenKey = 'mirai_balance_used_token_' . $formToken;
            $_SESSION[$tokenKey] = time();
            $processedKey = 'mirai_balance_processed_' . md5(serialize($_POST));
            $_SESSION[$processedKey] = time();
            $success = ($type === 'add' ? '增加' : '扣除') . '余额成功';

            $redirectUrl = $options->adminUrl('extending.php?panel=' . urlencode($panelName) . '&success=1&ts=' . time(), true);
            header('Location: ' . $redirectUrl);
            exit;
        } else {
            throw new \Exception($result['msg'] ?? '余额调整失败，可能是余额不足');
        }
    } catch (\Exception $e) {
        $error = $e->getMessage();
    }
}

if (isset($_GET['success']) && $_GET['success'] === '1') {
    $success = '余额调整成功';
}

$keywords = isset($_GET['keywords']) ? trim((string)$_GET['keywords']) : '';
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;

$query = $db->select('uid', 'name', 'screenName', 'mail', 'group')->from('table.users');
if ($keywords !== '') {
    $query->where('name LIKE ? OR screenName LIKE ? OR mail LIKE ?', '%' . $keywords . '%', '%' . $keywords . '%', '%' . $keywords . '%');
}
$countQuery = clone $query;
$total = $db->fetchObject($countQuery->select(['COUNT(*)' => 'num']))->num;
$totalPages = max(1, ceil($total / $pageSize));
$page = min($page, $totalPages);
if ($page < 1) {
    $page = 1;
}

$query->order('uid', \Typecho\Db::SORT_DESC)->limit($pageSize)->offset(($page - 1) * $pageSize);
$users = $db->fetchAll($query);

$userBalances = [];
if (!empty($users)) {
    $uids = array_map(function($userRow) {
        return (int)$userRow['uid'];
    }, $users);
    $wallets = Mirai_payAdminGetWallets(1, count($uids), $uids);
    foreach ($wallets['list'] as $wallet) {
        $userBalances[(int)$wallet['uid']] = (float)$wallet['balance'];
    }
}

$currency = Mirai_payCurrencyName();
$balanceName = Mirai_payBalanceName();
?>
<main class="main">
    <div class="body container">
        <div class="typecho-page-title">
            <h2>用户<?php echo htmlspecialchars($balanceName); ?>管理</h2>
        </div>
        <div class="row typecho-page-main" role="main">
            <div class="col-mb-12 typecho-list">
                <?php if ($success !== ''): ?>
                    <div class="message success popup"><p><?php echo htmlspecialchars($success); ?></p></div>
                <?php endif; ?>
                <?php if ($error !== ''): ?>
                    <div class="message error popup"><p><?php echo htmlspecialchars($error); ?></p></div>
                <?php endif; ?>
                
                <div class="typecho-list-operate clearfix">
                    <form method="get" action="<?php echo $options->adminUrl('extending.php', true); ?>">
                        <input type="hidden" name="panel" value="<?php echo htmlspecialchars($panelName); ?>">
                        <div class="search" role="search">
                            <input type="text" name="keywords" value="<?php echo htmlspecialchars($keywords); ?>" placeholder="用户名/昵称/邮箱">
                            <button type="submit" class="btn btn-s">筛选</button>
                            <?php if ($keywords !== ''): ?>
                                <a href="<?php echo $panelUrl; ?>">&laquo; 取消筛选</a>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
                
                <div class="typecho-table-wrap">
                    <table class="typecho-list-table">
                        <colgroup>
                            <col width="80">
                            <col width="150">
                            <col width="150">
                            <col width="200">
                            <col width="120">
                            <col width="150">
                        </colgroup>
                        <thead>
                        <tr>
                            <th>用户ID</th>
                            <th>用户名</th>
                            <th>昵称</th>
                            <th>邮箱</th>
                            <th><?php echo htmlspecialchars($balanceName); ?></th>
                            <th>操作</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if (empty($users)): ?>
                            <tr><td colspan="6"><h6 class="typecho-list-table-title">暂无用户</h6></td></tr>
                        <?php else: ?>
                            <?php foreach ($users as $u): ?>
                                <?php
                                $uid = (int)$u['uid'];
                                $balance = isset($userBalances[$uid]) ? $userBalances[$uid] : 0;
                                ?>
                                <tr>
                                    <td><?php echo $uid; ?></td>
                                    <td><?php echo htmlspecialchars($u['name']); ?></td>
                                    <td><?php echo htmlspecialchars($u['screenName'] ?: '-'); ?></td>
                                    <td><?php echo htmlspecialchars($u['mail'] ?: '-'); ?></td>
                                    <td><strong><?php echo number_format($balance, 2); ?></strong> <?php echo htmlspecialchars($currency); ?></td>
                                    <td>
                                        <a href="javascript:;" class="btn btn-s js-balance-btn" 
                                           data-uid="<?php echo $uid; ?>" 
                                           data-name="<?php echo htmlspecialchars($u['name']); ?>"
                                           data-balance="<?php echo $balance; ?>">调整余额</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <?php if ($totalPages > 1): ?>
                    <div class="typecho-pager">
                        <div class="typecho-pager-content">
                            <ul>
                                <?php
                                $pageNav = new \Typecho\Widget\Helper\PageNavigator\Box($total, $page, $pageSize, \Typecho\Request::getInstance()->makeUriByRequest('page={page}'));
                                $pageNav->render('&laquo;', '&raquo;');
                                ?>
                            </ul>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</main>
<div id="mirai-balance-modal" style="display:none;position:fixed;inset:0;z-index:10022;">
    <div class="mirai-pay-modal-mask" style="position:absolute;inset:0;background:rgba(0,0,0,0.5);"></div>
    <div class="mirai-pay-method-modal-panel" style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);background:#fff;border-radius:8px;padding:24px;max-width:480px;width:90%;box-shadow:0 4px 20px rgba(0,0,0,0.15);">
        <button type="button" class="mirai-pay-method-modal-close" aria-label="close" style="position:absolute;top:12px;right:12px;width:32px;height:32px;border:none;background:transparent;font-size:24px;line-height:32px;cursor:pointer;color:#666;">×</button>
        <div class="mirai-pay-method-modal-title" style="font-size:18px;font-weight:600;margin-bottom:20px;padding-right:40px;border-bottom:1px solid #eee;padding-bottom:12px;">调整用户余额</div>
        <?php $formToken = md5(uniqid('mirai_balance_', true) . mt_rand(1000, 9999)); ?>
        <form method="post" action="<?php echo $panelUrl; ?>">
            <input type="hidden" name="action" value="update_balance">
            <input type="hidden" name="_" value="<?php echo $security->getToken('/action/users-edit'); ?>">
            <input type="hidden" name="form_token" value="<?php echo $formToken; ?>">
            <input type="hidden" name="uid" id="balance-uid" value="">
            <div style="margin-bottom:16px;">
                <label style="display:block;margin-bottom:8px;font-weight:500;">用户</label>
                <div id="balance-user-name" style="padding:8px 12px;background:#f5f5f5;border-radius:4px;"></div>
            </div>
            <div style="margin-bottom:16px;">
                <label style="display:block;margin-bottom:8px;font-weight:500;">当前余额</label>
                <div id="balance-current" style="padding:8px 12px;background:#f5f5f5;border-radius:4px;"></div>
            </div>
            <div style="margin-bottom:16px;">
                <label style="display:block;margin-bottom:8px;font-weight:500;">操作类型</label>
                <select name="type" style="width:100%;padding:8px 12px;border:1px solid #ddd;border-radius:4px;height:36px;line-height:20px;font-size:14px;">
                    <option value="add">增加余额</option>
                    <option value="subtract">扣除余额</option>
                </select>
            </div>
            <div style="margin-bottom:16px;">
                <label style="display:block;margin-bottom:8px;font-weight:500;">金额</label>
                <input type="number" name="amount" step="0.01" min="0.01" required style="width:100%;padding:8px 12px;border:1px solid #ddd;border-radius:4px;box-sizing:border-box;">
            </div>
            <div style="margin-bottom:20px;">
                <label style="display:block;margin-bottom:8px;font-weight:500;">备注</label>
                <input type="text" name="remark" placeholder="管理员调整" style="width:100%;padding:8px 12px;border:1px solid #ddd;border-radius:4px;box-sizing:border-box;">
            </div>
            <div style="text-align:right;">
                <button type="button" class="btn" onclick="closeBalanceModal()" style="margin-right:8px;">取消</button>
                <button type="submit" class="btn primary">确认</button>
            </div>
        </form>
    </div>
</div>
<?php
include_once __TYPECHO_ROOT_DIR__ . $adminDir . '/copyright.php';
include_once __TYPECHO_ROOT_DIR__ . $adminDir . '/common-js.php';
include_once __TYPECHO_ROOT_DIR__ . $adminDir . '/table-js.php';
include_once __TYPECHO_ROOT_DIR__ . $adminDir . '/footer.php';
?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    var modal = document.getElementById('mirai-balance-modal');
    var mask = modal.querySelector('.mirai-pay-modal-mask');
    var closeBtn = modal.querySelector('.mirai-pay-method-modal-close');
    
    window.closeBalanceModal = function() {
        modal.style.display = 'none';
        document.body.style.overflow = '';
    };
    
    if (mask) mask.addEventListener('click', closeBalanceModal);
    if (closeBtn) closeBtn.addEventListener('click', closeBalanceModal);
    
    document.querySelectorAll('.js-balance-btn').forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            var uid = btn.getAttribute('data-uid');
            var name = btn.getAttribute('data-name');
            var balance = btn.getAttribute('data-balance');
            var currency = '<?php echo htmlspecialchars($currency); ?>';
            var balanceName = '<?php echo htmlspecialchars($balanceName); ?>';
            
            document.getElementById('balance-uid').value = uid;
            document.getElementById('balance-user-name').textContent = name + ' (ID: ' + uid + ')';
            document.getElementById('balance-current').textContent = parseFloat(balance).toFixed(2) + ' ' + currency;
            
            modal.style.display = 'block';
            document.body.style.overflow = 'hidden';
        });
    });
});
</script>
